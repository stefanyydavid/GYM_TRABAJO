package PRESENTACION;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Ventana principal (Landing Page) de NEXUS GYM.
 * Dibuja /IMAGENES/FRONT.jpeg como fondo y coloca botones transparentes
 * sobre TODOS los elementos clickeables del diseño: menú superior,
 * banner de promoción, flechas del carrusel, tarjeta de inscripción,
 * franja de cookies e ícono de WhatsApp.
 *
 * Todas las coordenadas fueron medidas píxel a píxel sobre el archivo
 * FRONT.jpeg (1376x768) y escaladas matemáticamente a la ventana 1100x650,
 * por lo que no requieren ajuste manual.
 *
 * @author NEXUSGyM
 */
public class FrmPrincipal extends JFrame {

    // Panel de fondo con la imagen
    private PanelFondo panelFondo;

    // Overlays usados para "ocultar" el banner de promo y la franja de cookies
    private JPanel overlayBanner;
    private JPanel overlayCookies;

    public FrmPrincipal() {
        initComponents();
    }

    private void initComponents() {

        setTitle("NEXUS GYM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setResizable(false);

        // ---------- Panel de fondo ----------
        panelFondo = new PanelFondo();
        panelFondo.setLayout(null); // Posicionamiento absoluto (coordenadas exactas)
        panelFondo.setBounds(0, 0, 1100, 650);

        // =========================================================
        // 1) MENÚ SUPERIOR
        // =========================================================

        JButton btnLogo = crearBotonTransparente();
        btnLogo.setBounds(98, 61, 124, 30);
        btnLogo.addActionListener(e -> { /* Ya estamos en el inicio */ });
        panelFondo.add(btnLogo);

        JButton btnSedes = crearBotonTransparente();
        btnSedes.setBounds(244, 66, 54, 19);
        btnSedes.addActionListener(e -> mostrarEnConstruccion("Sedes"));
        panelFondo.add(btnSedes);

        JButton btnServicios = crearBotonTransparente();
        btnServicios.setBounds(317, 66, 65, 19);
        btnServicios.addActionListener(e -> mostrarEnConstruccion("Servicios"));
        panelFondo.add(btnServicios);

        JButton btnClases = crearBotonTransparente();
        btnClases.setBounds(404, 66, 56, 19);
        btnClases.addActionListener(e -> mostrarEnConstruccion("Clases"));
        panelFondo.add(btnClases);

        // ---- INICIAR SESIÓN -> abre SESION.java ----
        JButton btnIniciarSesion = crearBotonTransparente();
        btnIniciarSesion.setBounds(876, 56, 132, 40);
        btnIniciarSesion.addActionListener(e -> new SESION().setVisible(true));
        panelFondo.add(btnIniciarSesion);

        // =========================================================
        // 2) BANNER DE PROMOCIÓN ("1 mes GRATIS" / Más info / X)
        // =========================================================

        JButton btnMasInfo = crearBotonTransparente();
        btnMasInfo.setBounds(635, 116, 49, 16);
        btnMasInfo.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Inscríbete antes de fin de mes y obtén tu primer mes de\n"
                + "membresía completamente GRATIS. Aplican términos y condiciones.",
                "Promoción NEXUS GYM", JOptionPane.INFORMATION_MESSAGE));
        panelFondo.add(btnMasInfo);

        // Overlay que cubre el banner completo (color exacto muestreado: crema)
        overlayBanner = new JPanel();
        overlayBanner.setBackground(new Color(234, 227, 209));
        overlayBanner.setBounds(0, 103, 1100, 40);
        overlayBanner.setVisible(false);
        panelFondo.add(overlayBanner);

        JButton btnCerrarBanner = crearBotonTransparente();
        btnCerrarBanner.setBounds(982, 108, 26, 26);
        btnCerrarBanner.addActionListener(e -> overlayBanner.setVisible(true));
        panelFondo.add(btnCerrarBanner);

        // =========================================================
        // 3) FLECHAS DEL CARRUSEL
        // =========================================================

        JButton btnFlechaIzq = crearBotonTransparente();
        btnFlechaIzq.setBounds(98, 345, 34, 34);
        btnFlechaIzq.addActionListener(e -> mostrarEnConstruccion("Carrusel (imagen anterior)"));
        panelFondo.add(btnFlechaIzq);

        JButton btnFlechaDer = crearBotonTransparente();
        btnFlechaDer.setBounds(968, 342, 34, 34);
        btnFlechaDer.addActionListener(e -> mostrarEnConstruccion("Carrusel (imagen siguiente)"));
        panelFondo.add(btnFlechaDer);

        // =========================================================
        // 4) TARJETA "Tu próximo paso empieza aquí" -> Frmcliente.java
        // =========================================================

        JButton btnInscribete = crearBotonTransparente();
        btnInscribete.setBounds(755, 511, 140, 48);
        btnInscribete.addActionListener(e -> new Frmcliente().setVisible(true));
        panelFondo.add(btnInscribete);

        // =========================================================
        // 5) FRANJA DE COOKIES ("ACEPTAR")
        // =========================================================

        // Overlay que cubre la franja de cookies (color exacto muestreado: gris oscuro)
        overlayCookies = new JPanel();
        overlayCookies.setBackground(new Color(30, 38, 46));
        overlayCookies.setBounds(0, 596, 1100, 54);
        overlayCookies.setVisible(false);
        panelFondo.add(overlayCookies);

        JButton btnAceptarCookies = crearBotonTransparente();
        btnAceptarCookies.setBounds(912, 615, 92, 28);
        btnAceptarCookies.addActionListener(e -> overlayCookies.setVisible(true));
        panelFondo.add(btnAceptarCookies);

        // =========================================================
        // 6) ÍCONO DE WHATSAPP (abre el navegador con el chat)
        // =========================================================

        JButton btnWhatsApp = crearBotonTransparente();
        btnWhatsApp.setBounds(1035, 590, 52, 46);
        btnWhatsApp.addActionListener(e -> abrirWhatsApp());
        panelFondo.add(btnWhatsApp);

        // ---------- Contenedor principal ----------
        JLayeredPane capas = new JLayeredPane();
        capas.setPreferredSize(new Dimension(1100, 650));
        capas.add(panelFondo, JLayeredPane.DEFAULT_LAYER);

        getContentPane().add(capas);
        pack();
        setLocationRelativeTo(null); // Centrar en pantalla
    }

    /**
     * Crea un JButton totalmente transparente (sin relleno, sin borde,
     * sin foco visual) con cursor de mano al pasar el mouse.
     */
    private JButton crearBotonTransparente() {
        JButton boton = new JButton();
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        // Descomenta la siguiente línea si alguna vez necesitas ver
        // dónde cae exactamente un botón sobre la imagen:
        // boton.setContentAreaFilled(true); boton.setBackground(new Color(255,0,0,80)); boton.setOpaque(true);
        return boton;
    }

    /** Mensaje estándar para secciones que aún no tienen ventana propia. */
    private void mostrarEnConstruccion(String seccion) {
        JOptionPane.showMessageDialog(this,
                "La sección \"" + seccion + "\" estará disponible próximamente.",
                "En construcción", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Abre el chat de WhatsApp en el navegador predeterminado. */
    private void abrirWhatsApp() {
        try {
            // Reemplaza 573000000000 por el número real de NEXUS GYM (con código de país, sin '+').
            Desktop.getDesktop().browse(new URI("https://wa.me/573000000000"));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo abrir WhatsApp: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Panel personalizado que dibuja la imagen de fondo escalada
     * al tamaño completo de la ventana.
     */
    private class PanelFondo extends JPanel {

        private Image imagenFondo;

        public PanelFondo() {
            setBackground(Color.WHITE);
            try {
                ImageIcon icono = new ImageIcon(getClass().getResource("/IMAGENES/FRONT.jpeg"));
                imagenFondo = icono.getImage();
            } catch (Exception e) {
                System.err.println("No se pudo cargar /IMAGENES/FRONT.jpeg: " + e.getMessage());
                imagenFondo = null;
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (imagenFondo != null) {
                g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    /**
     * Método main de prueba para ejecutar únicamente esta ventana.
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }
}