/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.util.Date;

/**
 *
 * @author prestamo
 */
public class facturas {
    private int id_factura;
    private String numero_factura;
    private int id_cliente;
    private int id_sede;
    private int id_membresia;
    private Date fecha_emision;
    private Date fecha_vencimiento;
    private double subtotal;
    private double descuento;
    private double impuesto;
    private double total;
    private String estado;
    private int emitida_por;
    private String observaciones;

    public facturas(int id_factura, String numero_factura, int id_cliente, int id_sede, int id_membresia, Date fecha_emision, Date fecha_vencimiento, double subtotal, double descuento, double impuesto, double total, String estado, int emitida_por, String observaciones) {
        this.id_factura = id_factura;
        this.numero_factura = numero_factura;
        this.id_cliente = id_cliente;
        this.id_sede = id_sede;
        this.id_membresia = id_membresia;
        this.fecha_emision = fecha_emision;
        this.fecha_vencimiento = fecha_vencimiento;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.impuesto = impuesto;
        this.total = total;
        this.estado = estado;
        this.emitida_por = emitida_por;
        this.observaciones = observaciones;
    }

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    public String getNumero_factura() {
        return numero_factura;
    }

    public void setNumero_factura(String numero_factura) {
        this.numero_factura = numero_factura;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_sede() {
        return id_sede;
    }

    public void setId_sede(int id_sede) {
        this.id_sede = id_sede;
    }

    public int getId_membresia() {
        return id_membresia;
    }

    public void setId_membresia(int id_membresia) {
        this.id_membresia = id_membresia;
    }

    public Date getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(Date fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public Date getFecha_vencimiento() {
        return fecha_vencimiento;
    }

    public void setFecha_vencimiento(Date fecha_vencimiento) {
        this.fecha_vencimiento = fecha_vencimiento;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getEmitida_por() {
        return emitida_por;
    }

    public void setEmitida_por(int emitida_por) {
        this.emitida_por = emitida_por;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "facturas{" + "id_factura=" + id_factura + ", numero_factura=" + numero_factura + ", id_cliente=" + id_cliente + ", id_sede=" + id_sede + ", id_membresia=" + id_membresia + ", fecha_emision=" + fecha_emision + ", fecha_vencimiento=" + fecha_vencimiento + ", subtotal=" + subtotal + ", descuento=" + descuento + ", impuesto=" + impuesto + ", total=" + total + ", estado=" + estado + ", emitida_por=" + emitida_por + ", observaciones=" + observaciones + '}';
    }
}