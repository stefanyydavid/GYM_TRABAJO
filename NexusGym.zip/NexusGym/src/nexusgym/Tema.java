package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;

/**
 * Tema visual compartido de NexusGym (mismo estilo que PaginaPrincipal).
 */
public final class Tema {

    private Tema() {
    }

    // ==========================================================
    // COLORES
    // ==========================================================

    public static final Color NARANJA = new Color(232, 106, 36);
    public static final Color NARANJA_CLARO = new Color(247, 138, 64);
    public static final Color NARANJA_OSCURO = new Color(196, 82, 18);
    public static final Color CREMA = new Color(240, 232, 218);
    public static final Color FONDO = new Color(13, 15, 20);
    public static final Color SUPERFICIE = new Color(20, 24, 32);
    public static final Color TARJETA = new Color(25, 30, 40);
    public static final Color CAMPO = new Color(16, 19, 26);
    public static final Color BORDE = new Color(45, 52, 64);
    public static final Color TEXTO_SEC = new Color(170, 176, 188);
    public static final Color ERROR = new Color(255, 107, 107);
    public static final Color EXITO = new Color(86, 210, 125);

    public enum Estilo { PRIMARIO, SECUNDARIO, FANTASMA }

    private static boolean instalado = false;

    public static void instalar() {

        if (instalado) {
            return;
        }

        FlatDarkLaf.setup();

        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 12);
        UIManager.put("TextComponent.arc", 12);
        UIManager.put("Component.focusColor", NARANJA);
        UIManager.put("Component.focusedBorderColor", NARANJA);
        UIManager.put("Component.borderColor", BORDE);
        UIManager.put("ComboBox.background", CAMPO);
        UIManager.put("ComboBox.selectionBackground", NARANJA);
        UIManager.put("ComboBox.buttonArrowColor", NARANJA_CLARO);
        UIManager.put("ScrollBar.width", 10);
        UIManager.put("ScrollBar.thumbArc", 999);
        UIManager.put("ScrollBar.trackArc", 999);
        UIManager.put("ScrollBar.thumb", new Color(60, 68, 82));
        UIManager.put("ScrollBar.track", new Color(0, 0, 0, 0));
        UIManager.put("ProgressBar.foreground", NARANJA);

        instalado = true;
    }

    public static Font f(int estilo, int tam) {
        return new Font("Segoe UI", estilo, tam);
    }

    public static String esc(String s) {

        if (s == null) {
            return "";
        }

        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    // ==========================================================
    // FONDO CON RESPLANDOR
    // ==========================================================

    public static class Fondo extends JPanel {

        public Fondo() {
            super(new BorderLayout());
            setOpaque(true);
            setBackground(FONDO);
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            int w = getWidth();
            int h = getHeight();

            g2.setPaint(new RadialGradientPaint(
                    new Point2D.Float(w, 0),
                    Math.max(w, h) * 0.55f,
                    new float[]{0f, 1f},
                    new Color[]{
                        new Color(232, 106, 36, 34),
                        new Color(232, 106, 36, 0)
                    }
            ));

            g2.fillRect(0, 0, w, h);
            g2.dispose();
        }
    }

    // ==========================================================
    // TARJETA REDONDEADA
    // ==========================================================

    public static class Tarjeta extends JPanel {

        private final int radio;
        private final Color relleno;
        private final Color borde;
        private boolean hover = false;

        public Tarjeta(int radio, Color relleno, Color borde, boolean interactiva) {

            this.radio = radio;
            this.relleno = relleno;
            this.borde = borde;

            setOpaque(false);

            if (interactiva) {

                addMouseListener(new MouseAdapter() {

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        hover = true;
                        repaint();
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        hover = getMousePosition(true) != null;
                        repaint();
                    }
                });
            }
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(relleno);
            g2.fill(new RoundRectangle2D.Double(
                    0, 0, getWidth() - 1, getHeight() - 1, radio, radio
            ));

            g2.setColor(hover ? NARANJA : borde);
            g2.setStroke(new BasicStroke(hover ? 1.6f : 1f));
            g2.draw(new RoundRectangle2D.Double(
                    0.5, 0.5, getWidth() - 2, getHeight() - 2, radio, radio
            ));

            g2.dispose();

            super.paintComponent(g);
        }
    }

    // ==========================================================
    // BOTÓN
    // ==========================================================

    public static class Boton extends JButton {

        private final Estilo estilo;
        private boolean hover = false;
        private boolean presionado = false;

        public Boton(String texto, Estilo estilo) {

            super(texto);

            this.estilo = estilo;

            setFont(f(Font.BOLD, 13));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            setForeground(
                    estilo == Estilo.PRIMARIO
                            ? Color.WHITE
                            : estilo == Estilo.FANTASMA
                                    ? NARANJA_CLARO
                                    : CREMA
            );

            addMouseListener(new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    presionado = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    presionado = true;
                    repaint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    presionado = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            RoundRectangle2D.Double forma = new RoundRectangle2D.Double(
                    0, 0, getWidth() - 1, getHeight() - 1, 12, 12
            );

            switch (estilo) {

                case PRIMARIO -> {

                    g2.setColor(
                            !isEnabled()
                                    ? new Color(90, 60, 45)
                                    : presionado
                                            ? NARANJA_OSCURO
                                            : hover ? NARANJA_CLARO : NARANJA
                    );

                    g2.fill(forma);
                }

                case SECUNDARIO -> {

                    g2.setColor(
                            hover
                                    ? new Color(255, 255, 255, 26)
                                    : new Color(255, 255, 255, 12)
                    );

                    g2.fill(forma);

                    g2.setColor(hover ? NARANJA : BORDE);
                    g2.draw(forma);
                }

                case FANTASMA -> {

                    if (hover) {
                        g2.setColor(new Color(232, 106, 36, 28));
                        g2.fill(forma);
                    }
                }
            }

            g2.dispose();

            super.paintComponent(g);
        }
    }

    // ==========================================================
    // INSIGNIA NUMERADA
    // ==========================================================

    public static class Insignia extends JComponent {

        private final String texto;
        private final int tam;

        public Insignia(String texto, int tam) {

            this.texto = texto;
            this.tam = tam;

            Dimension d = new Dimension(tam, tam);

            setPreferredSize(d);
            setMinimumSize(d);
            setMaximumSize(d);
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );
            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            g2.setColor(new Color(232, 106, 36, 40));
            g2.fill(new RoundRectangle2D.Double(0, 0, tam - 1, tam - 1, 14, 14));

            g2.setColor(new Color(232, 106, 36, 120));
            g2.draw(new RoundRectangle2D.Double(0.5, 0.5, tam - 2, tam - 2, 14, 14));

            g2.setColor(NARANJA_CLARO);
            g2.setFont(f(Font.BOLD, tam / 3 + 2));

            FontMetrics fm = g2.getFontMetrics();

            g2.drawString(
                    texto,
                    (tam - fm.stringWidth(texto)) / 2,
                    (tam - fm.getHeight()) / 2 + fm.getAscent()
            );

            g2.dispose();
        }
    }

    // ==========================================================
    // CAMPOS
    // ==========================================================

    public static JTextField campo(String placeholder) {

        JTextField c = new JTextField();
        estilizar(c, placeholder);
        return c;
    }

    public static JPasswordField password(String placeholder) {

        JPasswordField c = new JPasswordField();
        c.putClientProperty("JPasswordField.showRevealButton", true);
        estilizar(c, placeholder);
        return c;
    }

    private static void estilizar(JTextField c, String placeholder) {

        c.setFont(f(Font.PLAIN, 14));
        c.setForeground(CREMA);
        c.setBackground(CAMPO);
        c.setCaretColor(NARANJA_CLARO);
        c.setSelectionColor(NARANJA);
        c.putClientProperty("JTextField.placeholderText", placeholder);
        c.putClientProperty("JTextField.padding", new Insets(8, 12, 8, 12));
        c.setPreferredSize(new Dimension(200, 42));
    }

    public static JComboBox<String> combo(String[] items) {

        JComboBox<String> cb = new JComboBox<>(items);

        cb.setFont(f(Font.PLAIN, 14));
        cb.setBackground(CAMPO);
        cb.setForeground(CREMA);
        cb.setPreferredSize(new Dimension(200, 42));
        cb.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        return cb;
    }

    public static JPanel bloque(String titulo, JComponent comp) {

        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setOpaque(false);

        JLabel l = new JLabel(titulo.toUpperCase());
        l.setFont(f(Font.BOLD, 11));
        l.setForeground(NARANJA_CLARO);

        p.add(l, BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);

        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height)
        );

        return p;
    }

    // ==========================================================
    // LOGO / ENCABEZADOS
    // ==========================================================

    public static JLabel logo(int size) {

        JLabel l = new JLabel(
                "<html><span style='color:#F0E8DA'>NEXUS</span> "
                + "<span style='color:#E86A24'>GYM</span></html>"
        );

        l.setFont(f(Font.BOLD, size));

        return l;
    }

    private static JPanel celda(JComponent c, int anchor) {

        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);

        GridBagConstraints gc = new GridBagConstraints();
        gc.weightx = 1;
        gc.weighty = 1;
        gc.anchor = anchor;

        p.add(c, gc);

        return p;
    }

    public static JPanel header(String titulo, ActionListener volver) {

        JPanel h = new JPanel(new GridLayout(1, 3)) {

            @Override
            protected void paintComponent(Graphics g) {

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setColor(SUPERFICIE);
                g2.fillRect(0, 0, getWidth(), getHeight());

                g2.setColor(BORDE);
                g2.fillRect(0, getHeight() - 1, getWidth(), 1);

                g2.setPaint(new GradientPaint(
                        0, 0, NARANJA,
                        getWidth() * 0.45f, 0, new Color(232, 106, 36, 0)
                ));

                g2.fillRect(0, getHeight() - 2, getWidth(), 2);

                g2.dispose();
            }
        };

        h.setPreferredSize(new Dimension(100, 72));
        h.setBorder(BorderFactory.createEmptyBorder(0, 32, 0, 32));

        JLabel t = new JLabel(titulo, SwingConstants.CENTER);
        t.setFont(f(Font.BOLD, 17));
        t.setForeground(CREMA);

        Boton b = new Boton("←  VOLVER", Estilo.SECUNDARIO);
        b.setPreferredSize(new Dimension(130, 40));
        b.addActionListener(volver);

        h.add(celda(logo(25), GridBagConstraints.WEST));
        h.add(t);
        h.add(celda(b, GridBagConstraints.EAST));

        return h;
    }

    public static JPanel encabezadoSeccion(
            String titulo,
            String subtitulo,
            JComponent derecha) {

        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(26, 40, 12, 40));

        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));

        JLabel t = new JLabel(titulo);
        t.setFont(f(Font.BOLD, 30));
        t.setForeground(CREMA);

        JLabel s = new JLabel(subtitulo);
        s.setFont(f(Font.PLAIN, 14));
        s.setForeground(TEXTO_SEC);

        textos.add(t);
        textos.add(Box.createVerticalStrut(4));
        textos.add(s);

        p.add(textos, BorderLayout.WEST);

        if (derecha != null) {
            p.add(derecha, BorderLayout.EAST);
        }

        return p;
    }

    public static JScrollPane scroll(JComponent contenido) {

        JPanel envoltura = new JPanel(new BorderLayout());
        envoltura.setOpaque(false);
        envoltura.add(contenido, BorderLayout.NORTH);

        JScrollPane sp = new JScrollPane(
                envoltura,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
        );

        sp.setBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(16);

        return sp;
    }

    // ==========================================================
    // PANEL DE MARCA (lado izquierdo de Login / Registro)
    // ==========================================================

    public static class PanelMarca extends JPanel {

        public PanelMarca(int ancho, String titularHtml, String[] puntos) {

            setPreferredSize(new Dimension(ancho, 100));
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(BorderFactory.createEmptyBorder(56, 46, 34, 40));

            JLabel logo = logo(34);
            logo.setAlignmentX(Component.LEFT_ALIGNMENT);

            add(logo);
            add(Box.createVerticalGlue());

            JLabel titular = new JLabel("<html>" + titularHtml + "</html>");
            titular.setFont(f(Font.BOLD, 34));
            titular.setForeground(CREMA);
            titular.setAlignmentX(Component.LEFT_ALIGNMENT);

            add(titular);
            add(Box.createVerticalStrut(28));

            for (String p : puntos) {

                JLabel l = new JLabel(
                        "<html><span style='color:#E86A24'>&#9679;</span>"
                        + "&nbsp;&nbsp;" + p + "</html>"
                );

                l.setFont(f(Font.PLAIN, 14));
                l.setForeground(TEXTO_SEC);
                l.setAlignmentX(Component.LEFT_ALIGNMENT);

                add(l);
                add(Box.createVerticalStrut(12));
            }

            add(Box.createVerticalGlue());

            JLabel copy = new JLabel("NexusGym © 2026");
            copy.setFont(f(Font.PLAIN, 12));
            copy.setForeground(new Color(110, 116, 128));
            copy.setAlignmentX(Component.LEFT_ALIGNMENT);

            add(copy);
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            int w = getWidth();
            int h = getHeight();

            g2.setPaint(new GradientPaint(
                    0, 0, new Color(26, 31, 42),
                    0, h, new Color(11, 13, 18)
            ));
            g2.fillRect(0, 0, w, h);

            g2.setPaint(new RadialGradientPaint(
                    new Point2D.Float(0, h),
                    h * 0.95f,
                    new float[]{0f, 1f},
                    new Color[]{
                        new Color(232, 106, 36, 85),
                        new Color(232, 106, 36, 0)
                    }
            ));
            g2.fillRect(0, 0, w, h);

            g2.setColor(new Color(255, 255, 255, 10));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawOval(w - 190, -110, 320, 320);
            g2.drawOval(w - 270, -190, 480, 480);

            g2.setColor(BORDE);
            g2.fillRect(w - 1, 0, 1, h);

            g2.dispose();
        }
    }

    // ==========================================================
    // DIÁLOGO DE MENSAJE (mismo look del "Sección en proceso")
    // ==========================================================

    public static void mensaje(
            Component padre,
            String etiqueta,
            String titulo,
            String cuerpoHtml,
            boolean error) {

        Window ventana = null;

        if (padre instanceof Window) {
            ventana = (Window) padre;
        } else if (padre != null) {
            ventana = SwingUtilities.getWindowAncestor(padre);
        }

        JDialog dialogo = new JDialog(ventana, Dialog.ModalityType.APPLICATION_MODAL);

        dialogo.setUndecorated(true);
        dialogo.setBackground(new Color(0, 0, 0, 0));

        final Color acento = error ? ERROR : NARANJA;

        JPanel panel = new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                g2.setPaint(new GradientPaint(
                        0, 0, new Color(30, 36, 46),
                        0, getHeight(), new Color(13, 15, 20)
                ));

                g2.fillRoundRect(
                        0, 0, getWidth() - 1, getHeight() - 1, 28, 28
                );

                g2.setColor(acento);
                g2.setStroke(new BasicStroke(2f));

                g2.drawRoundRect(
                        1, 1, getWidth() - 3, getHeight() - 3, 28, 28
                );

                g2.dispose();

                super.paintComponent(g);
            }
        };

        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 44, 30, 44));

        JLabel lblEtiqueta = new JLabel(etiqueta);
        lblEtiqueta.setFont(f(Font.BOLD, 13));
        lblEtiqueta.setForeground(acento);
        lblEtiqueta.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblTitulo = new JLabel(
                "<html><div style='text-align:center;width:340px'>"
                + esc(titulo) + "</div></html>"
        );
        lblTitulo.setFont(f(Font.BOLD, 26));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblCuerpo = new JLabel(
                "<html><div style='text-align:center;width:340px'>"
                + cuerpoHtml + "</div></html>"
        );
        lblCuerpo.setFont(f(Font.PLAIN, 14));
        lblCuerpo.setForeground(new Color(190, 196, 208));
        lblCuerpo.setAlignmentX(Component.CENTER_ALIGNMENT);

        Boton cerrar = new Boton("ENTENDIDO", Estilo.PRIMARIO);
        cerrar.setPreferredSize(new Dimension(180, 42));
        cerrar.setMaximumSize(new Dimension(180, 42));
        cerrar.setAlignmentX(Component.CENTER_ALIGNMENT);
        cerrar.addActionListener(e -> dialogo.dispose());

        panel.add(lblEtiqueta);
        panel.add(Box.createVerticalStrut(8));
        panel.add(lblTitulo);
        panel.add(Box.createVerticalStrut(14));
        panel.add(lblCuerpo);
        panel.add(Box.createVerticalStrut(26));
        panel.add(cerrar);

        dialogo.setContentPane(panel);

        dialogo.getRootPane().registerKeyboardAction(
                e -> dialogo.dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        dialogo.getRootPane().setDefaultButton(cerrar);

        dialogo.pack();
        dialogo.setLocationRelativeTo(padre);
        dialogo.setVisible(true);
    }
}