package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Acceso exclusivo del administrador de Nexus Gym.
 * Abrir con: new IniciodesesionAdmin().setVisible(true);
 * Requiere haber ejecutado el script SQL de la tabla `administradores`.
 */
public class IniciodesesionAdmin extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color NARANJA_CLARO = new Color(255, 139, 62);
    private static final Color FONDO = new Color(13, 15, 20);
    private static final Color PANEL = new Color(22, 25, 32);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color GRIS = new Color(150, 152, 158);
    private static final Color ROJO = new Color(214, 69, 65);
    private static final Color VERDE = new Color(102, 165, 88);

    private static final int MAX_INTENTOS_MINUTOS_INACTIVIDAD = 10;

    private static final String[][] SECCIONES = {
            {"Clientes / Usuarios", "clientes"},
            {"Membresías / Suscripciones", "membresias"},
            {"Planes", "planes"},
            {"Clases", "clases"},
            {"Horarios de clases", "horarios_clases"},
            {"Reservas de clases", "reservas_clases"},
            {"Ingresos y salidas", "asistencias"},
            {"Pagos", "pagos"},
            {"Facturas", "facturas"},
            {"Detalle de facturas", "factura_detalles"},
            {"Devoluciones", "devoluciones"},
            {"Entrenadores", "entrenadores"},
            {"Sedes", "sedes"},
            {"Rutinas", "rutinas"},
            {"Ejercicios de rutinas", "rutina_ejercicios"},
            {"Catálogo de ejercicios", "ejercicios"},
            {"Incidencias", "incidencias"},
            {"Contactos de emergencia", "contactos_emergencia"},
            {"Historial de membresías", "historial_membresias"},
            {"Usuarios internos", "usuarios_internos"},
            {"Roles", "roles"},
            {"Usuarios y roles", "usuarios_roles"},
            {"Métodos de pago", "metodos_pago"},
            {"Configuración", "configuracion"},
            {"Auditoría", "auditoria"}
    };

    // tabla -> {columna, valor nuevo, texto del botón}
    private static final Map<String, String[]> ACCIONES = new HashMap<>();
    static {
        ACCIONES.put("membresias", new String[]{"estado", "CANCELADA", "CANCELAR SUSCRIPCIÓN"});
        ACCIONES.put("reservas_clases", new String[]{"estado", "CANCELADA", "CANCELAR RESERVA"});
        ACCIONES.put("facturas", new String[]{"estado", "ANULADA", "ANULAR FACTURA"});
        ACCIONES.put("pagos", new String[]{"estado", "ANULADO", "ANULAR PAGO"});
        ACCIONES.put("planes", new String[]{"activo", "0", "DESACTIVAR PLAN"});
        ACCIONES.put("clases", new String[]{"activo", "0", "DESACTIVAR CLASE"});
        ACCIONES.put("horarios_clases", new String[]{"activo", "0", "DESACTIVAR HORARIO"});
        ACCIONES.put("sedes", new String[]{"activo", "0", "DESACTIVAR SEDE"});
        ACCIONES.put("clientes", new String[]{"estado", "INACTIVO", "DAR DE BAJA"});
        ACCIONES.put("usuarios_internos", new String[]{"estado", "INACTIVO", "DESACTIVAR USUARIO"});
        ACCIONES.put("entrenadores", new String[]{"estado", "INACTIVO", "DAR DE BAJA"});
        ACCIONES.put("rutinas", new String[]{"estado", "CANCELADA", "CANCELAR RUTINA"});
        ACCIONES.put("incidencias", new String[]{"estado", "CERRADA", "CERRAR CASO"});
    }

    private static final Set<String> ESTADOS_BUENOS = new HashSet<>(Arrays.asList(
            "ACTIVA", "ACTIVO", "APROBADO", "PAGADA", "ASISTIO", "FINALIZADA", "RESUELTA", "PROCESADA", "APROBADA"));
    private static final Set<String> ESTADOS_MALOS = new HashSet<>(Arrays.asList(
            "CANCELADA", "INACTIVO", "ANULADO", "ANULADA", "RETIRADO", "VENCIDA", "RECHAZADA",
            "SUSPENDIDO", "SUSPENDIDA", "NO_ASISTIO"));

    private record Col(String nombre, boolean autoInc, boolean nulo, String tipo) { }

    private final CardLayout cartas = new CardLayout();
    private final JPanel raiz = new JPanel(cartas);

    // Login
    private JTextField campoEmail;
    private JPasswordField campoPass;
    private JLabel lblError;
    private BotonNx btnIngresar;

    // Panel
    private String adminEmail;
    private JLabel lblAdmin;
    private JList<String> listaSecciones;
    private JTable tabla;
    private DefaultTableModel modelo = new DefaultTableModel();
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField buscador;
    private JLabel lblTitulo;
    private JLabel lblConteo;
    private final Tile[] stats = new Tile[4];
    private BotonNx btnAccion;
    private String tablaActual = SECCIONES[0][1];
    private javax.swing.Timer temporizador;
    private AWTEventListener oyente;

    public IniciodesesionAdmin() {
        setTitle("Nexus Gym | Administración");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        raiz.add(crearLogin(), "login");
        raiz.add(crearPanel(), "panel");
        setContentPane(raiz);
        setSize(1280, 760);
        setMinimumSize(new Dimension(1000, 620));
        setLocationRelativeTo(null);
        cartas.show(raiz, "login");
    }

    // =====================================================================
    //  ESTILO
    // =====================================================================

    private static String familiaFuente;

    private static Font fuente(int estilo, int tam) {
        if (familiaFuente == null) {
            Set<String> disp = new HashSet<>(Arrays.asList(GraphicsEnvironment
                    .getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
            familiaFuente = "SansSerif";
            for (String f : new String[]{"Montserrat", "Poppins", "Roboto", "Segoe UI", "Helvetica Neue"}) {
                if (disp.contains(f)) {
                    familiaFuente = f;
                    break;
                }
            }
        }
        return new Font(familiaFuente, estilo, tam);
    }

    private static Font espaciado(Font f, float tracking) {
        Map<java.awt.font.TextAttribute, Object> m = new HashMap<>();
        m.put(java.awt.font.TextAttribute.TRACKING, tracking);
        return f.deriveFont(m);
    }

    private static void calidad(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    private static JLabel etiqueta(String texto, Font f, Color c) {
        JLabel l = new JLabel(texto);
        l.setFont(f);
        l.setForeground(c);
        return l;
    }

    private static class BotonNx extends JButton {
        private final int variante; // 0 naranja, 1 contorno, 2 peligro
        private boolean hover;

        BotonNx(String texto, int variante) {
            super(texto);
            this.variante = variante;
            setFont(espaciado(fuente(Font.BOLD, 12), 0.08f));
            setForeground(Color.WHITE);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(Math.max(110, fm.stringWidth(getText()) + 44), 40);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            if (!isEnabled()) {
                g2.setComposite(AlphaComposite.SrcOver.derive(0.45f));
            }
            RoundRectangle2D r = new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 12, 12);
            if (variante == 1) {
                g2.setColor(hover ? new Color(232, 106, 36, 50) : new Color(255, 255, 255, 8));
                g2.fill(r);
                g2.setColor(hover ? NARANJA : new Color(232, 106, 36, 170));
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Double(1.5, 1.5, w - 3, h - 3, 12, 12));
            } else {
                Color a = variante == 2 ? new Color(232, 90, 84) : NARANJA_CLARO;
                Color b = variante == 2 ? new Color(176, 48, 44) : new Color(214, 92, 24);
                if (hover) {
                    a = a.brighter();
                }
                if (getModel().isPressed()) {
                    a = b;
                }
                g2.setPaint(new GradientPaint(0, 0, a, 0, h, b));
                g2.fill(r);
                g2.setColor(new Color(255, 255, 255, 55));
                g2.setStroke(new BasicStroke(1f));
                g2.draw(new RoundRectangle2D.Double(1.5, 1.5, w - 3, h - 3, 12, 12));
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class Tile extends JPanel {
        private String valor = "—";
        private final String titulo;

        Tile(String titulo) {
            this.titulo = titulo;
            setOpaque(false);
            setPreferredSize(new Dimension(200, 84));
        }

        void setValor(String v) {
            valor = v;
            repaint();
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 16, 16);
            g2.setPaint(new GradientPaint(0, 0, new Color(38, 42, 52), 0, h, new Color(22, 25, 32)));
            g2.fill(r);
            g2.setColor(new Color(255, 255, 255, 30));
            g2.draw(r);
            g2.setColor(NARANJA);
            g2.fillRoundRect(0, 18, 4, h - 36, 4, 4);
            g2.setFont(fuente(Font.BOLD, 26));
            g2.setColor(CREMA);
            g2.drawString(valor, 20, 40);
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.12f));
            g2.setColor(GRIS);
            g2.drawString(titulo, 20, 62);
            g2.dispose();
        }
    }

    private static class CabeceraRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean s,
                                                                 boolean f, int r, int c) {
            super.getTableCellRendererComponent(t,
                    v == null ? "" : v.toString().toUpperCase().replace('_', ' '), false, false, r, c);
            setBackground(new Color(18, 20, 25));
            setForeground(NARANJA);
            setFont(espaciado(fuente(Font.BOLD, 11), 0.08f));
            setHorizontalAlignment(LEFT);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 2, 0, NARANJA),
                    BorderFactory.createEmptyBorder(0, 10, 0, 10)));
            return this;
        }
    }

    private static class CeldaRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                 boolean foco, int r, int c) {
            String col = t.getColumnName(c).toLowerCase();
            String texto = v == null ? "" : v.toString();
            if (col.equals("password_hash") || col.equals("salt")) {
                texto = "••••••••";
            }
            super.getTableCellRendererComponent(t, texto, sel, false, r, c);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            setFont(fuente(Font.PLAIN, 12));
            if (sel) {
                setBackground(new Color(92, 52, 30));
                setForeground(Color.WHITE);
            } else {
                setBackground(r % 2 == 0 ? new Color(22, 25, 32) : new Color(27, 31, 40));
                setForeground(CREMA);
                if (ESTADOS_BUENOS.contains(texto)) {
                    setForeground(VERDE);
                } else if (ESTADOS_MALOS.contains(texto)) {
                    setForeground(new Color(232, 100, 92));
                }
            }
            return this;
        }
    }

    private void estilizarCampo(JTextField c, String placeholder) {
        c.setFont(fuente(Font.PLAIN, 14));
        c.putClientProperty("JTextField.placeholderText", placeholder);
        c.putClientProperty("JComponent.roundRect", true);
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setPreferredSize(new Dimension(360, 44));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
    }

    // =====================================================================
    //  LOGIN
    // =====================================================================

    private JPanel crearLogin() {
        JPanel fondo = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                calidad(g2);
                int w = getWidth();
                int h = getHeight();
                g2.setPaint(new GradientPaint(0, 0, new Color(8, 10, 14), w, h, new Color(30, 34, 44)));
                g2.fillRect(0, 0, w, h);
                g2.setPaint(new RadialGradientPaint(new Point2D.Float(w * 0.8f, h * 0.15f),
                        Math.max(w, h) * 0.5f, new float[]{0f, 1f},
                        new Color[]{new Color(232, 106, 36, 70), new Color(232, 106, 36, 0)}));
                g2.fillRect(0, 0, w, h);
                Path2D.Double p = new Path2D.Double();
                p.moveTo(w * 0.08, h * 0.30);
                p.lineTo(w * 0.22, h * 0.12);
                p.lineTo(w * 0.34, h * 0.36);
                p.lineTo(w * 0.17, h * 0.52);
                p.closePath();
                float[] anchos = {12f, 6f, 2.5f};
                int[] alfas = {16, 34, 170};
                for (int i = 0; i < anchos.length; i++) {
                    g2.setStroke(new BasicStroke(anchos[i], BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g2.setColor(new Color(255, 255, 255, alfas[i]));
                    g2.draw(p);
                }
                g2.dispose();
            }
        };

        final int M = 16;
        JPanel tarjeta = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                calidad(g2);
                int w = getWidth();
                int h = getHeight();
                for (int k = 0; k < M; k++) {
                    g2.setColor(new Color(0, 0, 0, 7));
                    g2.fill(new RoundRectangle2D.Double(M - k, M - k + 5, w - 2 * M + 2 * k,
                            h - 2 * M + 2 * k, 24 + k, 24 + k));
                }
                RoundRectangle2D forma = new RoundRectangle2D.Double(M, M, w - 2 * M, h - 2 * M, 24, 24);
                g2.setPaint(new GradientPaint(0, M, new Color(26, 29, 38), 0, h - M, new Color(12, 14, 18)));
                g2.fill(forma);
                g2.setColor(new Color(255, 255, 255, 40));
                g2.draw(forma);
                g2.setClip(forma);
                g2.setColor(NARANJA);
                g2.fillRect(M, M, w - 2 * M, 4);
                g2.dispose();
            }
        };
        tarjeta.setOpaque(false);
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(BorderFactory.createEmptyBorder(M + 34, M + 38, M + 30, M + 38));

        JLabel marca = etiqueta("NEXUS GYM", espaciado(fuente(Font.BOLD, 13), 0.25f), NARANJA);
        JLabel titulo = etiqueta("Acceso administrador", fuente(Font.BOLD, 26), CREMA);
        JLabel sub = etiqueta("Área restringida · toda actividad queda registrada", fuente(Font.PLAIN, 12), GRIS);
        for (JComponent c : new JComponent[]{marca, titulo, sub}) {
            c.setAlignmentX(Component.LEFT_ALIGNMENT);
        }
        tarjeta.add(marca);
        tarjeta.add(Box.createVerticalStrut(8));
        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(4));
        tarjeta.add(sub);
        tarjeta.add(Box.createVerticalStrut(26));

        JLabel l1 = etiqueta("CORREO", espaciado(fuente(Font.BOLD, 10), 0.15f), NARANJA);
        l1.setAlignmentX(Component.LEFT_ALIGNMENT);
        campoEmail = new JTextField();
        estilizarCampo(campoEmail, "admin@correo.com");
        JLabel l2 = etiqueta("CONTRASEÑA", espaciado(fuente(Font.BOLD, 10), 0.15f), NARANJA);
        l2.setAlignmentX(Component.LEFT_ALIGNMENT);
        campoPass = new JPasswordField();
        estilizarCampo(campoPass, "••••••••");
        campoPass.putClientProperty("JPasswordField.showRevealButton", true);

        tarjeta.add(l1);
        tarjeta.add(Box.createVerticalStrut(6));
        tarjeta.add(campoEmail);
        tarjeta.add(Box.createVerticalStrut(16));
        tarjeta.add(l2);
        tarjeta.add(Box.createVerticalStrut(6));
        tarjeta.add(campoPass);
        tarjeta.add(Box.createVerticalStrut(10));

        lblError = etiqueta(" ", fuente(Font.PLAIN, 12), new Color(232, 100, 92));
        lblError.setAlignmentX(Component.LEFT_ALIGNMENT);
        tarjeta.add(lblError);
        tarjeta.add(Box.createVerticalStrut(12));

        btnIngresar = new BotonNx("INGRESAR", 0);
        btnIngresar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnIngresar.setPreferredSize(new Dimension(360, 46));
        btnIngresar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        btnIngresar.addActionListener(e -> intentarLogin());
        BotonNx btnVolver = new BotonNx("VOLVER AL INICIO DE SESIÓN", 1);
        btnVolver.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnVolver.setPreferredSize(new Dimension(360, 42));
        btnVolver.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnVolver.addActionListener(e -> {
            detenerInactividad();
            LoginNuevo l = new LoginNuevo();
            l.setLocationRelativeTo(null);
            l.setVisible(true);
            dispose();
        });
        tarjeta.add(btnIngresar);
        tarjeta.add(Box.createVerticalStrut(10));
        tarjeta.add(btnVolver);

        campoEmail.addActionListener(e -> campoPass.requestFocusInWindow());
        campoPass.addActionListener(e -> intentarLogin());

        tarjeta.setPreferredSize(new Dimension(500 + 2 * M, 520 + 2 * M));
        fondo.add(tarjeta);
        return fondo;
    }

    private static String sha256(String salt, char[] clave) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest((salt + new String(clave)).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private void fallo(String mensaje) {
        lblError.setText(mensaje);
        btnIngresar.setEnabled(false);
        javax.swing.Timer t = new javax.swing.Timer(1200, e -> btnIngresar.setEnabled(true));
        t.setRepeats(false);
        t.start();
    }

    private void intentarLogin() {
        if (!btnIngresar.isEnabled()) {
            return;
        }
        String email = campoEmail.getText().trim().toLowerCase();
        char[] clave = campoPass.getPassword();
        try {
            if (!email.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$") || clave.length == 0) {
                fallo("Credenciales inválidas.");
                return;
            }
            Connection cx = Conexion.getInstancia().conectar();
            if (cx == null) {
                fallo("No hay conexión con la base de datos.");
                return;
            }
            int id = -1;
            String salt = "x";
            String hashBd = "";
            boolean activo = false;
            boolean bloqueado = false;
            String sel = "SELECT id_admin, salt, password_hash, activo, "
                    + "(bloqueado_hasta IS NOT NULL AND bloqueado_hasta > NOW()) AS bloqueado "
                    + "FROM administradores WHERE email = ?";
            try (PreparedStatement ps = cx.prepareStatement(sel)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        id = rs.getInt("id_admin");
                        salt = rs.getString("salt");
                        hashBd = rs.getString("password_hash");
                        activo = rs.getInt("activo") == 1;
                        bloqueado = rs.getInt("bloqueado") == 1;
                    }
                }
            }
            String calculado = sha256(salt, clave);
            boolean iguales = MessageDigest.isEqual(calculado.getBytes(StandardCharsets.UTF_8),
                    hashBd.getBytes(StandardCharsets.UTF_8));
            if (id < 0) {
                fallo("Credenciales inválidas.");
                return;
            }
            if (bloqueado) {
                fallo("Acceso bloqueado temporalmente por intentos fallidos.");
                return;
            }
            if (activo && iguales) {
                try (PreparedStatement up = cx.prepareStatement(
                        "UPDATE administradores SET intentos_fallidos = 0, bloqueado_hasta = NULL, "
                                + "ultimo_acceso = NOW() WHERE id_admin = ?")) {
                    up.setInt(1, id);
                    up.executeUpdate();
                }
                abrirPanel(email);
            } else {
                try (PreparedStatement up = cx.prepareStatement(
                        "UPDATE administradores SET "
                                + "bloqueado_hasta = IF(intentos_fallidos + 1 >= 5, DATE_ADD(NOW(), INTERVAL 15 MINUTE), bloqueado_hasta), "
                                + "intentos_fallidos = intentos_fallidos + 1 WHERE id_admin = ?")) {
                    up.setInt(1, id);
                    up.executeUpdate();
                }
                fallo("Credenciales inválidas.");
            }
        } catch (SQLException ex) {
            fallo("No se pudo verificar el acceso: " + ex.getMessage());
        } finally {
            Arrays.fill(clave, '\0');
            campoPass.setText("");
        }
    }

    private void abrirPanel(String email) {
        adminEmail = email;
        lblAdmin.setText(email);
        lblError.setText(" ");
        auditar("LOGIN", "administradores", "0", "Inicio de sesión del administrador");
        listaSecciones.setSelectedIndex(0);
        cargarSeccion(0);
        cartas.show(raiz, "panel");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        iniciarInactividad();
    }

    private void cerrarSesion(String mensaje) {
        if (adminEmail != null) {
            auditar("LOGOUT", "administradores", "0", "Cierre de sesión del administrador");
        }
        detenerInactividad();
        adminEmail = null;
        tabla.setModel(new DefaultTableModel());
        campoEmail.setText("");
        campoPass.setText("");
        lblError.setText(mensaje == null ? " " : mensaje);
        setExtendedState(JFrame.NORMAL);
        setSize(1280, 760);
        setLocationRelativeTo(null);
        cartas.show(raiz, "login");
    }

    private void iniciarInactividad() {
        detenerInactividad();
        temporizador = new javax.swing.Timer(MAX_INTENTOS_MINUTOS_INACTIVIDAD * 60 * 1000,
                e -> cerrarSesion("Sesión cerrada por inactividad."));
        temporizador.setRepeats(false);
        temporizador.start();
        oyente = ev -> {
            if (temporizador != null) {
                temporizador.restart();
            }
        };
        Toolkit.getDefaultToolkit().addAWTEventListener(oyente,
                AWTEvent.MOUSE_EVENT_MASK | AWTEvent.KEY_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK);
    }

    private void detenerInactividad() {
        if (temporizador != null) {
            temporizador.stop();
            temporizador = null;
        }
        if (oyente != null) {
            Toolkit.getDefaultToolkit().removeAWTEventListener(oyente);
            oyente = null;
        }
    }

    // =====================================================================
    //  PANEL DE ADMINISTRACIÓN
    // =====================================================================

    private JPanel crearPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(FONDO);

        // Barra superior
        JPanel barra = new JPanel(new BorderLayout());
        barra.setBackground(new Color(10, 12, 16));
        barra.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, NARANJA),
                BorderFactory.createEmptyBorder(10, 22, 10, 22)));
        JPanel izq = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        izq.setOpaque(false);
        izq.add(etiqueta("NEXUS GYM", espaciado(fuente(Font.BOLD, 20), 0.1f), CREMA));
        izq.add(etiqueta("PANEL DE ADMINISTRACIÓN", espaciado(fuente(Font.BOLD, 11), 0.2f), NARANJA));
        barra.add(izq, BorderLayout.WEST);
        JPanel der = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        der.setOpaque(false);
        lblAdmin = etiqueta("", fuente(Font.PLAIN, 12), GRIS);
        BotonNx btnSalir = new BotonNx("CERRAR SESIÓN", 1);
        btnSalir.addActionListener(e -> cerrarSesion(null));
        der.add(lblAdmin);
        der.add(btnSalir);
        barra.add(der, BorderLayout.EAST);
        p.add(barra, BorderLayout.NORTH);

        // Menú lateral
        DefaultListModel<String> lm = new DefaultListModel<>();
        for (String[] s : SECCIONES) {
            lm.addElement(s[0]);
        }
        listaSecciones = new JList<>(lm);
        listaSecciones.setBackground(PANEL);
        listaSecciones.setFixedCellHeight(40);
        listaSecciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listaSecciones.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i,
                                                                    boolean sel, boolean foco) {
                super.getListCellRendererComponent(l, v, i, sel, false);
                setFont(fuente(sel ? Font.BOLD : Font.PLAIN, 13));
                setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 10));
                setBackground(sel ? new Color(70, 42, 28) : PANEL);
                setForeground(sel ? NARANJA_CLARO : CREMA);
                return this;
            }
        });
        listaSecciones.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && listaSecciones.getSelectedIndex() >= 0) {
                cargarSeccion(listaSecciones.getSelectedIndex());
            }
        });
        JScrollPane spLista = new JScrollPane(listaSecciones);
        spLista.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(255, 255, 255, 25)));
        spLista.setPreferredSize(new Dimension(250, 100));
        p.add(spLista, BorderLayout.WEST);

        // Zona central
        JPanel centro = new JPanel(new BorderLayout(0, 12));
        centro.setBackground(FONDO);
        centro.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        JPanel norte = new JPanel();
        norte.setOpaque(false);
        norte.setLayout(new BoxLayout(norte, BoxLayout.Y_AXIS));

        JPanel cab = new JPanel(new BorderLayout());
        cab.setOpaque(false);
        lblTitulo = etiqueta("", fuente(Font.BOLD, 24), CREMA);
        lblConteo = etiqueta("", fuente(Font.PLAIN, 12), GRIS);
        cab.add(lblTitulo, BorderLayout.WEST);
        cab.add(lblConteo, BorderLayout.EAST);
        cab.setAlignmentX(Component.LEFT_ALIGNMENT);
        cab.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        norte.add(cab);
        norte.add(Box.createVerticalStrut(12));

        JPanel filaStats = new JPanel(new GridLayout(1, 4, 12, 0));
        filaStats.setOpaque(false);
        String[] titulos = {"CLIENTES", "MEMBRESÍAS ACTIVAS", "INGRESOS APROBADOS", "ENTRADAS REGISTRADAS"};
        for (int i = 0; i < 4; i++) {
            stats[i] = new Tile(titulos[i]);
            filaStats.add(stats[i]);
        }
        filaStats.setAlignmentX(Component.LEFT_ALIGNMENT);
        filaStats.setMaximumSize(new Dimension(Integer.MAX_VALUE, 84));
        norte.add(filaStats);
        norte.add(Box.createVerticalStrut(14));

        JPanel herr = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        herr.setOpaque(false);
        buscador = new JTextField(18);
        buscador.putClientProperty("JTextField.placeholderText", "Buscar en esta tabla…");
        buscador.putClientProperty("JComponent.roundRect", true);
        buscador.setFont(fuente(Font.PLAIN, 13));
        buscador.setPreferredSize(new Dimension(260, 40));
        buscador.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { aplicarFiltro(); }
            @Override public void removeUpdate(DocumentEvent e) { aplicarFiltro(); }
            @Override public void changedUpdate(DocumentEvent e) { aplicarFiltro(); }
        });
        BotonNx btnCrear = new BotonNx("+ CREAR", 0);
        btnCrear.addActionListener(e -> abrirFormulario(false));
        BotonNx btnEditar = new BotonNx("MODIFICAR", 1);
        btnEditar.addActionListener(e -> abrirFormulario(true));
        BotonNx btnBorrar = new BotonNx("ELIMINAR", 2);
        btnBorrar.addActionListener(e -> eliminar());
        btnAccion = new BotonNx("CANCELAR", 1);
        btnAccion.addActionListener(e -> accionEstado());
        BotonNx btnRef = new BotonNx("ACTUALIZAR", 1);
        btnRef.addActionListener(e -> {
            recargarTabla();
            refrescarStats();
        });
        herr.add(buscador);
        herr.add(btnCrear);
        herr.add(btnEditar);
        herr.add(btnBorrar);
        herr.add(btnAccion);
        herr.add(btnRef);
        herr.setAlignmentX(Component.LEFT_ALIGNMENT);
        herr.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        norte.add(herr);
        centro.add(norte, BorderLayout.NORTH);

        tabla = new JTable(modelo);
        tabla.setRowHeight(32);
        tabla.setShowGrid(false);
        tabla.setShowHorizontalLines(true);
        tabla.setGridColor(new Color(255, 255, 255, 14));
        tabla.setIntercellSpacing(new Dimension(0, 1));
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tabla.setFillsViewportHeight(true);
        tabla.setBackground(PANEL);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setDefaultRenderer(Object.class, new CeldaRenderer());
        tabla.getTableHeader().setDefaultRenderer(new CabeceraRenderer());
        tabla.getTableHeader().setPreferredSize(new Dimension(100, 38));
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tabla.getSelectedRow() >= 0) {
                    abrirFormulario(true);
                }
            }
        });
        JScrollPane sp = new JScrollPane(tabla);
        sp.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 30)));
        sp.getViewport().setBackground(PANEL);
        centro.add(sp, BorderLayout.CENTER);

        p.add(centro, BorderLayout.CENTER);
        return p;
    }

    private void cargarSeccion(int idx) {
        tablaActual = SECCIONES[idx][1];
        lblTitulo.setText(SECCIONES[idx][0].toUpperCase());
        String[] ac = ACCIONES.get(tablaActual);
        btnAccion.setVisible(ac != null);
        if (ac != null) {
            btnAccion.setText(ac[2]);
        }
        buscador.setText("");
        recargarTabla();
        refrescarStats();
    }

    private void recargarTabla() {
        Connection cx = Conexion.getInstancia().conectar();
        if (cx == null) {
            aviso("No hay conexión con la base de datos.");
            return;
        }
        String sql = "SELECT * FROM `" + tablaActual + "` ORDER BY 1 DESC";
        try (PreparedStatement ps = cx.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();
            String[] cols = new String[n];
            for (int i = 0; i < n; i++) {
                cols[i] = md.getColumnLabel(i + 1);
            }
            DefaultTableModel m = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            while (rs.next()) {
                Object[] f = new Object[n];
                for (int i = 0; i < n; i++) {
                    String v = rs.getString(i + 1);
                    f[i] = v == null ? "" : v;
                }
                m.addRow(f);
            }
            modelo = m;
            tabla.setModel(m);
            sorter = new TableRowSorter<>(m);
            tabla.setRowSorter(sorter);
            ajustarColumnas();
            aplicarFiltro();
        } catch (SQLException ex) {
            aviso("No se pudo cargar la tabla:\n" + ex.getMessage());
        }
    }

    private void ajustarColumnas() {
        TableColumnModel cm = tabla.getColumnModel();
        FontMetrics fm = tabla.getFontMetrics(tabla.getFont());
        for (int c = 0; c < cm.getColumnCount(); c++) {
            int max = fm.stringWidth(String.valueOf(modelo.getColumnName(c))) + 44;
            int lim = Math.min(modelo.getRowCount(), 60);
            for (int r = 0; r < lim; r++) {
                max = Math.max(max, fm.stringWidth(String.valueOf(modelo.getValueAt(r, c))) + 30);
            }
            cm.getColumn(c).setPreferredWidth(Math.min(max, 340));
        }
    }

    private void aplicarFiltro() {
        if (sorter == null) {
            return;
        }
        String t = buscador.getText().trim();
        if (t.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(t)));
        }
        lblConteo.setText(tabla.getRowCount() + " registros");
    }

    private String escalar(String sql) {
        try {
            Connection cx = Conexion.getInstancia().conectar();
            try (PreparedStatement ps = cx.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : "0";
            }
        } catch (Exception e) {
            return "—";
        }
    }

    private void refrescarStats() {
        stats[0].setValor(escalar("SELECT COUNT(*) FROM clientes"));
        stats[1].setValor(escalar("SELECT COUNT(*) FROM membresias WHERE estado = 'ACTIVA'"));
        String ing = escalar("SELECT COALESCE(SUM(CAST(monto AS DECIMAL(14,2))), 0) FROM pagos WHERE estado = 'APROBADO'");
        try {
            ing = "$" + NumberFormat.getInstance(Locale.forLanguageTag("es-CO")).format((long) Double.parseDouble(ing));
        } catch (NumberFormatException ignorada) {
            ing = "—";
        }
        stats[2].setValor(ing);
        stats[3].setValor(escalar("SELECT COUNT(*) FROM asistencias"));
    }

    // =====================================================================
    //  CRUD GENÉRICO
    // =====================================================================

    private List<Col> columnas(String t) throws SQLException {
        List<Col> res = new ArrayList<>();
        Connection cx = Conexion.getInstancia().conectar();
        try (PreparedStatement ps = cx.prepareStatement("SELECT * FROM `" + t + "` LIMIT 0");
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++) {
                res.add(new Col(md.getColumnName(i), md.isAutoIncrement(i),
                        md.isNullable(i) != ResultSetMetaData.columnNoNulls,
                        md.getColumnTypeName(i).toUpperCase()));
            }
        }
        return res;
    }

    private List<String> claves(String t) throws SQLException {
        List<String> res = new ArrayList<>();
        Connection cx = Conexion.getInstancia().conectar();
        try (PreparedStatement ps = cx.prepareStatement("SHOW KEYS FROM `" + t + "` WHERE Key_name = 'PRIMARY'");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                res.add(rs.getString("Column_name"));
            }
        }
        return res;
    }

    private void aviso(String m) {
        JOptionPane.showMessageDialog(this, m, "Nexus Gym", JOptionPane.INFORMATION_MESSAGE);
    }

    private int filaModelo() {
        int f = tabla.getSelectedRow();
        if (f < 0) {
            aviso("Selecciona un registro de la tabla primero.");
            return -1;
        }
        return tabla.convertRowIndexToModel(f);
    }

    private String celda(int mr, String col) {
        try {
            return String.valueOf(modelo.getValueAt(mr, modelo.findColumn(col)));
        } catch (Exception e) {
            return "";
        }
    }

    private String mensajeSql(SQLException ex) {
        String m = ex.getMessage() == null ? "Error desconocido." : ex.getMessage();
        if (m.toLowerCase().contains("foreign key")) {
            return "Operación bloqueada: el registro tiene datos relacionados en otras tablas.";
        }
        return m;
    }

    private static String hint(String tipo) {
        if (tipo.contains("DATETIME") || tipo.contains("TIMESTAMP")) return "AAAA-MM-DD HH:MM:SS";
        if (tipo.contains("DATE")) return "AAAA-MM-DD";
        if (tipo.contains("TIME")) return "HH:MM:SS";
        if (tipo.contains("INT") || tipo.contains("DECIMAL")) return "número";
        return "texto";
    }

    private void abrirFormulario(boolean editar) {
        try {
            final List<Col> cols = columnas(tablaActual);
            final List<String> pks = claves(tablaActual);
            final Map<String, String> actuales = new HashMap<>();
            if (editar) {
                int mr = filaModelo();
                if (mr < 0) {
                    return;
                }
                for (int i = 0; i < modelo.getColumnCount(); i++) {
                    actuales.put(modelo.getColumnName(i), String.valueOf(modelo.getValueAt(mr, i)));
                }
            }

            final JDialog d = new JDialog(this, editar ? "Modificar registro" : "Crear registro", true);
            JPanel cont = new JPanel();
            cont.setLayout(new BoxLayout(cont, BoxLayout.Y_AXIS));
            cont.setBackground(PANEL);
            cont.setBorder(BorderFactory.createEmptyBorder(20, 26, 10, 26));

            final Map<String, JTextField> campos = new LinkedHashMap<>();
            for (Col c : cols) {
                if (!editar && c.autoInc()) {
                    continue;
                }
                JLabel l = etiqueta(c.nombre().toUpperCase().replace('_', ' '),
                        espaciado(fuente(Font.BOLD, 10), 0.12f), NARANJA);
                l.setAlignmentX(Component.LEFT_ALIGNMENT);
                JTextField t = new JTextField(editar ? actuales.getOrDefault(c.nombre(), "") : "");
                t.putClientProperty("JTextField.placeholderText", hint(c.tipo()));
                t.putClientProperty("JComponent.roundRect", true);
                t.setFont(fuente(Font.PLAIN, 13));
                t.setAlignmentX(Component.LEFT_ALIGNMENT);
                t.setPreferredSize(new Dimension(420, 38));
                t.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
                if (editar && pks.contains(c.nombre())) {
                    t.setEnabled(false);
                }
                campos.put(c.nombre(), t);
                cont.add(l);
                cont.add(Box.createVerticalStrut(4));
                cont.add(t);
                cont.add(Box.createVerticalStrut(12));
            }

            JScrollPane sp = new JScrollPane(cont);
            sp.setBorder(null);
            sp.getVerticalScrollBar().setUnitIncrement(16);
            sp.setPreferredSize(new Dimension(520, Math.min(520, campos.size() * 66 + 40)));

            JPanel pie = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
            pie.setBackground(PANEL);
            BotonNx cancelar = new BotonNx("CANCELAR", 1);
            cancelar.addActionListener(e -> d.dispose());
            BotonNx guardar = new BotonNx("GUARDAR", 0);
            guardar.addActionListener(e -> {
                try {
                    if (editar) {
                        actualizar(cols, pks, campos, actuales);
                    } else {
                        insertar(campos);
                    }
                    d.dispose();
                    recargarTabla();
                    refrescarStats();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(d, mensajeSql(ex), "No se pudo guardar",
                            JOptionPane.ERROR_MESSAGE);
                }
            });
            pie.add(cancelar);
            pie.add(guardar);

            d.getContentPane().setBackground(PANEL);
            d.getContentPane().add(etiquetaTitulo(editar ? "MODIFICAR REGISTRO" : "CREAR REGISTRO"), BorderLayout.NORTH);
            d.getContentPane().add(sp, BorderLayout.CENTER);
            d.getContentPane().add(pie, BorderLayout.SOUTH);
            d.pack();
            d.setLocationRelativeTo(this);
            d.setVisible(true);
        } catch (SQLException ex) {
            aviso(mensajeSql(ex));
        }
    }

    private JComponent etiquetaTitulo(String texto) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(10, 12, 16));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, NARANJA),
                BorderFactory.createEmptyBorder(14, 26, 14, 26)));
        p.add(etiqueta(texto + "  ·  " + tablaActual.toUpperCase().replace('_', ' '),
                espaciado(fuente(Font.BOLD, 13), 0.15f), CREMA), BorderLayout.WEST);
        return p;
    }

    private void insertar(Map<String, JTextField> campos) throws SQLException {
        List<String> nombres = new ArrayList<>();
        List<String> vals = new ArrayList<>();
        for (Map.Entry<String, JTextField> en : campos.entrySet()) {
            String v = en.getValue().getText().trim();
            if (!v.isEmpty()) {
                nombres.add(en.getKey());
                vals.add(v);
            }
        }
        if (nombres.isEmpty()) {
            throw new SQLException("Completa al menos un campo.");
        }
        StringBuilder cols = new StringBuilder();
        StringBuilder marcas = new StringBuilder();
        for (int i = 0; i < nombres.size(); i++) {
            cols.append(i > 0 ? ", " : "").append('`').append(nombres.get(i)).append('`');
            marcas.append(i > 0 ? ", " : "").append('?');
        }
        Connection cx = Conexion.getInstancia().conectar();
        try (PreparedStatement ps = cx.prepareStatement(
                "INSERT INTO `" + tablaActual + "` (" + cols + ") VALUES (" + marcas + ")")) {
            for (int i = 0; i < vals.size(); i++) {
                ps.setString(i + 1, vals.get(i));
            }
            ps.executeUpdate();
        }
        auditar("INSERT", tablaActual, "-", "Registro creado en " + tablaActual);
    }

    private void actualizar(List<Col> cols, List<String> pks, Map<String, JTextField> campos,
                            Map<String, String> actuales) throws SQLException {
        List<String> sets = new ArrayList<>();
        List<String> params = new ArrayList<>();
        for (Col c : cols) {
            JTextField t = campos.get(c.nombre());
            if (t == null || pks.contains(c.nombre()) || c.autoInc()) {
                continue;
            }
            String v = t.getText().trim();
            sets.add("`" + c.nombre() + "` = ?");
            params.add(v.isEmpty() && c.nulo() ? null : v);
        }
        if (sets.isEmpty() || pks.isEmpty()) {
            throw new SQLException("Esta tabla no tiene campos modificables.");
        }
        StringBuilder where = new StringBuilder();
        for (int i = 0; i < pks.size(); i++) {
            where.append(i > 0 ? " AND " : "").append('`').append(pks.get(i)).append("` = ?");
            params.add(actuales.get(pks.get(i)));
        }
        Connection cx = Conexion.getInstancia().conectar();
        try (PreparedStatement ps = cx.prepareStatement("UPDATE `" + tablaActual + "` SET "
                + String.join(", ", sets) + " WHERE " + where)) {
            for (int i = 0; i < params.size(); i++) {
                ps.setString(i + 1, params.get(i));
            }
            ps.executeUpdate();
        }
        auditar("UPDATE", tablaActual, actuales.get(pks.get(0)), "Registro modificado en " + tablaActual);
    }

    private void eliminar() {
        int mr = filaModelo();
        if (mr < 0) {
            return;
        }
        try {
            List<String> pks = claves(tablaActual);
            if (pks.isEmpty()) {
                aviso("Esta tabla no permite eliminar registros.");
                return;
            }
            int op = JOptionPane.showConfirmDialog(this,
                    "¿Eliminar definitivamente este registro de " + tablaActual + "?\nEsta acción no se puede deshacer.",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (op != JOptionPane.YES_OPTION) {
                return;
            }
            StringBuilder where = new StringBuilder();
            for (int i = 0; i < pks.size(); i++) {
                where.append(i > 0 ? " AND " : "").append('`').append(pks.get(i)).append("` = ?");
            }
            Connection cx = Conexion.getInstancia().conectar();
            try (PreparedStatement ps = cx.prepareStatement("DELETE FROM `" + tablaActual + "` WHERE " + where)) {
                for (int i = 0; i < pks.size(); i++) {
                    ps.setString(i + 1, celda(mr, pks.get(i)));
                }
                ps.executeUpdate();
            }
            auditar("DELETE", tablaActual, celda(mr, pks.get(0)), "Registro eliminado de " + tablaActual);
            recargarTabla();
            refrescarStats();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, mensajeSql(ex), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void accionEstado() {
        String[] ac = ACCIONES.get(tablaActual);
        if (ac == null) {
            return;
        }
        int mr = filaModelo();
        if (mr < 0) {
            return;
        }
        try {
            List<String> pks = claves(tablaActual);
            if (pks.isEmpty()) {
                return;
            }
            String motivo = "Acción del administrador";
            if (tablaActual.equals("membresias")) {
                String m = JOptionPane.showInputDialog(this, "Motivo de la cancelación:", "Cancelar suscripción",
                        JOptionPane.QUESTION_MESSAGE);
                if (m == null) {
                    return;
                }
                if (!m.trim().isEmpty()) {
                    motivo = m.trim();
                }
            } else {
                int op = JOptionPane.showConfirmDialog(this, "¿Confirmas la acción \"" + ac[2] + "\"?",
                        "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (op != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            StringBuilder where = new StringBuilder();
            for (int i = 0; i < pks.size(); i++) {
                where.append(i > 0 ? " AND " : "").append('`').append(pks.get(i)).append("` = ?");
            }
            Connection cx = Conexion.getInstancia().conectar();
            try (PreparedStatement ps = cx.prepareStatement("UPDATE `" + tablaActual + "` SET `" + ac[0]
                    + "` = ? WHERE " + where)) {
                ps.setString(1, ac[1]);
                for (int i = 0; i < pks.size(); i++) {
                    ps.setString(i + 2, celda(mr, pks.get(i)));
                }
                ps.executeUpdate();
            }
            if (tablaActual.equals("membresias")) {
                try (PreparedStatement ph = cx.prepareStatement(
                        "INSERT INTO historial_membresias (id_membresia, estado_anterior, estado_nuevo, motivo, cambiado_por) "
                                + "VALUES (?, ?, 'CANCELADA', ?, 1)")) {
                    ph.setString(1, celda(mr, "id_membresia"));
                    ph.setString(2, celda(mr, "estado"));
                    ph.setString(3, motivo);
                    ph.executeUpdate();
                }
            }
            auditar("UPDATE", tablaActual, celda(mr, pks.get(0)), ac[2] + " (" + motivo + ")");
            recargarTabla();
            refrescarStats();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, mensajeSql(ex), "No se pudo completar", JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================================
    //  AUDITORÍA
    // =====================================================================

    private void auditar(String accion, String tabla, String idReg, String desc) {
        try {
            Connection cx = Conexion.getInstancia().conectar();
            if (cx == null) {
                return;
            }
            String ip;
            try {
                ip = InetAddress.getLocalHost().getHostAddress();
            } catch (Exception e) {
                ip = "127.0.0.1";
            }
            String d = "[ADMIN " + adminEmail + "] " + desc;
            try (PreparedStatement ps = cx.prepareStatement(
                    "INSERT INTO auditoria (id_usuario, accion, tabla_afectada, id_registro, descripcion, "
                            + "datos_anteriores, datos_nuevos, ip, user_agent) VALUES (1, ?, ?, ?, ?, '{}', '{}', ?, ?)")) {
                ps.setString(1, accion.length() > 20 ? accion.substring(0, 20) : accion);
                ps.setString(2, tabla.length() > 60 ? tabla.substring(0, 60) : tabla);
                ps.setString(3, idReg.length() > 20 ? idReg.substring(0, 20) : idReg);
                ps.setString(4, d.length() > 255 ? d.substring(0, 255) : d);
                ps.setString(5, ip);
                ps.setString(6, "NexusGym Admin Panel");
                ps.executeUpdate();
            }
        } catch (SQLException ignorada) {
            // La auditoría nunca debe bloquear la operación principal.
        }
    }

    public static void main(String[] args) {
        FlatDarkLaf.setup();
        SwingUtilities.invokeLater(() -> new IniciodesesionAdmin().setVisible(true));
    }
}