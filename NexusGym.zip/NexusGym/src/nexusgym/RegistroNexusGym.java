package nexusgym;

import at.favre.lib.crypto.bcrypt.BCrypt;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class RegistroNexusGym extends JFrame {

    private JComboBox<String> cmbTipoDocumento;
    private JTextField txtDocumento;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtFechaNacimiento;
    private JComboBox<String> cmbSexo;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JPasswordField txtPassword;
    private JPasswordField txtConfirmarPassword;
    private JTextField txtDireccion;
    private JTextField txtCiudad;

    public RegistroNexusGym() {

        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception e) {
            System.err.println("No se pudo cargar FlatLaf.");
        }

        setTitle("NexusGym - Crear cuenta");
        setSize(1000, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        crearInterfaz();
    }

    private void crearInterfaz() {

        JPanel fondo = new JPanel(new BorderLayout());
        fondo.setBackground(new Color(15, 18, 22));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(9, 12, 15));
        header.setBorder(new EmptyBorder(20, 35, 20, 35));

        JLabel logo = new JLabel("NEXUS GYM");
        logo.setFont(new Font("Arial", Font.BOLD, 28));
        logo.setForeground(new Color(170, 255, 90));

        JLabel tituloHeader = new JLabel("CREAR CUENTA");
        tituloHeader.setFont(new Font("Arial", Font.BOLD, 15));
        tituloHeader.setForeground(Color.WHITE);

        header.add(logo, BorderLayout.WEST);
        header.add(tituloHeader, BorderLayout.EAST);

        fondo.add(header, BorderLayout.NORTH);

        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
        contenido.setBackground(new Color(15, 18, 22));
        contenido.setBorder(new EmptyBorder(20, 80, 20, 80));

        JLabel titulo = new JLabel("Únete a NexusGym");
        titulo.setFont(new Font("Arial", Font.BOLD, 30));
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel descripcion = new JLabel(
                "Completa tus datos para crear tu cuenta de cliente."
        );
        descripcion.setFont(new Font("Arial", Font.PLAIN, 14));
        descripcion.setForeground(new Color(180, 185, 190));
        descripcion.setAlignmentX(Component.CENTER_ALIGNMENT);

        contenido.add(titulo);
        contenido.add(Box.createVerticalStrut(5));
        contenido.add(descripcion);
        contenido.add(Box.createVerticalStrut(22));

        JPanel formulario = new JPanel(new GridLayout(6, 2, 20, 13));
        formulario.setOpaque(false);
        formulario.setMaximumSize(new Dimension(800, 420));

        cmbTipoDocumento = new JComboBox<>(
                new String[]{"CC", "TI", "CE", "PASAPORTE"}
        );

        txtDocumento = crearCampo();
        txtNombres = crearCampo();
        txtApellidos = crearCampo();
        txtFechaNacimiento = crearCampo();

        cmbSexo = new JComboBox<>(
                new String[]{"NO_ESPECIFICA", "M", "F", "OTRO"}
        );

        txtTelefono = crearCampo();
        txtEmail = crearCampo();

        txtPassword = new JPasswordField();
        configurarCampoPassword(txtPassword);

        txtConfirmarPassword = new JPasswordField();
        configurarCampoPassword(txtConfirmarPassword);

        txtDireccion = crearCampo();
        txtCiudad = crearCampo();

        formulario.add(crearBloque("TIPO DE DOCUMENTO", cmbTipoDocumento));
        formulario.add(crearBloque("DOCUMENTO", txtDocumento));

        formulario.add(crearBloque("NOMBRES", txtNombres));
        formulario.add(crearBloque("APELLIDOS", txtApellidos));

        formulario.add(crearBloque("FECHA DE NACIMIENTO", txtFechaNacimiento));
        formulario.add(crearBloque("SEXO", cmbSexo));

        formulario.add(crearBloque("TELÉFONO", txtTelefono));
        formulario.add(crearBloque("CORREO ELECTRÓNICO", txtEmail));

        formulario.add(crearBloque("CONTRASEÑA", txtPassword));
        formulario.add(crearBloque("CONFIRMAR CONTRASEÑA", txtConfirmarPassword));

        formulario.add(crearBloque("DIRECCIÓN", txtDireccion));
        formulario.add(crearBloque("CIUDAD", txtCiudad));

        contenido.add(formulario);
        contenido.add(Box.createVerticalStrut(20));

        JLabel ayuda = new JLabel(
                "La contraseña se almacenará de forma segura."
        );
        ayuda.setFont(new Font("Arial", Font.PLAIN, 12));
        ayuda.setForeground(new Color(150, 155, 160));
        ayuda.setAlignmentX(Component.CENTER_ALIGNMENT);

        contenido.add(ayuda);
        contenido.add(Box.createVerticalStrut(15));

        JPanel panelBotones = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 15, 0)
        );
        panelBotones.setOpaque(false);

        JButton btnVolver = new JButton("VOLVER");
        JButton btnCrear = new JButton("CREAR CUENTA");

        configurarBoton(btnVolver, false);
        configurarBoton(btnCrear, true);

        panelBotones.add(btnVolver);
        panelBotones.add(btnCrear);

        contenido.add(panelBotones);

        fondo.add(contenido, BorderLayout.CENTER);

        btnVolver.addActionListener(e -> {

            new PaginaPrincipal().setVisible(true);
            dispose();

        });

        btnCrear.addActionListener(e -> registrarCliente());

        add(fondo);
    }

    private JTextField crearCampo() {

        JTextField campo = new JTextField();

        campo.setFont(new Font("Arial", Font.PLAIN, 14));
        campo.setForeground(Color.WHITE);
        campo.setBackground(new Color(30, 34, 39));

        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(65, 70, 75)
                ),
                BorderFactory.createEmptyBorder(
                        7, 10, 7, 10
                )
        ));

        return campo;
    }

    private void configurarCampoPassword(JPasswordField campo) {

        campo.setFont(new Font("Arial", Font.PLAIN, 14));
        campo.setForeground(Color.WHITE);
        campo.setBackground(new Color(30, 34, 39));

        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(65, 70, 75)
                ),
                BorderFactory.createEmptyBorder(
                        7, 10, 7, 10
                )
        ));
    }

    private JPanel crearBloque(String titulo, JComponent componente) {

        JPanel panel = new JPanel(new BorderLayout(0, 5));
        panel.setOpaque(false);

        JLabel etiqueta = new JLabel(titulo);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 11));
        etiqueta.setForeground(new Color(180, 255, 100));

        panel.add(etiqueta, BorderLayout.NORTH);
        panel.add(componente, BorderLayout.CENTER);

        return panel;
    }

    private void configurarBoton(JButton boton, boolean principal) {

        boton.setFont(new Font("Arial", Font.BOLD, 13));
        boton.setFocusPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(new Dimension(180, 42));

        if (principal) {

            boton.setBackground(new Color(150, 240, 70));
            boton.setForeground(Color.BLACK);

        } else {

            boton.setBackground(new Color(35, 39, 44));
            boton.setForeground(Color.WHITE);
        }
    }

    private void registrarCliente() {

        String tipoDocumento =
                cmbTipoDocumento.getSelectedItem().toString();

        String documento =
                txtDocumento.getText().trim();

        String nombres =
                txtNombres.getText().trim();

        String apellidos =
                txtApellidos.getText().trim();

        String fechaNacimiento =
                txtFechaNacimiento.getText().trim();

        String sexo =
                cmbSexo.getSelectedItem().toString();

        String telefono =
                txtTelefono.getText().trim();

        String email =
                txtEmail.getText().trim();

        String password =
                new String(txtPassword.getPassword());

        String confirmarPassword =
                new String(txtConfirmarPassword.getPassword());

        String direccion =
                txtDireccion.getText().trim();

        String ciudad =
                txtCiudad.getText().trim();

        if (documento.isEmpty()
                || nombres.isEmpty()
                || apellidos.isEmpty()
                || email.isEmpty()
                || password.isEmpty()
                || confirmarPassword.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Completa todos los campos obligatorios.",
                    "Datos incompletos",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (!email.contains("@")) {

            JOptionPane.showMessageDialog(
                    this,
                    "Ingresa un correo electrónico válido.",
                    "Correo inválido",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (password.length() < 6) {

            JOptionPane.showMessageDialog(
                    this,
                    "La contraseña debe tener mínimo 6 caracteres.",
                    "Contraseña inválida",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (!password.equals(confirmarPassword)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Las contraseñas no coinciden.",
                    "Error",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        Date fechaSQL = null;

        if (!fechaNacimiento.isEmpty()) {

            try {

                LocalDate fecha =
                        LocalDate.parse(fechaNacimiento);

                fechaSQL = Date.valueOf(fecha);

            } catch (DateTimeParseException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "La fecha debe tener este formato:\n"
                        + "AAAA-MM-DD\n\n"
                        + "Ejemplo: 2008-05-20",
                        "Fecha inválida",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }
        }

        String passwordHash =
                BCrypt.withDefaults()
                        .hashToString(
                                12,
                                password.toCharArray()
                        );

        String sql = """
                INSERT INTO clientes
                (
                    tipo_documento,
                    documento,
                    nombres,
                    apellidos,
                    fecha_nacimiento,
                    sexo,
                    telefono,
                    email,
                    password_hash,
                    direccion,
                    ciudad,
                    fecha_registro,
                    estado
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'ACTIVO')
                """;

        Conexion conexionBD =
                Conexion.getInstancia();

        Connection cn =
                conexionBD.conectar();

        if (cn == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo conectar con la base de datos.",
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try (
                PreparedStatement pst =
                        cn.prepareStatement(
                                sql,
                                Statement.RETURN_GENERATED_KEYS
                        )
        ) {

            pst.setString(1, tipoDocumento);
            pst.setString(2, documento);
            pst.setString(3, nombres);
            pst.setString(4, apellidos);

            if (fechaSQL != null) {
                pst.setDate(5, fechaSQL);
            } else {
                pst.setNull(5, Types.DATE);
            }

            pst.setString(6, sexo);
            pst.setString(7, telefono);
            pst.setString(8, email);
            pst.setString(9, passwordHash);
            pst.setString(10, direccion);
            pst.setString(11, ciudad);

            int filas = pst.executeUpdate();

            if (filas > 0) {

                int idCliente = 0;

                try (ResultSet rs =
                             pst.getGeneratedKeys()) {

                    if (rs.next()) {
                        idCliente = rs.getInt(1);
                    }
                }

                JOptionPane.showMessageDialog(
                        this,
                        "¡CUENTA CREADA CORRECTAMENTE!\n\n"
                        + "Bienvenido a NexusGym, "
                        + nombres + ".\n\n"
                        + "ID de cliente: " + idCliente
                        + "\n"
                        + "Correo: " + email
                        + "\n\n"
                        + "Ya puedes iniciar sesión.",
                        "NexusGym",
                        JOptionPane.INFORMATION_MESSAGE
                );

                limpiarFormulario();
            }

        } catch (SQLException ex) {

            String mensaje =
                    ex.getMessage() == null
                    ? ""
                    : ex.getMessage().toLowerCase();

            if (mensaje.contains("duplicate")) {

                if (mensaje.contains("documento")) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Ese documento ya está registrado.",
                            "Cliente existente",
                            JOptionPane.WARNING_MESSAGE
                    );

                } else if (mensaje.contains("email")) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Ese correo electrónico ya está registrado.",
                            "Cliente existente",
                            JOptionPane.WARNING_MESSAGE
                    );

                } else {

                    JOptionPane.showMessageDialog(
                            this,
                            "El documento o correo ya está registrado.",
                            "Cliente existente",
                            JOptionPane.WARNING_MESSAGE
                    );
                }

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se pudo crear la cuenta.\n\n"
                        + "Error:\n"
                        + ex.getMessage(),
                        "Error de base de datos",
                        JOptionPane.ERROR_MESSAGE
                );

                ex.printStackTrace();
            }
        }
    }

    private void limpiarFormulario() {

        cmbTipoDocumento.setSelectedIndex(0);

        txtDocumento.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtFechaNacimiento.setText("");

        cmbSexo.setSelectedIndex(0);

        txtTelefono.setText("");
        txtEmail.setText("");
        txtPassword.setText("");
        txtConfirmarPassword.setText("");
        txtDireccion.setText("");
        txtCiudad.setText("");

        txtDocumento.requestFocus();
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new RegistroNexusGym().setVisible(true);

        });
    }
}