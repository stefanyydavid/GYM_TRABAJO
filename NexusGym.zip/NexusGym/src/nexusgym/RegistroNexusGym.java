package nexusgym;

import at.favre.lib.crypto.bcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class RegistroNexusGym extends JFrame {

    private static final String[] TIPOS_DOC_TXT = {
        "CC - Cédula de ciudadanía",
        "TI - Tarjeta de identidad",
        "CE - Cédula de extranjería",
        "Pasaporte"
    };

    private static final String[] TIPOS_DOC = {"CC", "TI", "CE", "PASAPORTE"};

    private static final String[] SEXO_TXT = {
        "Prefiero no decirlo", "Masculino", "Femenino", "Otro"
    };

    private static final String[] SEXO = {"NO_ESPECIFICA", "M", "F", "OTRO"};

    private JComboBox<String> cmbTipoDocumento;
    private JTextField txtDocumento;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtFechaNacimiento;
    private JComboBox<String> cmbSexo;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JPasswordField txtPassword;
    private JPasswordField txtConfirmarPassword;
    private JTextField txtDireccion;
    private JTextField txtCiudad;

    private JLabel lblError;
    private Tema.Boton btnCrear;

    public RegistroNexusGym() {

        Tema.instalar();

        setTitle("NexusGym - Crear cuenta");
        setSize(1160, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        crearInterfaz();
    }

    private void crearInterfaz() {

        JPanel raiz = new JPanel(new BorderLayout());

        raiz.add(
                new Tema.PanelMarca(
                        340,
                        "Empieza<br>tu cambio<br><span style='color:#E86A24'>hoy.</span>",
                        new String[]{
                            "Reserva clases y consulta horarios",
                            "Accede a todas nuestras sedes",
                            "Tu cuenta, siempre contigo"
                        }
                ),
                BorderLayout.WEST
        );

        Tema.Fondo derecha = new Tema.Fondo();

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBorder(BorderFactory.createEmptyBorder(34, 48, 30, 48));

        JLabel titulo = new JLabel("Crea tu cuenta");
        titulo.setFont(Tema.f(Font.BOLD, 30));
        titulo.setForeground(Tema.CREMA);
        titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descripcion = new JLabel(
                "Completa tus datos para crear tu cuenta de cliente. "
                + "Los campos con * son obligatorios."
        );
        descripcion.setFont(Tema.f(Font.PLAIN, 14));
        descripcion.setForeground(Tema.TEXTO_SEC);
        descripcion.setAlignmentX(Component.LEFT_ALIGNMENT);

        cmbTipoDocumento = Tema.combo(TIPOS_DOC_TXT);
        txtDocumento = Tema.campo("Número de documento");
        txtNombres = Tema.campo("Tus nombres");
        txtApellidos = Tema.campo("Tus apellidos");
        txtFechaNacimiento = Tema.campo("AAAA-MM-DD  (ej. 2000-05-20)");
        cmbSexo = Tema.combo(SEXO_TXT);
        txtTelefono = Tema.campo("Ej. 3001234567");
        txtEmail = Tema.campo("tucorreo@ejemplo.com");
        txtPassword = Tema.password("Mínimo 6 caracteres");
        txtConfirmarPassword = Tema.password("Repite tu contraseña");
        txtDireccion = Tema.campo("Dirección de residencia");
        txtCiudad = Tema.campo("Ciudad");

        JPanel grid = new JPanel(new GridLayout(0, 2, 20, 14));
        grid.setOpaque(false);
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);

        grid.add(Tema.bloque("Tipo de documento *", cmbTipoDocumento));
        grid.add(Tema.bloque("Documento *", txtDocumento));
        grid.add(Tema.bloque("Nombres *", txtNombres));
        grid.add(Tema.bloque("Apellidos *", txtApellidos));
        grid.add(Tema.bloque("Fecha de nacimiento", txtFechaNacimiento));
        grid.add(Tema.bloque("Sexo", cmbSexo));
        grid.add(Tema.bloque("Teléfono", txtTelefono));
        grid.add(Tema.bloque("Correo electrónico *", txtEmail));
        grid.add(Tema.bloque("Contraseña *", txtPassword));
        grid.add(Tema.bloque("Confirmar contraseña *", txtConfirmarPassword));
        grid.add(Tema.bloque("Dirección", txtDireccion));
        grid.add(Tema.bloque("Ciudad", txtCiudad));

        lblError = new JLabel(" ");
        lblError.setFont(Tema.f(Font.BOLD, 12));
        lblError.setForeground(Tema.ERROR);
        lblError.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel ayuda = new JLabel("Tu contraseña se almacena de forma segura (cifrada).");
        ayuda.setFont(Tema.f(Font.PLAIN, 12));
        ayuda.setForeground(new Color(120, 126, 138));
        ayuda.setAlignmentX(Component.LEFT_ALIGNMENT);

        // ---------- Botones ----------

        Tema.Boton btnLogin = new Tema.Boton(
                "¿Ya tienes cuenta? Inicia sesión",
                Tema.Estilo.FANTASMA
        );
        btnLogin.addActionListener(e -> {
            new LoginNuevo().setVisible(true);
            dispose();
        });

        Tema.Boton btnVolver = new Tema.Boton("VOLVER", Tema.Estilo.SECUNDARIO);
        btnVolver.setPreferredSize(new Dimension(130, 44));
        btnVolver.addActionListener(e -> {
            new PaginaPrincipal().setVisible(true);
            dispose();
        });

        btnCrear = new Tema.Boton("CREAR CUENTA", Tema.Estilo.PRIMARIO);
        btnCrear.setPreferredSize(new Dimension(180, 44));
        btnCrear.addActionListener(e -> registrarCliente());

        JPanel derechaBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        derechaBotones.setOpaque(false);
        derechaBotones.add(btnVolver);
        derechaBotones.add(btnCrear);

        JPanel filaBotones = new JPanel(new BorderLayout());
        filaBotones.setOpaque(false);
        filaBotones.setAlignmentX(Component.LEFT_ALIGNMENT);
        filaBotones.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        filaBotones.add(btnLogin, BorderLayout.WEST);
        filaBotones.add(derechaBotones, BorderLayout.EAST);

        form.add(titulo);
        form.add(Box.createVerticalStrut(6));
        form.add(descripcion);
        form.add(Box.createVerticalStrut(24));
        form.add(grid);
        form.add(Box.createVerticalStrut(12));
        form.add(ayuda);
        form.add(Box.createVerticalStrut(6));
        form.add(lblError);
        form.add(Box.createVerticalStrut(8));
        form.add(filaBotones);

        derecha.add(Tema.scroll(form), BorderLayout.CENTER);

        raiz.add(derecha, BorderLayout.CENTER);

        setContentPane(raiz);

        getRootPane().setDefaultButton(btnCrear);
    }

    private void mostrarError(String mensaje) {
        lblError.setText(mensaje);
    }

    // ==========================================================
    // REGISTRO
    // ==========================================================

    private void registrarCliente() {

        lblError.setText(" ");

        String tipoDocumento = TIPOS_DOC[cmbTipoDocumento.getSelectedIndex()];
        String documento = txtDocumento.getText().trim();
        String nombres = txtNombres.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String fechaNacimiento = txtFechaNacimiento.getText().trim();
        String sexo = SEXO[cmbSexo.getSelectedIndex()];
        String telefono = txtTelefono.getText().trim();
        String email = txtEmail.getText().trim();
        String password = new String(txtPassword.getPassword());
        String confirmar = new String(txtConfirmarPassword.getPassword());
        String direccion = txtDireccion.getText().trim();
        String ciudad = txtCiudad.getText().trim();

        if (documento.isEmpty() || nombres.isEmpty() || apellidos.isEmpty()
                || email.isEmpty() || password.isEmpty() || confirmar.isEmpty()) {
            mostrarError("Completa todos los campos obligatorios (*).");
            return;
        }

        if (!email.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
            mostrarError("Ingresa un correo electrónico válido.");
            txtEmail.requestFocusInWindow();
            return;
        }

        if (password.length() < 6) {
            mostrarError("La contraseña debe tener mínimo 6 caracteres.");
            txtPassword.requestFocusInWindow();
            return;
        }

        if (!password.equals(confirmar)) {
            mostrarError("Las contraseñas no coinciden.");
            txtConfirmarPassword.requestFocusInWindow();
            return;
        }

        Date fechaSQL = null;

        if (!fechaNacimiento.isEmpty()) {

            try {

                LocalDate fecha = LocalDate.parse(fechaNacimiento);

                if (fecha.isAfter(LocalDate.now())) {
                    mostrarError("La fecha de nacimiento no puede ser futura.");
                    return;
                }

                fechaSQL = Date.valueOf(fecha);

            } catch (DateTimeParseException e) {
                mostrarError("La fecha debe tener el formato AAAA-MM-DD (ej. 2000-05-20).");
                txtFechaNacimiento.requestFocusInWindow();
                return;
            }
        }

        Connection cn = Conexion.getInstancia().conectar();

        if (cn == null) {
            Tema.mensaje(
                    this,
                    "ERROR DE CONEXIÓN",
                    "Sin conexión",
                    "No se pudo conectar con la base de datos.",
                    true
            );
            return;
        }

        String passwordHash = BCrypt.withDefaults()
                .hashToString(12, password.toCharArray());

        String sql = """
                INSERT INTO clientes
                (
                    tipo_documento, documento, nombres, apellidos,
                    fecha_nacimiento, sexo, telefono, email,
                    password_hash, direccion, ciudad,
                    fecha_registro, estado
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), 'ACTIVO')
                """;

        try (PreparedStatement pst = cn.prepareStatement(
                sql, Statement.RETURN_GENERATED_KEYS)) {

            pst.setString(1, tipoDocumento);
            pst.setString(2, documento);
            pst.setString(3, nombres);
            pst.setString(4, apellidos);

            if (fechaSQL != null) {
                pst.setDate(5, fechaSQL);
            } else {
                pst.setNull(5, Types.DATE);
            }

            pst.setString(6, sexo);
            pst.setString(7, telefono);
            pst.setString(8, email);
            pst.setString(9, passwordHash);
            pst.setString(10, direccion);
            pst.setString(11, ciudad);

            if (pst.executeUpdate() > 0) {

                int idCliente = 0;

                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        idCliente = rs.getInt(1);
                    }
                }

                Tema.mensaje(
                        this,
                        "CUENTA CREADA",
                        "¡Bienvenido a NexusGym!",
                        "<b>" + Tema.esc(nombres) + "</b>, tu cuenta fue creada "
                        + "correctamente.<br><br>"
                        + "Cliente #" + idCliente + "<br>"
                        + Tema.esc(email) + "<br><br>"
                        + "Ya puedes iniciar sesión.",
                        false
                );

                new LoginNuevo().setVisible(true);
                dispose();
            }

        } catch (SQLException ex) {

            String mensaje = ex.getMessage() == null
                    ? ""
                    : ex.getMessage().toLowerCase();

            if (mensaje.contains("duplicate")) {

                if (mensaje.contains("documento")) {
                    mostrarError("Ese documento ya está registrado.");
                } else if (mensaje.contains("email")) {
                    mostrarError("Ese correo electrónico ya está registrado.");
                } else {
                    mostrarError("El documento o el correo ya están registrados.");
                }

            } else {

                Tema.mensaje(
                        this,
                        "ERROR",
                        "No se pudo crear la cuenta",
                        Tema.esc(ex.getMessage()),
                        true
                );

                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {

        Tema.instalar();

        SwingUtilities.invokeLater(() -> new RegistroNexusGym().setVisible(true));
    }
}