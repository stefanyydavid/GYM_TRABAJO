package nexusgym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String URL = "jdbc:mysql://localhost:3307/";
    private final String DB = "db_gym";
    private final String USER = "root";
    private final String PASSWORD = "";

    private Connection cadena;
    private static Conexion instancia;

    private Conexion() {
        cadena = null;
    }

    // Obtener la única instancia de la conexión
    public static Conexion getInstancia() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }

    // Conectar a la base de datos
    public Connection conectar() {
        try {
            if (cadena == null || cadena.isClosed()) {
                Class.forName(DRIVER);

                cadena = DriverManager.getConnection(
                        URL + DB,
                        USER,
                        PASSWORD
                );
            }

        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error de conexión: " + e.getMessage(),
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return cadena;
    }

    // Desconectar de la base de datos
    public void desconectar() {
        try {
            if (cadena != null && !cadena.isClosed()) {
                cadena.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error al cerrar la conexión: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}