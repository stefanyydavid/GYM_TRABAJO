package nexusgym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** JDBC connection helper. Configure with NEXUS_DB_URL, NEXUS_DB_USER and NEXUS_DB_PASSWORD. */
public final class Conexion {
    private static final String DEFAULT_URL = "jdbc:mysql://127.0.0.1:3307/db_gym?useUnicode=true&characterEncoding=UTF-8&serverTimezone=America/Bogota&allowPublicKeyRetrieval=true&useSSL=false";
    private static final Conexion INSTANCIA = new Conexion();
    private Conexion() {}
    public static Conexion getInstancia() { return INSTANCIA; }
    public Connection conectar() {
        String url = System.getenv().getOrDefault("NEXUS_DB_URL", DEFAULT_URL);
        String user = System.getenv().getOrDefault("NEXUS_DB_USER", "root");
        String password = System.getenv().getOrDefault("NEXUS_DB_PASSWORD", "");
        try { Class.forName("com.mysql.cj.jdbc.Driver"); return DriverManager.getConnection(url, user, password); }
        catch (ClassNotFoundException | SQLException ex) { throw new IllegalStateException("No fue posible conectar a db_gym. Verifica MySQL, puerto, usuario y contraseña. Detalle: " + ex.getMessage(), ex); }
    }
    /** Compatibility method: closes only the supplied connection; prefer try-with-resources. */
    public void desconectar(Connection connection) { if (connection != null) try { connection.close(); } catch (SQLException ex) { throw new IllegalStateException("No se pudo cerrar la conexión", ex); } }
    /** Legacy compatibility method. Avoid shared mutable connections in new code. */
    @Deprecated public void desconectar() { }
}
