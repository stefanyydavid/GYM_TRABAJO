package nexusgym;

import at.favre.lib.crypto.bcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginNuevo extends JFrame {

    private JTextField txtCorreo;
    private JPasswordField txtPassword;
    private JLabel lblError;
    private Tema.Boton btnIngresar;

    public LoginNuevo() {

        Tema.instalar();

        setTitle("NexusGym - Iniciar Sesión");
        setSize(960, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        construirInterfaz();

        SwingUtilities.invokeLater(() -> txtCorreo.requestFocusInWindow());
    }

    private void construirInterfaz() {

        JPanel raiz = new JPanel(new BorderLayout());

        // ---------- Lado izquierdo ----------

        raiz.add(
                new Tema.PanelMarca(
                        390,
                        "Entrena mejor.<br>"
                        + "<span style='color:#E86A24'>Alcanza tus<br>objetivos.</span>",
                        new String[]{
                            "Consulta horarios y clases",
                            "Sigue tu progreso",
                            "Encuentra tu sede más cercana"
                        }
                ),
                BorderLayout.WEST
        );

        // ---------- Lado derecho ----------

        Tema.Fondo derecha = new Tema.Fondo();
        derecha.setLayout(new GridBagLayout());

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("Bienvenido de nuevo");
        titulo.setFont(Tema.f(Font.BOLD, 30));
        titulo.setForeground(Tema.CREMA);
        titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descripcion = new JLabel("Ingresa tus datos para continuar");
        descripcion.setFont(Tema.f(Font.PLAIN, 14));
        descripcion.setForeground(Tema.TEXTO_SEC);
        descripcion.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtCorreo = Tema.campo("tucorreo@ejemplo.com");
        txtCorreo.setPreferredSize(new Dimension(380, 44));

        txtPassword = Tema.password("Tu contraseña");
        txtPassword.setPreferredSize(new Dimension(380, 44));

        lblError = new JLabel(" ");
        lblError.setFont(Tema.f(Font.BOLD, 12));
        lblError.setForeground(Tema.ERROR);
        lblError.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnIngresar = new Tema.Boton("INICIAR SESIÓN", Tema.Estilo.PRIMARIO);
        btnIngresar.setPreferredSize(new Dimension(380, 46));
        btnIngresar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        btnIngresar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnIngresar.addActionListener(e -> iniciarSesion());

        // ---------- Crear cuenta ----------

        JPanel filaRegistro = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        filaRegistro.setOpaque(false);
        filaRegistro.setAlignmentX(Component.LEFT_ALIGNMENT);
        filaRegistro.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JLabel lblNoCuenta = new JLabel("¿No tienes una cuenta?");
        lblNoCuenta.setFont(Tema.f(Font.PLAIN, 13));
        lblNoCuenta.setForeground(Tema.TEXTO_SEC);

        Tema.Boton btnCrear = new Tema.Boton("Crear cuenta", Tema.Estilo.FANTASMA);
        btnCrear.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        btnCrear.addActionListener(e -> {
            new RegistroNexusGym().setVisible(true);
            dispose();
        });

        filaRegistro.add(lblNoCuenta);
        filaRegistro.add(btnCrear);

        Tema.Boton btnVolver = new Tema.Boton("←  Volver al inicio", Tema.Estilo.SECUNDARIO);
        btnVolver.setPreferredSize(new Dimension(380, 42));
        btnVolver.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnVolver.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnVolver.addActionListener(e -> {
            new PaginaPrincipal().setVisible(true);
            dispose();
        });

        form.add(titulo);
        form.add(Box.createVerticalStrut(6));
        form.add(descripcion);
        form.add(Box.createVerticalStrut(30));
        form.add(Tema.bloque("Correo electrónico", txtCorreo));
        form.add(Box.createVerticalStrut(18));
        form.add(Tema.bloque("Contraseña", txtPassword));
        form.add(Box.createVerticalStrut(10));
        form.add(lblError);
        form.add(Box.createVerticalStrut(10));
        form.add(btnIngresar);
        form.add(Box.createVerticalStrut(14));
        form.add(filaRegistro);
        form.add(Box.createVerticalStrut(10));
        form.add(btnVolver);

        derecha.add(form);

        raiz.add(derecha, BorderLayout.CENTER);

        setContentPane(raiz);

        getRootPane().setDefaultButton(btnIngresar);
    }

    // ==========================================================
    // INICIAR SESIÓN
    // ==========================================================

    private void iniciarSesion() {

        lblError.setText(" ");

        String correo = txtCorreo.getText().trim();
        String contrasena = new String(txtPassword.getPassword());

        if (correo.isEmpty() || contrasena.isEmpty()) {
            lblError.setText("Ingresa tu correo y tu contraseña.");
            return;
        }

        Connection cn = Conexion.getInstancia().conectar();

        if (cn == null) {
            Tema.mensaje(
                    this,
                    "ERROR DE CONEXIÓN",
                    "Sin conexión",
                    "No se pudo conectar con la base de datos.",
                    true
            );
            return;
        }

        try {

            // 1. Usuarios internos
            boolean interno = true;
            String[] u = buscar(cn, "usuarios_internos", "id_usuario", correo);

            // 2. Clientes
            if (u == null) {
                interno = false;
                u = buscar(cn, "clientes", "id_cliente", correo);
            }

            // 3. No existe
            if (u == null) {
                mostrarErrorLogin();
                return;
            }

            String hash = u[3];

            if (hash == null || hash.isEmpty()) {

                if (interno) {
                    mostrarErrorLogin();
                } else {
                    lblError.setText("Esta cuenta aún no tiene contraseña configurada.");
                }

                return;
            }

            BCrypt.Result resultado = BCrypt.verifyer().verify(
                    contrasena.toCharArray(),
                    hash
            );

            if (!resultado.verified) {
                mostrarErrorLogin();
                return;
            }

            if (interno) {

                try (PreparedStatement pst = cn.prepareStatement(
                        "UPDATE usuarios_internos "
                        + "SET ultimo_acceso = NOW() "
                        + "WHERE id_usuario = ?")) {

                    pst.setInt(1, Integer.parseInt(u[0]));
                    pst.executeUpdate();
                }
            }

            new PanelNexusGym(u[1], u[2]).setVisible(true);
            dispose();

        } catch (SQLException ex) {

            Tema.mensaje(
                    this,
                    "ERROR",
                    "Error de base de datos",
                    Tema.esc(ex.getMessage()),
                    true
            );

            ex.printStackTrace();

        } catch (Exception ex) {

            Tema.mensaje(
                    this,
                    "ERROR",
                    "No se pudo iniciar sesión",
                    Tema.esc(ex.getMessage()),
                    true
            );

            ex.printStackTrace();
        }
    }

    /**
     * Devuelve {id, nombres, email, password_hash} o null si no existe.
     * Los nombres de tabla/columna son constantes internas (no vienen del usuario).
     */
    private String[] buscar(
            Connection cn,
            String tabla,
            String columnaId,
            String correo) throws SQLException {

        String sql = "SELECT " + columnaId + " AS id, nombres, email, password_hash "
                + "FROM " + tabla + " "
                + "WHERE email = ? AND estado = 'ACTIVO'";

        try (PreparedStatement pst = cn.prepareStatement(sql)) {

            pst.setString(1, correo);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {
                    return new String[]{
                        rs.getString("id"),
                        rs.getString("nombres"),
                        rs.getString("email"),
                        rs.getString("password_hash")
                    };
                }
            }
        }

        return null;
    }

    private void mostrarErrorLogin() {

        lblError.setText("El correo o la contraseña son incorrectos.");

        txtPassword.setText("");
        txtPassword.requestFocusInWindow();
    }

    public static void main(String[] args) {

        Tema.instalar();

        SwingUtilities.invokeLater(() -> new LoginNuevo().setVisible(true));
    }
}
