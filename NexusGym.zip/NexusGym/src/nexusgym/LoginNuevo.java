package nexusgym;

import at.favre.lib.crypto.bcrypt.BCrypt;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;

public class LoginNuevo extends JFrame {

    private JTextField txtCorreo;
    private JPasswordField txtPassword;

    public LoginNuevo() {

        FlatDarkLaf.setup();

        setTitle("NexusGym - Iniciar Sesión");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel fondo = new JPanel(new BorderLayout());
        fondo.setBackground(new Color(18, 18, 18));
        setContentPane(fondo);

        // =========================
        // PANEL IZQUIERDO
        // =========================

        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setPreferredSize(new Dimension(390, 600));
        panelIzquierdo.setBackground(new Color(20, 20, 20));
        panelIzquierdo.setLayout(
                new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS)
        );
        panelIzquierdo.setBorder(
                new EmptyBorder(80, 45, 50, 45)
        );

        JLabel lblLogo = new JLabel("NEXUSGYM");
        lblLogo.setFont(
                new Font("Arial", Font.BOLD, 34)
        );
        lblLogo.setForeground(
                new Color(45, 220, 120)
        );
        lblLogo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        JLabel lblSubtitulo =
                new JLabel("Tu entrenamiento. Tu progreso.");

        lblSubtitulo.setFont(
                new Font("Arial", Font.PLAIN, 15)
        );
        lblSubtitulo.setForeground(
                Color.LIGHT_GRAY
        );
        lblSubtitulo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panelIzquierdo.add(lblLogo);
        panelIzquierdo.add(
                Box.createVerticalStrut(10)
        );
        panelIzquierdo.add(lblSubtitulo);
        panelIzquierdo.add(
                Box.createVerticalGlue()
        );

        JLabel lblInfo = new JLabel(
                "<html><center>"
                + "Entrena mejor.<br>"
                + "Alcanza tus objetivos."
                + "</center></html>"
        );

        lblInfo.setFont(
                new Font("Arial", Font.PLAIN, 18)
        );
        lblInfo.setForeground(Color.WHITE);
        lblInfo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panelIzquierdo.add(lblInfo);
        panelIzquierdo.add(
                Box.createVerticalGlue()
        );

        JLabel lblVersion =
                new JLabel("NexusGym © 2026");

        lblVersion.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );
        lblVersion.setForeground(Color.GRAY);
        lblVersion.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panelIzquierdo.add(lblVersion);

        // =========================
        // PANEL DERECHO
        // =========================

        JPanel panelDerecho = new JPanel();
        panelDerecho.setBackground(
                new Color(30, 30, 30)
        );
        panelDerecho.setLayout(
                new GridBagLayout()
        );

        JPanel formulario = new JPanel();
        formulario.setBackground(
                new Color(30, 30, 30)
        );
        formulario.setLayout(
                new BoxLayout(
                        formulario,
                        BoxLayout.Y_AXIS
                )
        );
        formulario.setPreferredSize(
                new Dimension(380, 430)
        );

        JLabel lblTitulo =
                new JLabel("Iniciar sesión");

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 30)
        );
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        JLabel lblDescripcion =
                new JLabel(
                        "Ingresa tus datos para continuar"
                );

        lblDescripcion.setFont(
                new Font("Arial", Font.PLAIN, 14)
        );
        lblDescripcion.setForeground(Color.GRAY);
        lblDescripcion.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        formulario.add(lblTitulo);
        formulario.add(
                Box.createVerticalStrut(8)
        );
        formulario.add(lblDescripcion);
        formulario.add(
                Box.createVerticalStrut(35)
        );

        // =========================
        // CORREO
        // =========================

        JLabel lblCorreo =
                new JLabel("Correo electrónico");

        lblCorreo.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        lblCorreo.setForeground(Color.WHITE);
        lblCorreo.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        txtCorreo = new JTextField();
        txtCorreo.setFont(
                new Font("Arial", Font.PLAIN, 15)
        );
        txtCorreo.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 45)
        );
        txtCorreo.setPreferredSize(
                new Dimension(350, 45)
        );
        txtCorreo.setBackground(
                new Color(45, 45, 45)
        );
        txtCorreo.setForeground(Color.WHITE);
        txtCorreo.setCaretColor(Color.WHITE);
        txtCorreo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(70, 70, 70)
                        ),
                        BorderFactory.createEmptyBorder(
                                5, 10, 5, 10
                        )
                )
        );

        formulario.add(lblCorreo);
        formulario.add(
                Box.createVerticalStrut(8)
        );
        formulario.add(txtCorreo);
        formulario.add(
                Box.createVerticalStrut(20)
        );

        // =========================
        // CONTRASEÑA
        // =========================

        JLabel lblPassword =
                new JLabel("Contraseña");

        lblPassword.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        txtPassword = new JPasswordField();

        txtPassword.setFont(
                new Font("Arial", Font.PLAIN, 15)
        );
        txtPassword.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 45)
        );
        txtPassword.setPreferredSize(
                new Dimension(350, 45)
        );
        txtPassword.setBackground(
                new Color(45, 45, 45)
        );
        txtPassword.setForeground(Color.WHITE);
        txtPassword.setCaretColor(Color.WHITE);
        txtPassword.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(70, 70, 70)
                        ),
                        BorderFactory.createEmptyBorder(
                                5, 10, 5, 10
                        )
                )
        );

        formulario.add(lblPassword);
        formulario.add(
                Box.createVerticalStrut(8)
        );
        formulario.add(txtPassword);
        formulario.add(
                Box.createVerticalStrut(30)
        );

        // =========================
        // BOTÓN INICIAR SESIÓN
        // =========================

        JButton btnIngresar =
                new JButton("INICIAR SESIÓN");

        btnIngresar.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setBackground(
                new Color(35, 190, 105)
        );
        btnIngresar.setFocusPainted(false);
        btnIngresar.setBorderPainted(false);
        btnIngresar.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
        btnIngresar.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );
        btnIngresar.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 48)
        );
        btnIngresar.setPreferredSize(
                new Dimension(350, 48)
        );

        formulario.add(btnIngresar);
        formulario.add(
                Box.createVerticalStrut(18)
        );

        // =========================
        // CREAR CUENTA
        // =========================

        JPanel panelRegistro = new JPanel();

        panelRegistro.setBackground(
                new Color(30, 30, 30)
        );

        panelRegistro.setLayout(
                new FlowLayout(
                        FlowLayout.CENTER,
                        5,
                        0
                )
        );

        panelRegistro.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panelRegistro.setMaximumSize(
                new Dimension(380, 45)
        );

        JLabel lblNoCuenta =
                new JLabel("¿No tienes una cuenta?");

        lblNoCuenta.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );
        lblNoCuenta.setForeground(Color.GRAY);

        JButton btnCrearCuenta =
                new JButton(
                        "Haz clic aquí para crear una"
                );

        btnCrearCuenta.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        btnCrearCuenta.setForeground(
                new Color(45, 220, 120)
        );
        btnCrearCuenta.setBackground(
                new Color(30, 30, 30)
        );
        btnCrearCuenta.setBorderPainted(false);
        btnCrearCuenta.setFocusPainted(false);
        btnCrearCuenta.setContentAreaFilled(false);
        btnCrearCuenta.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        panelRegistro.add(lblNoCuenta);
        panelRegistro.add(btnCrearCuenta);

        formulario.add(panelRegistro);

        panelDerecho.add(formulario);

        fondo.add(
                panelIzquierdo,
                BorderLayout.WEST
        );

        fondo.add(
                panelDerecho,
                BorderLayout.CENTER
        );

        // =========================
        // EVENTOS
        // =========================

        btnIngresar.addActionListener(
                e -> iniciarSesion()
        );

        txtPassword.addActionListener(
                e -> iniciarSesion()
        );

        btnCrearCuenta.addActionListener(e -> {

            RegistroNexusGym registro =
                    new RegistroNexusGym();

            registro.setVisible(true);

            dispose();
        });

        SwingUtilities.invokeLater(
                () -> txtCorreo.requestFocusInWindow()
        );
    }

    // ==========================================================
    // INICIAR SESIÓN
    // ==========================================================

    private void iniciarSesion() {

        String correo =
                txtCorreo.getText().trim();

        String contraseña =
                new String(
                        txtPassword.getPassword()
                );

        if (correo.isEmpty()
                || contraseña.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Por favor ingresa el correo y la contraseña.",
                    "Campos incompletos",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        // ==========================================
        // CONEXIÓN CORREGIDA
        // ==========================================

        Conexion conexionBD =
                Conexion.getInstancia();

        Connection conexion =
                conexionBD.conectar();

        if (conexion == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo conectar con la base de datos.",
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try {

            // ==================================================
            // 1. BUSCAR EN USUARIOS INTERNOS
            // ==================================================

            String sqlInterno =
                    "SELECT * FROM usuarios_internos "
                    + "WHERE email = ? "
                    + "AND estado = 'ACTIVO'";

            try (PreparedStatement pst =
                         conexion.prepareStatement(
                                 sqlInterno
                         )) {

                pst.setString(1, correo);

                try (ResultSet rs =
                             pst.executeQuery()) {

                    if (rs.next()) {

                        String contraseñaBD =
                                rs.getString(
                                        "password_hash"
                                );

                        if (contraseñaBD != null
                                && !contraseñaBD.isEmpty()) {

                            BCrypt.Result resultado =
                                    BCrypt.verifyer().verify(
                                            contraseña.toCharArray(),
                                            contraseñaBD
                                    );

                            if (resultado.verified) {

                                String nombres =
                                        rs.getString(
                                                "nombres"
                                        );

                                String correoUsuario =
                                        rs.getString(
                                                "email"
                                        );

                                try (
                                    PreparedStatement pstAcceso =
                                        conexion.prepareStatement(
                                            "UPDATE usuarios_internos "
                                            + "SET ultimo_acceso = NOW() "
                                            + "WHERE id_usuario = ?"
                                        )
                                ) {

                                    pstAcceso.setInt(
                                            1,
                                            rs.getInt(
                                                    "id_usuario"
                                            )
                                    );

                                    pstAcceso.executeUpdate();
                                }

                                JOptionPane.showMessageDialog(
                                        this,
                                        "Bienvenido, "
                                        + nombres
                                        + ".",
                                        "Inicio de sesión exitoso",
                                        JOptionPane.INFORMATION_MESSAGE
                                );

                                new PanelNexusGym(
                                        nombres,
                                        correoUsuario
                                ).setVisible(true);

                                dispose();

                                return;
                            }
                        }

                        mostrarErrorLogin();
                        return;
                    }
                }
            }

            // ==================================================
            // 2. BUSCAR EN CLIENTES
            // ==================================================

            String sqlCliente =
                    "SELECT id_cliente, nombres, apellidos, "
                    + "email, password_hash "
                    + "FROM clientes "
                    + "WHERE email = ? "
                    + "AND estado = 'ACTIVO'";

            try (PreparedStatement pst =
                         conexion.prepareStatement(
                                 sqlCliente
                         )) {

                pst.setString(1, correo);

                try (ResultSet rs =
                             pst.executeQuery()) {

                    if (rs.next()) {

                        String contraseñaBD =
                                rs.getString(
                                        "password_hash"
                                );

                        if (contraseñaBD == null
                                || contraseñaBD.isEmpty()) {

                            JOptionPane.showMessageDialog(
                                    this,
                                    "Esta cuenta todavía no tiene una contraseña configurada.",
                                    "Contraseña no disponible",
                                    JOptionPane.WARNING_MESSAGE
                            );

                            return;
                        }

                        BCrypt.Result resultado =
                                BCrypt.verifyer().verify(
                                        contraseña.toCharArray(),
                                        contraseñaBD
                                );

                        if (resultado.verified) {

                            String nombres =
                                    rs.getString(
                                            "nombres"
                                    );

                            String correoUsuario =
                                    rs.getString(
                                            "email"
                                    );

                            JOptionPane.showMessageDialog(
                                    this,
                                    "Bienvenido, "
                                    + nombres
                                    + ".",
                                    "Inicio de sesión exitoso",
                                    JOptionPane.INFORMATION_MESSAGE
                            );

                            new PanelNexusGym(
                                    nombres,
                                    correoUsuario
                            ).setVisible(true);

                            dispose();

                            return;
                        }

                        mostrarErrorLogin();
                        return;
                    }
                }
            }

            // ==================================================
            // 3. NO EXISTE EL CORREO
            // ==================================================

            mostrarErrorLogin();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error de base de datos:\n"
                    + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            ex.printStackTrace();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Ocurrió un error al iniciar sesión:\n"
                    + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            ex.printStackTrace();

        }
    }

    // ==========================================================
    // ERROR DE LOGIN
    // ==========================================================

    private void mostrarErrorLogin() {

        JOptionPane.showMessageDialog(
                this,
                "El correo o la contraseña son incorrectos.",
                "Inicio de sesión",
                JOptionPane.ERROR_MESSAGE
        );

        txtPassword.setText("");
        txtPassword.requestFocusInWindow();
    }

    // ==========================================================
    // MAIN
    // ==========================================================

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {

            LoginNuevo ventana =
                    new LoginNuevo();

            ventana.setVisible(true);
        });
    }
}