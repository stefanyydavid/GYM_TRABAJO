package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import java.awt.*;

public class ServiciosNexusGym extends JFrame {

    public ServiciosNexusGym() {

        setTitle("Nexus Gym - Servicios");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(1160, 661);

        setResizable(false);

        setLocationRelativeTo(null);

        construirInterfaz();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout());

        principal.setBackground(
                new Color(15, 18, 20)
        );

        // ==================================
        // BARRA SUPERIOR
        // ==================================

        JPanel barraSuperior = new JPanel(
                new BorderLayout()
        );

        barraSuperior.setBackground(
                new Color(20, 24, 27)
        );

        barraSuperior.setBorder(
                BorderFactory.createEmptyBorder(
                        18, 30, 18, 30
                )
        );

        JLabel titulo = new JLabel(
                "NEXUS GYM"
        );

        titulo.setForeground(
                new Color(120, 255, 120)
        );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        25
                )
        );

        barraSuperior.add(
                titulo,
                BorderLayout.WEST
        );

        JLabel subtitulo = new JLabel(
                "Nuestros servicios"
        );

        subtitulo.setForeground(
                Color.WHITE
        );

        subtitulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        20
                )
        );

        barraSuperior.add(
                subtitulo,
                BorderLayout.CENTER
        );

        JButton volver = new JButton(
                "VOLVER"
        );

        volver.setForeground(Color.WHITE);

        volver.setBackground(
                new Color(35, 42, 45)
        );

        volver.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        13
                )
        );

        volver.setFocusPainted(false);

        volver.setBorderPainted(false);

        volver.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        volver.addActionListener(e -> {

            new PaginaPrincipal().setVisible(true);

            dispose();
        });

        barraSuperior.add(
                volver,
                BorderLayout.EAST
        );

        principal.add(
                barraSuperior,
                BorderLayout.NORTH
        );

        // ==================================
        // CONTENIDO
        // ==================================

        JPanel contenido = new JPanel();

        contenido.setBackground(
                new Color(15, 18, 20)
        );

        contenido.setBorder(
                BorderFactory.createEmptyBorder(
                        35, 45, 35, 45
                )
        );

        contenido.setLayout(
                new GridLayout(
                        2,
                        2,
                        25,
                        25
                )
        );

        // ==================================
        // SERVICIO 1
        // ==================================

        contenido.add(
                crearServicio(
                        "ENTRENAMIENTO PERSONAL",
                        "Entrenamiento guiado y personalizado.",
                        "Rutinas adaptadas a tus objetivos."
                )
        );

        // ==================================
        // SERVICIO 2
        // ==================================

        contenido.add(
                crearServicio(
                        "ZONA DE MUSCULACIÓN",
                        "Equipamiento para entrenamiento de fuerza.",
                        "Espacio diseñado para tu entrenamiento."
                )
        );

        // ==================================
        // SERVICIO 3
        // ==================================

        contenido.add(
                crearServicio(
                        "CARDIO",
                        "Área dedicada al entrenamiento cardiovascular.",
                        "Mejora tu resistencia y condición física."
                )
        );

        // ==================================
        // SERVICIO 4
        // ==================================

        contenido.add(
                crearServicio(
                        "CLASES GRUPALES",
                        "Entrenamientos dirigidos en grupo.",
                        "Diferentes modalidades y horarios."
                )
        );

        principal.add(
                contenido,
                BorderLayout.CENTER
        );

        setContentPane(principal);
    }

    // ==================================
    // CREAR TARJETA
    // ==================================

    private JPanel crearServicio(
            String nombre,
            String descripcion,
            String detalle) {

        JPanel tarjeta = new JPanel();

        tarjeta.setBackground(
                new Color(25, 30, 32)
        );

        tarjeta.setBorder(
                BorderFactory.createCompoundBorder(

                        BorderFactory.createLineBorder(
                                new Color(55, 65, 68),
                                1
                        ),

                        BorderFactory.createEmptyBorder(
                                25, 25, 25, 25
                        )
                )
        );

        tarjeta.setLayout(
                new BoxLayout(
                        tarjeta,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel titulo = new JLabel(
                nombre
        );

        titulo.setForeground(
                new Color(120, 255, 120)
        );

        titulo.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        20
                )
        );

        titulo.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        tarjeta.add(titulo);

        tarjeta.add(
                Box.createVerticalStrut(18)
        );

        JLabel texto = new JLabel(
                "<html>"
                + descripcion
                + "<br><br>"
                + detalle
                + "</html>"
        );

        texto.setForeground(
                Color.WHITE
        );

        texto.setFont(
                new Font(
                        "SansSerif",
                        Font.PLAIN,
                        14
                )
        );

        texto.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        tarjeta.add(texto);

        tarjeta.add(
                Box.createVerticalGlue()
        );

        JButton ver = new JButton(
                "VER SERVICIO"
        );

        ver.setForeground(
                Color.BLACK
        );

        ver.setBackground(
                new Color(120, 255, 120)
        );

        ver.setFont(
                new Font(
                        "SansSerif",
                        Font.BOLD,
                        12
                )
        );

        ver.setFocusPainted(false);

        ver.setBorderPainted(false);

        ver.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        ver.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        ver.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                    this,
                    nombre
                            + "\n\n"
                            + descripcion
                            + "\n\n"
                            + detalle,
                    "Información del servicio",
                    JOptionPane.INFORMATION_MESSAGE
            );
        });

        tarjeta.add(ver);

        return tarjeta;
    }

    // ==================================
    // MAIN
    // ==================================

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {

            ServiciosNexusGym ventana =
                    new ServiciosNexusGym();

            ventana.setVisible(true);
        });
    }
}