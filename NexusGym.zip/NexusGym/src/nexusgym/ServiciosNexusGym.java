
package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicios de Nexus Gym dibujado sobre SERVICIOS.jpg.
 * Incluye el efecto hover de la barra superior de PaginaPrincipal.
 */
public class ServiciosNexusGym extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color NARANJA_CLARO = new Color(255, 139, 62);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color FONDO = new Color(13, 15, 20);

    // Dimensiones reales de SERVICIOS.jpg.
    private static final int REF_ANCHO = 1536;
    private static final int REF_ALTO = 929;

    private enum Tipo {
        MENU, BOTON, CERRAR
    }

    private record Zona(
            String nombre,
            double x,
            double y,
            double w,
            double h,
            Tipo tipo,
            Runnable accion
    ) {}

    private final List<Zona> zonas = new ArrayList<>();

    private BufferedImage fondo;
    private Zona zonaHover;
    private boolean avisoVisible = true;
    private Lienzo lienzo;

    public ServiciosNexusGym() {

        setTitle("Nexus Gym - Servicios");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagen();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1152, 697));

        setContentPane(lienzo);
        setMinimumSize(new Dimension(950, 574));

        pack();
        setLocationRelativeTo(null);

        configurarTeclado();
    }

    private void cargarImagen() {

        URL url = getClass().getResource("/nexusgym/SERVICIOS.jpg");

        if (url == null) {
            url = getClass().getResource("/nexusgym/servicios.jpg");
        }

        if (url != null) {
            try {
                fondo = ImageIO.read(url);
            } catch (IOException ignored) {
                fondo = null;
            }
        }
    }

    private void crearZonas() {

        // Barra superior.
        zonas.add(new Zona(
                "NEXUS GYM", 65, 17, 225, 52,
                Tipo.MENU, this::volverInicio
        ));

        zonas.add(new Zona(
                "SEDES", 326, 18, 86, 47,
                Tipo.MENU, () -> abrir(new SedesNexusGym())
        ));

        zonas.add(new Zona(
                "SERVICIOS", 441, 18, 132, 47,
                Tipo.MENU, null
        ));

        zonas.add(new Zona(
                "CLASES", 605, 18, 95, 47,
                Tipo.MENU, () -> abrir(new ClasesNexusGym())
        ));

        zonas.add(new Zona(
                "SUSCRIPCIONES / PLANES", 728, 18, 294, 47,
                Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de suscripciones y planes estará disponible próximamente."
                )
        ));

        zonas.add(new Zona(
                "PAGOS", 1053, 18, 94, 47,
                Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de pagos estará disponible próximamente."
                )
        ));

        zonas.add(new Zona(
                "INICIAR SESIÓN", 1281, 8, 230, 58,
                Tipo.BOTON, () -> abrir(new LoginNuevo())
        ));

        // Aviso promocional.
        zonas.add(new Zona(
                "Más info", 902, 92, 105, 40,
                Tipo.MENU,
                () -> mostrarAviso(
                        "Comienza tu viaje con 1 mes gratis. "
                        + "Consulta las condiciones en recepción de Nexus Gym."
                )
        ));

        zonas.add(new Zona(
                "Cerrar aviso", 1477, 91, 39, 42,
                Tipo.CERRAR,
                () -> {
                    avisoVisible = false;
                    lienzo.repaint();
                }
        ));

        // Tarjetas de servicios: se mantienen sus coordenadas y acciones.
        zonas.add(new Zona(
                "ENTRENAMIENTO PERSONAL", 59, 420, 205, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "ENTRENAMIENTO PERSONAL",
                        "Entrenamiento guiado y personalizado.",
                        "Rutinas adaptadas a tus objetivos con acompañamiento durante tu progreso."
                )
        ));

        zonas.add(new Zona(
                "ZONA DE MUSCULACIÓN", 811, 420, 207, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "ZONA DE MUSCULACIÓN",
                        "Equipamiento para entrenamiento de fuerza.",
                        "Espacio equipado para trabajar fuerza, técnica y progresión."
                )
        ));

        zonas.add(new Zona(
                "CARDIO", 59, 768, 205, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "CARDIO",
                        "Área dedicada al entrenamiento cardiovascular.",
                        "Entrena tu resistencia y condición física con máquinas cardiovasculares."
                )
        ));

        zonas.add(new Zona(
                "CLASES GRUPALES", 811, 768, 222, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "CLASES GRUPALES",
                        "Entrenamientos dirigidos en grupo.",
                        "Consulta en recepción las modalidades y horarios disponibles."
                )
        ));
    }

    private void configurarTeclado() {

        getRootPane().getInputMap(
                JComponent.WHEN_IN_FOCUSED_WINDOW
        ).put(
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                "volver"
        );

        getRootPane().getActionMap().put(
                "volver",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(
                            java.awt.event.ActionEvent e
                    ) {
                        volverInicio();
                    }
                }
        );
    }

    private void volverInicio() {
        abrir(new PaginaPrincipal());
    }

    private void abrir(JFrame ventana) {
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    private void mostrarAviso(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void mostrarServicio(
            String nombre,
            String descripcion,
            String detalle
    ) {

        String texto = nombre
                + "\n\n" + descripcion
                + "\n\n" + detalle;

        JOptionPane.showMessageDialog(
                this,
                texto,
                "Servicios Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private class Lienzo extends JPanel {

        Lienzo() {

            setBackground(FONDO);
            setCursor(Cursor.getDefaultCursor());

            MouseAdapter raton = new MouseAdapter() {

                @Override
                public void mouseMoved(MouseEvent e) {

                    Zona encontrada = buscarZona(e.getPoint());

                    if (encontrada != zonaHover) {
                        zonaHover = encontrada;

                        setCursor(Cursor.getPredefinedCursor(
                                encontrada != null
                                        ? Cursor.HAND_CURSOR
                                        : Cursor.DEFAULT_CURSOR
                        ));

                        repaint();
                    }

                    if (encontrada != null) {
                        setToolTipText(encontrada.nombre());
                    } else {
                        setToolTipText(null);
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {

                    zonaHover = null;
                    setCursor(Cursor.getDefaultCursor());
                    setToolTipText(null);
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {

                    if (e.getButton() != MouseEvent.BUTTON1) {
                        return;
                    }

                    Zona encontrada = buscarZona(e.getPoint());

                    if (encontrada != null
                            && encontrada.accion() != null) {
                        encontrada.accion().run();
                    }
                }
            };

            addMouseListener(raton);
            addMouseMotionListener(raton);
        }

        private Zona buscarZona(Point punto) {

            double sx = getWidth() / (double) REF_ANCHO;
            double sy = getHeight() / (double) REF_ALTO;

            for (int i = zonas.size() - 1; i >= 0; i--) {

                Zona z = zonas.get(i);

                if (z.tipo() == Tipo.CERRAR && !avisoVisible) {
                    continue;
                }

                Rectangle r = new Rectangle(
                        (int) Math.round(z.x() * sx),
                        (int) Math.round(z.y() * sy),
                        (int) Math.round(z.w() * sx),
                        (int) Math.round(z.h() * sy)
                );

                if (r.contains(punto)) {
                    return z;
                }
            }

            return null;
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            // Dibujar la imagen original.
            if (fondo != null) {

                g2.drawImage(
                        fondo,
                        0, 0,
                        getWidth(), getHeight(),
                        null
                );

            } else {

                g2.setColor(FONDO);
                g2.fillRect(
                        0, 0,
                        getWidth(), getHeight()
                );

                g2.setColor(CREMA);
                g2.setFont(
                        new Font("Segoe UI", Font.BOLD, 24)
                );

                g2.drawString(
                        "No se encontró /nexusgym/SERVICIOS.jpg",
                        35, 50
                );
            }

            double sx = getWidth() / (double) REF_ANCHO;
            double sy = getHeight() / (double) REF_ALTO;

            // Ocultar el aviso sin modificar el resto de la imagen.
            if (!avisoVisible) {

                g2.setColor(FONDO);

                g2.fillRect(
                        0,
                        (int) Math.round(86 * sy),
                        getWidth(),
                        Math.max(
                                1,
                                (int) Math.round(54 * sy)
                        )
                );
            }

            // Efectos hover: mismo estilo que PaginaPrincipal.
            if (zonaHover != null) {

                Zona z = zonaHover;

                int x = (int) Math.round(z.x() * sx);
                int y = (int) Math.round(z.y() * sy);
                int w = (int) Math.round(z.w() * sx);
                int h = (int) Math.round(z.h() * sy);

                if (z.tipo() == Tipo.MENU) {

                    // Recuadro translúcido redondeado.
                    g2.setColor(
                            new Color(255, 255, 255, 26)
                    );

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x, y, w, h, 12, 12
                            )
                    );

                    // Línea naranja inferior centrada.
                    double ancho = w * 0.62;

                    g2.setColor(NARANJA);

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x + (w - ancho) / 2.0,
                                    y + h - 4,
                                    ancho,
                                    3,
                                    3, 3
                            )
                    );

                } else if (z.tipo() == Tipo.BOTON) {

                    // Resaltado naranja de los botones.
                    g2.setColor(
                            new Color(232, 106, 36, 48)
                    );

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x, y, w, h, 12, 12
                            )
                    );

                    g2.setColor(NARANJA);
                    g2.setStroke(new BasicStroke(2f));

                    g2.draw(
                            new RoundRectangle2D.Double(
                                    x + 1,
                                    y + 1,
                                    w - 2,
                                    h - 2,
                                    12, 12
                            )
                    );
                }
            }

            g2.dispose();
        }
    }

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(
                () -> new ServiciosNexusGym().setVisible(true)
        );
    }
}
