package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Servicios de Nexus Gym dibujado sobre SERVICIOS.jpg.
 * Incluye el efecto hover de la barra superior de PaginaPrincipal.
 */
public class ServiciosNexusGym extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color NARANJA_CLARO = new Color(255, 139, 62);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color FONDO = new Color(13, 15, 20);
    private static final Color VERDE = new Color(102, 165, 88);
    private static final Color GRIS = new Color(150, 152, 158);
    private static final Color TEXTO_OSCURO = new Color(32, 28, 24);

    // Dimensiones reales de SERVICIOS.jpg.
    private static final int REF_ANCHO = 1536;
    private static final int REF_ALTO = 929;

    private enum Tipo {
        MENU, BOTON, CERRAR
    }

    private record Zona(
            String nombre,
            double x,
            double y,
            double w,
            double h,
            Tipo tipo,
            Runnable accion
    ) {}

    private final List<Zona> zonas = new ArrayList<>();

    private BufferedImage fondo;
    private Zona zonaHover;
    private boolean avisoVisible = true;
    private Lienzo lienzo;

    public ServiciosNexusGym() {

        setTitle("Nexus Gym - Servicios");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagen();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1152, 697));

        setContentPane(lienzo);
        setMinimumSize(new Dimension(950, 574));

        pack();
        setLocationRelativeTo(null);

        configurarTeclado();
    }

    private void cargarImagen() {

        URL url = getClass().getResource("/nexusgym/SERVICIOS.jpg");

        if (url == null) {
            url = getClass().getResource("/nexusgym/servicios.jpg");
        }

        if (url != null) {
            try {
                fondo = ImageIO.read(url);
            } catch (IOException ignored) {
                fondo = null;
            }
        }
    }

    private void crearZonas() {

        // Barra superior.
        zonas.add(new Zona(
                "NEXUS GYM", 65, 17, 225, 52,
                Tipo.MENU, this::volverInicio
        ));

        zonas.add(new Zona(
                "SEDES", 326, 18, 86, 47,
                Tipo.MENU, () -> abrir(new SedesNexusGym())
        ));

        zonas.add(new Zona(
                "SERVICIOS", 441, 18, 132, 47,
                Tipo.MENU, null
        ));

        zonas.add(new Zona(
                "CLASES", 605, 18, 95, 47,
                Tipo.MENU, () -> abrir(new ClasesNexusGym())
        ));

        zonas.add(new Zona(
                "SUSCRIPCIONES / PLANES", 728, 18, 294, 47,
                Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de suscripciones y planes estará disponible próximamente."
                )
        ));

        zonas.add(new Zona(
                "PAGOS", 1053, 18, 94, 47,
                Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de pagos estará disponible próximamente."
                )
        ));

        zonas.add(new Zona(
                "INICIAR SESIÓN", 1281, 8, 230, 58,
                Tipo.BOTON, () -> abrir(new LoginNuevo())
        ));

        // Aviso promocional.
        zonas.add(new Zona(
                "Más info", 902, 92, 105, 40,
                Tipo.MENU,
                () -> mostrarAviso(
                        "Comienza tu viaje con 1 mes gratis. "
                        + "Consulta las condiciones en recepción de Nexus Gym."
                )
        ));

        zonas.add(new Zona(
                "Cerrar aviso", 1477, 91, 39, 42,
                Tipo.CERRAR,
                () -> {
                    avisoVisible = false;
                    lienzo.repaint();
                }
        ));

        // Tarjetas de servicios.
        zonas.add(new Zona(
                "ENTRENAMIENTO PERSONAL", 59, 420, 205, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "ENTRENAMIENTO PERSONAL",
                        "Entrenamiento guiado y personalizado.",
                        "Rutinas adaptadas a tus objetivos con acompañamiento durante tu progreso."
                )
        ));

        zonas.add(new Zona(
                "ZONA DE MUSCULACIÓN", 811, 420, 207, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "ZONA DE MUSCULACIÓN",
                        "Equipamiento para entrenamiento de fuerza.",
                        "Espacio equipado para trabajar fuerza, técnica y progresión."
                )
        ));

        zonas.add(new Zona(
                "CARDIO", 59, 768, 205, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "CARDIO",
                        "Área dedicada al entrenamiento cardiovascular.",
                        "Entrena tu resistencia y condición física con máquinas cardiovasculares."
                )
        ));

        zonas.add(new Zona(
                "CLASES GRUPALES", 811, 768, 222, 51,
                Tipo.BOTON,
                () -> mostrarServicio(
                        "CLASES GRUPALES",
                        "Entrenamientos dirigidos en grupo.",
                        "Consulta en recepción las modalidades y horarios disponibles."
                )
        ));
    }

    private void configurarTeclado() {

        getRootPane().getInputMap(
                JComponent.WHEN_IN_FOCUSED_WINDOW
        ).put(
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                "volver"
        );

        getRootPane().getActionMap().put(
                "volver",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(
                            java.awt.event.ActionEvent e
                    ) {
                        volverInicio();
                    }
                }
        );
    }

    private void volverInicio() {
        abrir(new PaginaPrincipal());
    }

    private void abrir(JFrame ventana) {
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    private void mostrarAviso(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // =====================================================================
    //  UTILIDADES DE ESTILO
    // =====================================================================

    private static String familiaFuente;

    private static Font fuente(int estilo, int tam) {
        if (familiaFuente == null) {
            Set<String> disponibles = new HashSet<>(Arrays.asList(
                    GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
            familiaFuente = "SansSerif";
            for (String f : new String[]{"Montserrat", "Poppins", "Roboto", "Segoe UI", "Helvetica Neue"}) {
                if (disponibles.contains(f)) {
                    familiaFuente = f;
                    break;
                }
            }
        }
        return new Font(familiaFuente, estilo, tam);
    }

    private static Font espaciado(Font f, float tracking) {
        Map<java.awt.font.TextAttribute, Object> m = new HashMap<>();
        m.put(java.awt.font.TextAttribute.TRACKING, tracking);
        return f.deriveFont(m);
    }

    private static void calidad(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    private static String recortar(String t, FontMetrics fm, int max) {
        if (t == null) return "";
        if (max <= 10) return "";
        if (fm.stringWidth(t) <= max) return t;
        String s = t;
        while (s.length() > 1 && fm.stringWidth(s + "…") > max) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "…";
    }

    private static int baseline(FontMetrics fm, int alto) {
        return (alto - fm.getHeight()) / 2 + fm.getAscent();
    }

    private static JLabel etiqueta(String texto, Font fuente, Color color) {
        JLabel l = new JLabel(texto);
        l.setFont(fuente);
        l.setForeground(color);
        return l;
    }

    private static void fijarAlto(JComponent c, int alto) {
        c.setPreferredSize(new Dimension(100, alto));
        c.setMinimumSize(new Dimension(0, alto));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, alto));
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    // ---------- Contenedor principal con sombra y degradado ----------
    private static class Tarjeta extends JPanel {
        static final int M = 18;

        Tarjeta() {
            super(new BorderLayout());
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(M, M, M, M));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setComposite(AlphaComposite.Clear);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setComposite(AlphaComposite.SrcOver);

            int w = getWidth();
            int h = getHeight();
            for (int k = 0; k < M; k++) {
                g2.setColor(new Color(0, 0, 0, 6));
                g2.fill(new RoundRectangle2D.Double(M - k, M - k + 5, w - 2 * M + 2 * k,
                        h - 2 * M + 2 * k, 24 + k, 24 + k));
            }
            RoundRectangle2D cuerpo = new RoundRectangle2D.Double(M, M, w - 2 * M, h - 2 * M, 24, 24);
            g2.setPaint(new GradientPaint(0, M, new Color(24, 27, 35), 0, h - M, new Color(11, 13, 17)));
            g2.fill(cuerpo);
            g2.setPaint(new RadialGradientPaint(new java.awt.geom.Point2D.Float(M + 40, h - M),
                    w * 0.55f, new float[]{0f, 1f},
                    new Color[]{new Color(232, 106, 36, 38), new Color(232, 106, 36, 0)}));
            g2.fill(cuerpo);
            g2.setColor(new Color(255, 255, 255, 38));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new RoundRectangle2D.Double(M + 0.5, M + 0.5, w - 2 * M - 1, h - 2 * M - 1, 24, 24));
            g2.dispose();
        }
    }

    // ---------- Cabecera tipo hero con luces geométricas ----------
    private static class Cabecera extends JPanel {
        private final String nombre;
        private final String subtitulo;
        private final String insignia;

        Cabecera(String nombre, String subtitulo, String insignia) {
            super(new BorderLayout());
            this.nombre = nombre.toUpperCase();
            this.subtitulo = subtitulo;
            this.insignia = insignia;
            setOpaque(false);
            setPreferredSize(new Dimension(100, 150));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            g2.setClip(new Rectangle(0, 0, w, h));
            RoundRectangle2D forma = new RoundRectangle2D.Double(0, 0, w, h + 30, 24, 24);
            g2.setPaint(new GradientPaint(0, 0, new Color(8, 10, 14), w, h, new Color(40, 45, 57)));
            g2.fill(forma);
            g2.setPaint(new RadialGradientPaint(new java.awt.geom.Point2D.Float(w * 0.82f, h * 0.1f),
                    w * 0.45f, new float[]{0f, 1f},
                    new Color[]{new Color(232, 106, 36, 100), new Color(232, 106, 36, 0)}));
            g2.fill(forma);

            Path2D.Double poligono = new Path2D.Double();
            poligono.moveTo(w * 0.50, h * 0.34);
            poligono.lineTo(w * 0.73, h * 0.10);
            poligono.lineTo(w * 0.91, h * 0.46);
            poligono.lineTo(w * 0.66, h * 0.70);
            poligono.closePath();
            Path2D.Double diagonal = new Path2D.Double();
            diagonal.moveTo(w * 0.73, h * 0.10);
            diagonal.lineTo(w * 0.66, h * 0.70);
            float[] anchos = {12f, 7f, 3f};
            int[] alfas = {22, 45, 235};
            for (int i = 0; i < anchos.length; i++) {
                g2.setStroke(new BasicStroke(anchos[i], BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.setColor(new Color(255, 255, 255, alfas[i]));
                g2.draw(poligono);
                g2.draw(diagonal);
            }

            g2.setPaint(new GradientPaint(0, 0, new Color(8, 10, 14, 215), w * 0.62f, 0, new Color(8, 10, 14, 0)));
            g2.fill(forma);

            g2.setPaint(new GradientPaint(0, 0, NARANJA, w, 0, new Color(232, 106, 36, 0)));
            g2.fillRect(0, h - 3, w, 3);

            g2.setFont(espaciado(fuente(Font.BOLD, 12), 0.25f));
            g2.setColor(NARANJA);
            g2.drawString("NEXUS GYM", 32, 40);

            Font fNombre = fuente(Font.BOLD, 32);
            g2.setFont(fNombre);
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            g2.drawString(recortar(nombre, fm, (int) (w * 0.62)), 32, 88);

            g2.setFont(espaciado(fuente(Font.PLAIN, 12), 0.12f));
            g2.setColor(GRIS);
            g2.drawString(subtitulo, 32, 118);
            int anchoSub = g2.getFontMetrics().stringWidth(subtitulo);

            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.12f));
            int anchoIns = g2.getFontMetrics().stringWidth(insignia);
            int pw = anchoIns + 34;
            int bx = 32 + anchoSub + 14;
            g2.setColor(new Color(102, 165, 88, 45));
            g2.fillRoundRect(bx, 104, pw, 20, 20, 20);
            g2.setColor(VERDE);
            g2.fillOval(bx + 9, 111, 6, 6);
            g2.drawString(insignia, bx + 22, 118);
            g2.dispose();
        }
    }

    // ---------- Botón de cerrar dibujado ----------
    private static class BotonCerrar extends JButton {
        private boolean hover;

        BotonCerrar() {
            setPreferredSize(new Dimension(34, 34));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setColor(hover ? NARANJA : new Color(255, 255, 255, 28));
            g2.fillOval(1, 1, getWidth() - 2, getHeight() - 2);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int c = getWidth() / 2;
            g2.drawLine(c - 5, c - 5, c + 5, c + 5);
            g2.drawLine(c + 5, c - 5, c - 5, c + 5);
            g2.dispose();
        }
    }

    // ---------- Botones principales ----------
    private static class BotonNexus extends JButton {
        private boolean hover;
        private final boolean relleno;

        BotonNexus(String texto, boolean relleno) {
            super(texto);
            this.relleno = relleno;
            setFont(espaciado(fuente(Font.BOLD, 12), 0.1f));
            setForeground(Color.WHITE);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(166, 54));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            int m = 7;
            RoundRectangle2D forma = new RoundRectangle2D.Double(m, m, w - 2 * m, h - 2 * m, 12, 12);
            if (relleno) {
                if (hover) {
                    for (int i = 1; i <= 6; i++) {
                        g2.setColor(new Color(232, 106, 36, 16));
                        g2.fill(new RoundRectangle2D.Double(m - i, m - i, w - 2 * m + 2 * i,
                                h - 2 * m + 2 * i, 12 + i, 12 + i));
                    }
                }
                boolean pulsado = getModel().isPressed();
                g2.setPaint(new GradientPaint(0, m,
                        pulsado ? new Color(214, 92, 24) : NARANJA_CLARO,
                        0, h - m,
                        pulsado ? new Color(170, 70, 14) : new Color(214, 92, 24)));
                g2.fill(forma);
                g2.setColor(new Color(255, 255, 255, 55));
                g2.setStroke(new BasicStroke(1f));
                g2.draw(new RoundRectangle2D.Double(m + 0.5, m + 0.5, w - 2 * m - 1, h - 2 * m - 1, 12, 12));
            } else {
                g2.setColor(hover ? new Color(232, 106, 36, 50) : new Color(255, 255, 255, 8));
                g2.fill(forma);
                g2.setColor(hover ? NARANJA : new Color(232, 106, 36, 170));
                g2.setStroke(new BasicStroke(1.6f));
                g2.draw(new RoundRectangle2D.Double(m + 0.8, m + 0.8, w - 2 * m - 1.6, h - 2 * m - 1.6, 12, 12));
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ---------- Tarjeta de estadística ----------
    private static class Tile extends JPanel {
        private final String valor;
        private final String titulo;

        Tile(String valor, String titulo) {
            this.valor = valor;
            this.titulo = titulo;
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 16, 16);
            g2.setPaint(new GradientPaint(0, 0, new Color(38, 42, 52), 0, h, new Color(22, 25, 32)));
            g2.fill(r);
            g2.setColor(new Color(255, 255, 255, 30));
            g2.draw(r);
            g2.setColor(NARANJA);
            g2.fillRoundRect(0, 18, 4, h - 36, 4, 4);

            g2.setFont(fuente(Font.BOLD, 26));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            g2.drawString(recortar(valor, fm, w - 36), 20, 40);
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.12f));
            fm = g2.getFontMetrics();
            g2.setColor(GRIS);
            g2.drawString(recortar(titulo, fm, w - 30), 20, 62);
            g2.dispose();
        }
    }

    // ---------- Tarjeta crema ----------
    private static class TarjetaCrema extends JPanel {
        TarjetaCrema() {
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            g2.setColor(new Color(0, 0, 0, 40));
            g2.fill(new RoundRectangle2D.Double(2, 5, w - 4, h - 5, 18, 18));
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, w, h - 4, 18, 18);
            g2.setPaint(new GradientPaint(0, 0, new Color(250, 244, 233), 0, h, new Color(232, 221, 202)));
            g2.fill(r);
            g2.setColor(NARANJA);
            g2.fillRoundRect(0, 0, w, 4, 4, 4);
            g2.dispose();
        }
    }

    private JPanel celdaTexto(String titulo, String texto) {
        JPanel c = new JPanel();
        c.setOpaque(false);
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        JLabel t = etiqueta(titulo, espaciado(fuente(Font.BOLD, 10), 0.15f), NARANJA);
        JLabel v = etiqueta("<html><div style='width:270px'>" + texto + "</div></html>",
                fuente(Font.BOLD, 14), TEXTO_OSCURO);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        v.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.add(t);
        c.add(Box.createVerticalStrut(6));
        c.add(v);
        return c;
    }

    // ---------- Fila de datos (3 columnas) ----------
    private static class FilaDato extends JPanel {
        private final String[] datos;
        private final boolean encabezado;
        private final boolean par;
        private boolean hover;

        FilaDato(String[] datos, boolean encabezado, boolean par) {
            this.datos = datos;
            this.encabezado = encabezado;
            this.par = par;
            setOpaque(false);
            if (!encabezado) {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                });
            }
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            if (encabezado) {
                g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.15f));
                FontMetrics fm = g2.getFontMetrics();
                g2.setColor(GRIS);
                int y = baseline(fm, h);
                g2.drawString(datos[0], 16, y);
                g2.drawString(datos[1], 140, y);
                g2.drawString(datos[2], w - 16 - fm.stringWidth(datos[2]), y);
                g2.dispose();
                return;
            }
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 2, w, h - 4, 12, 12);
            g2.setColor(hover ? new Color(232, 106, 36, 36)
                    : (par ? new Color(255, 255, 255, 12) : new Color(255, 255, 255, 5)));
            g2.fill(r);
            if (hover) {
                g2.setColor(NARANJA);
                g2.fillRoundRect(0, 9, 3, h - 18, 3, 3);
            }

            // Píldora
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.08f));
            FontMetrics fm = g2.getFontMetrics();
            int ph = 24;
            int py = (h - ph) / 2;
            g2.setColor(new Color(232, 106, 36, 46));
            g2.fillRoundRect(16, 0 + py, 112, ph, ph, ph);
            g2.setColor(NARANJA);
            String pill = recortar(datos[0].toUpperCase(), fm, 100);
            g2.drawString(pill, 16 + (112 - fm.stringWidth(pill)) / 2, py + baseline(fm, ph));

            // Columna derecha
            g2.setFont(fuente(Font.PLAIN, 12));
            fm = g2.getFontMetrics();
            String der = recortar(datos[2], fm, 250);
            int anchoDer = fm.stringWidth(der);
            g2.setColor(GRIS);
            g2.drawString(der, w - 16 - anchoDer, baseline(fm, h));

            // Título
            g2.setFont(fuente(Font.BOLD, 13));
            fm = g2.getFontMetrics();
            g2.setColor(Color.WHITE);
            int maxTitulo = w - 140 - 16 - anchoDer - 16;
            g2.drawString(recortar(datos[1], fm, maxTitulo), 140, baseline(fm, h));
            g2.dispose();
        }
    }

    // ---------- Tarjeta de plan ----------
    private static class PlanCard extends JPanel {
        private final String[] datos;
        private boolean hover;

        PlanCard(String[] datos) {
            this.datos = datos;
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            RoundRectangle2D r = new RoundRectangle2D.Double(1, 1, w - 3, h - 3, 14, 14);
            g2.setPaint(hover
                    ? new GradientPaint(0, 0, new Color(60, 38, 26), 0, h, new Color(30, 22, 20))
                    : new GradientPaint(0, 0, new Color(36, 40, 50), 0, h, new Color(22, 25, 32)));
            g2.fill(r);
            g2.setColor(hover ? NARANJA : new Color(255, 255, 255, 32));
            g2.setStroke(new BasicStroke(hover ? 1.8f : 1f));
            g2.draw(r);

            g2.setFont(fuente(Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            String n = recortar(datos[0], fm, w - 16);
            g2.drawString(n, (w - fm.stringWidth(n)) / 2, 27);

            g2.setFont(fuente(Font.BOLD, 17));
            fm = g2.getFontMetrics();
            g2.setColor(NARANJA);
            String p = recortar(datos[1], fm, w - 12);
            g2.drawString(p, (w - fm.stringWidth(p)) / 2, 52);

            g2.setFont(fuente(Font.PLAIN, 11));
            fm = g2.getFontMetrics();
            g2.setColor(GRIS);
            g2.drawString(datos[2], (w - fm.stringWidth(datos[2])) / 2, 70);
            g2.dispose();
        }
    }

    // ---------- Panel que acompaña el ancho del scroll ----------
    private static class PanelScroll extends JPanel implements Scrollable {
        PanelScroll() {
            setOpaque(false);
        }
        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 18; }
        @Override public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 90; }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }

    // ---------- Barra de scroll delgada ----------
    private static class BarraNexus extends javax.swing.plaf.basic.BasicScrollBarUI {
        private JButton cero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            b.setMinimumSize(new Dimension(0, 0));
            b.setMaximumSize(new Dimension(0, 0));
            return b;
        }
        @Override protected JButton createDecreaseButton(int orientation) { return cero(); }
        @Override protected JButton createIncreaseButton(int orientation) { return cero(); }
        @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
        @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setColor(isThumbRollover() || isDragging ? NARANJA : new Color(255, 255, 255, 70));
            g2.fillRoundRect(r.x + 3, r.y + 2, r.width - 6, r.height - 4, 8, 8);
            g2.dispose();
        }
    }

    private JComponent tituloSeccion(String texto) {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setOpaque(false);
        p.add(etiqueta(texto, espaciado(fuente(Font.BOLD, 12), 0.2f), NARANJA), BorderLayout.WEST);
        JSeparator s = new JSeparator();
        s.setForeground(new Color(255, 255, 255, 35));
        p.add(s, BorderLayout.CENTER);
        fijarAlto(p, 26);
        return p;
    }

    // =====================================================================
    //  CONSULTAS A LA BASE DE DATOS
    // =====================================================================

    private List<String[]> filas(Connection cx, String sql) throws SQLException {
        List<String[]> res = new ArrayList<>();
        try (PreparedStatement ps = cx.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();
            while (rs.next()) {
                String[] f = new String[n];
                for (int i = 0; i < n; i++) {
                    String v = rs.getString(i + 1);
                    f[i] = v == null ? "" : v;
                }
                res.add(f);
            }
        }
        return res;
    }

    private String escalar(Connection cx, String sql) throws SQLException {
        List<String[]> r = filas(cx, sql);
        return r.isEmpty() ? "0" : r.get(0)[0];
    }

    private List<String[]> planes(Connection cx, boolean soloConEntrenador) throws SQLException {
        String sql = "SELECT nombre, precio, duracion_dias FROM planes WHERE activo = 1"
                + (soloConEntrenador ? " AND incluye_entrenador = 1" : "")
                + " ORDER BY precio + 0";
        java.text.NumberFormat moneda = java.text.NumberFormat.getInstance(
                java.util.Locale.forLanguageTag("es-CO"));
        List<String[]> res = new ArrayList<>();
        for (String[] f : filas(cx, sql)) {
            String precio = "$" + moneda.format((long) Double.parseDouble(f[1]));
            res.add(new String[]{f[0], precio, f[2] + " días"});
        }
        return res;
    }

    private void mostrarServicio(String nombre, String descripcion, String detalle) {
        Connection cx = Conexion.getInstancia().conectar();
        if (cx == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar con la base de datos.",
                    "Nexus Gym", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            String[][] tiles;
            String tituloLista;
            String[] encabezados;
            List<String[]> lista;
            String tituloPlanes = "PLANES DISPONIBLES";
            boolean soloEntrenador = false;
            String ctaTexto = "VER SEDES";
            Runnable ctaAccion = () -> abrir(new SedesNexusGym());

            switch (nombre) {
                case "ENTRENAMIENTO PERSONAL" -> {
                    tiles = new String[][]{
                            {escalar(cx, "SELECT COUNT(*) FROM entrenadores WHERE estado = 'ACTIVO'"),
                                    "ENTRENADORES ACTIVOS"},
                            {escalar(cx, "SELECT COUNT(*) FROM planes WHERE activo = 1 AND incluye_entrenador = 1"),
                                    "PLANES CON ENTRENADOR"},
                            {escalar(cx, "SELECT COUNT(*) FROM rutinas WHERE estado = 'ACTIVA'"),
                                    "RUTINAS ACTIVAS"}};
                    tituloLista = "NUESTROS ENTRENADORES";
                    encabezados = new String[]{"EXPERIENCIA", "ENTRENADOR", "ESPECIALIDAD"};
                    lista = filas(cx, "SELECT CONCAT('DESDE ', YEAR(fecha_contratacion)), "
                            + "CONCAT(nombres, ' ', apellidos), especialidad "
                            + "FROM entrenadores WHERE estado = 'ACTIVO' ORDER BY fecha_contratacion");
                    tituloPlanes = "PLANES CON ENTRENADOR";
                    soloEntrenador = true;
                }
                case "ZONA DE MUSCULACIÓN" -> {
                    tiles = new String[][]{
                            {escalar(cx, "SELECT COUNT(*) FROM ejercicios WHERE activo = 1 AND grupo_muscular <> 'Cardio'"),
                                    "EJERCICIOS"},
                            {escalar(cx, "SELECT COUNT(DISTINCT grupo_muscular) FROM ejercicios "
                                    + "WHERE activo = 1 AND grupo_muscular <> 'Cardio'"),
                                    "GRUPOS MUSCULARES"},
                            {escalar(cx, "SELECT COUNT(*) FROM entrenadores WHERE estado = 'ACTIVO' AND "
                                    + "(especialidad LIKE '%Musculaci%' OR especialidad LIKE '%fuerza%')"),
                                    "ENTRENADORES DE FUERZA"}};
                    tituloLista = "EJERCICIOS DISPONIBLES";
                    encabezados = new String[]{"GRUPO", "EJERCICIO", "DESCRIPCIÓN"};
                    lista = filas(cx, "SELECT UPPER(grupo_muscular), nombre, descripcion FROM ejercicios "
                            + "WHERE activo = 1 AND grupo_muscular <> 'Cardio' "
                            + "ORDER BY grupo_muscular, nombre");
                }
                case "CARDIO" -> {
                    tiles = new String[][]{
                            {escalar(cx, "SELECT COUNT(*) FROM ejercicios WHERE activo = 1 AND grupo_muscular = 'Cardio'"),
                                    "EQUIPOS CARDIO"},
                            {escalar(cx, "SELECT COUNT(*) FROM rutinas WHERE nombre LIKE '%Cardio%'"),
                                    "RUTINAS DE CARDIO"},
                            {escalar(cx, "SELECT COUNT(*) FROM entrenadores WHERE estado = 'ACTIVO' AND "
                                    + "(especialidad LIKE '%Cardio%' OR especialidad LIKE '%Acondicionamiento%')"),
                                    "ENTRENADORES"}};
                    tituloLista = "ACTIVIDADES CARDIOVASCULARES";
                    encabezados = new String[]{"TIPO", "ACTIVIDAD", "DESCRIPCIÓN"};
                    lista = filas(cx, "SELECT 'EQUIPO', nombre, descripcion FROM ejercicios "
                            + "WHERE activo = 1 AND grupo_muscular = 'Cardio' "
                            + "UNION ALL "
                            + "SELECT 'CLASE', nombre, descripcion FROM clases "
                            + "WHERE activo = 1 AND nombre IN ('Spinning', 'Zumba', 'Entrenamiento funcional')");
                }
                default -> {
                    tiles = new String[][]{
                            {escalar(cx, "SELECT COUNT(*) FROM clases WHERE activo = 1"), "CLASES"},
                            {escalar(cx, "SELECT COUNT(*) FROM horarios_clases WHERE activo = 1"),
                                    "HORARIOS SEMANALES"},
                            {escalar(cx, "SELECT COALESCE(SUM(CAST(capacidad AS UNSIGNED)), 0) FROM clases "
                                    + "WHERE activo = 1"), "CUPOS TOTALES"}};
                    tituloLista = "CLASES GRUPALES";
                    encabezados = new String[]{"HORARIOS", "CLASE", "CAPACIDAD"};
                    lista = filas(cx, "SELECT CONCAT(COUNT(h.id_horario), ' HORARIOS'), c.nombre, "
                            + "CONCAT('Cupo ', c.capacidad, ' personas') "
                            + "FROM clases c LEFT JOIN horarios_clases h "
                            + "ON h.id_clase = c.id_clase AND h.activo = 1 "
                            + "WHERE c.activo = 1 GROUP BY c.id_clase, c.nombre, c.capacidad "
                            + "ORDER BY c.nombre");
                    ctaTexto = "VER CLASES";
                    ctaAccion = () -> abrir(new ClasesNexusGym());
                }
            }

            List<String[]> listaPlanes = planes(cx, soloEntrenador);
            construirDialogoServicio(nombre, descripcion, detalle, tiles, tituloLista, encabezados,
                    lista, tituloPlanes, listaPlanes, ctaTexto, ctaAccion);

        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "No fue posible consultar el servicio.\n\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================================
    //  DIÁLOGO DE SERVICIO
    // =====================================================================

    private void construirDialogoServicio(String nombre, String descripcion, String detalle,
                                          String[][] tiles, String tituloLista, String[] encabezados,
                                          List<String[]> lista, String tituloPlanes,
                                          List<String[]> planes, String ctaTexto, Runnable ctaAccion) {
        final JDialog d = new JDialog(this, true);
        d.setUndecorated(true);
        boolean translucido = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
                .isWindowTranslucencySupported(GraphicsDevice.WindowTranslucency.PERPIXEL_TRANSLUCENT);
        d.setBackground(translucido ? new Color(0, 0, 0, 0) : FONDO);

        Tarjeta raiz = new Tarjeta();

        // ---------- Cabecera ----------
        Cabecera cab = new Cabecera(nombre, "SERVICIO NEXUS GYM", "DISPONIBLE");
        BotonCerrar btnX = new BotonCerrar();
        btnX.addActionListener(e -> d.dispose());
        JPanel esquina = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        esquina.setOpaque(false);
        esquina.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 16));
        esquina.add(btnX);
        cab.add(esquina, BorderLayout.NORTH);
        final int[] desfase = new int[2];
        MouseAdapter arrastre = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                desfase[0] = e.getXOnScreen() - d.getX();
                desfase[1] = e.getYOnScreen() - d.getY();
            }
            @Override public void mouseDragged(MouseEvent e) {
                d.setLocation(e.getXOnScreen() - desfase[0], e.getYOnScreen() - desfase[1]);
            }
        };
        cab.addMouseListener(arrastre);
        cab.addMouseMotionListener(arrastre);
        raiz.add(cab, BorderLayout.NORTH);

        // ---------- Cuerpo ----------
        PanelScroll cuerpo = new PanelScroll();
        cuerpo.setLayout(new BoxLayout(cuerpo, BoxLayout.Y_AXIS));
        cuerpo.setBorder(BorderFactory.createEmptyBorder(18, 28, 10, 28));

        JPanel filaTiles = new JPanel(new GridLayout(1, tiles.length, 12, 0));
        filaTiles.setOpaque(false);
        for (String[] t : tiles) {
            filaTiles.add(new Tile(t[0], t[1]));
        }
        fijarAlto(filaTiles, 84);
        cuerpo.add(filaTiles);
        cuerpo.add(Box.createVerticalStrut(16));

        TarjetaCrema crema = new TarjetaCrema();
        crema.setLayout(new GridLayout(1, 2, 24, 0));
        crema.setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));
        crema.add(celdaTexto("DE QUÉ TRATA", descripcion));
        crema.add(celdaTexto("QUÉ INCLUYE", detalle));
        fijarAlto(crema, 128);
        cuerpo.add(crema);
        cuerpo.add(Box.createVerticalStrut(22));

        cuerpo.add(tituloSeccion(tituloLista));
        cuerpo.add(Box.createVerticalStrut(6));
        if (lista.isEmpty()) {
            JLabel vacio = etiqueta("Sin información registrada por el momento.", fuente(Font.PLAIN, 13), GRIS);
            vacio.setBorder(BorderFactory.createEmptyBorder(8, 4, 8, 4));
            vacio.setAlignmentX(Component.LEFT_ALIGNMENT);
            cuerpo.add(vacio);
        } else {
            FilaDato enc = new FilaDato(encabezados, true, false);
            fijarAlto(enc, 26);
            cuerpo.add(enc);
            for (int i = 0; i < lista.size(); i++) {
                FilaDato fd = new FilaDato(lista.get(i), false, i % 2 == 0);
                fijarAlto(fd, 42);
                cuerpo.add(fd);
            }
        }
        cuerpo.add(Box.createVerticalStrut(22));

        if (!planes.isEmpty()) {
            cuerpo.add(tituloSeccion(tituloPlanes));
            cuerpo.add(Box.createVerticalStrut(10));
            JPanel filaPlanes = new JPanel(new GridLayout(1, planes.size(), 10, 0));
            filaPlanes.setOpaque(false);
            for (String[] p : planes) {
                filaPlanes.add(new PlanCard(p));
            }
            fijarAlto(filaPlanes, 86);
            cuerpo.add(filaPlanes);
        }
        cuerpo.add(Box.createVerticalStrut(8));

        JScrollPane sp = new JScrollPane(cuerpo,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
        sp.setViewportBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
        sp.getVerticalScrollBar().setUI(new BarraNexus());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        sp.getVerticalScrollBar().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        raiz.add(sp, BorderLayout.CENTER);

        // ---------- Pie ----------
        JPanel pie = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 22));
                g2.drawLine(24, 0, getWidth() - 24, 0);
                g2.dispose();
            }
        };
        pie.setOpaque(false);
        pie.setBorder(BorderFactory.createEmptyBorder(6, 28, 12, 18));
        pie.add(etiqueta("ESC para cerrar", fuente(Font.PLAIN, 11), GRIS), BorderLayout.WEST);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        botones.setOpaque(false);
        BotonNexus btnCerrar = new BotonNexus("CERRAR", false);
        btnCerrar.addActionListener(e -> d.dispose());
        BotonNexus btnCta = new BotonNexus(ctaTexto, true);
        btnCta.addActionListener(e -> {
            d.dispose();
            ctaAccion.run();
        });
        botones.add(btnCerrar);
        botones.add(btnCta);
        pie.add(botones, BorderLayout.EAST);
        raiz.add(pie, BorderLayout.SOUTH);

        d.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "cerrarServicio");
        d.getRootPane().getActionMap().put("cerrarServicio", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { d.dispose(); }
        });

        d.setContentPane(raiz);
        int altoPantalla = Toolkit.getDefaultToolkit().getScreenSize().height;
        d.setSize(new Dimension(800, Math.min(830, altoPantalla - 50)));
        d.setLocationRelativeTo(this);

        try {
            d.setOpacity(0f);
            final javax.swing.Timer fade = new javax.swing.Timer(15, null);
            fade.addActionListener(ev -> {
                float o = Math.min(1f, d.getOpacity() + 0.1f);
                try {
                    d.setOpacity(o);
                } catch (Exception ex) {
                    fade.stop();
                }
                if (o >= 1f) fade.stop();
            });
            fade.start();
        } catch (Exception ignorada) {
            // Si el sistema no soporta opacidad, se muestra directamente.
        }
        d.setVisible(true);
    }

    // =====================================================================
    //  LIENZO
    // =====================================================================

    private class Lienzo extends JPanel {

        Lienzo() {

            setBackground(FONDO);
            setCursor(Cursor.getDefaultCursor());

            MouseAdapter raton = new MouseAdapter() {

                @Override
                public void mouseMoved(MouseEvent e) {

                    Zona encontrada = buscarZona(e.getPoint());

                    if (encontrada != zonaHover) {
                        zonaHover = encontrada;

                        setCursor(Cursor.getPredefinedCursor(
                                encontrada != null
                                        ? Cursor.HAND_CURSOR
                                        : Cursor.DEFAULT_CURSOR
                        ));

                        repaint();
                    }

                    if (encontrada != null) {
                        setToolTipText(encontrada.nombre());
                    } else {
                        setToolTipText(null);
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {

                    zonaHover = null;
                    setCursor(Cursor.getDefaultCursor());
                    setToolTipText(null);
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {

                    if (e.getButton() != MouseEvent.BUTTON1) {
                        return;
                    }

                    Zona encontrada = buscarZona(e.getPoint());

                    if (encontrada != null
                            && encontrada.accion() != null) {
                        encontrada.accion().run();
                    }
                }
            };

            addMouseListener(raton);
            addMouseMotionListener(raton);
        }

        private Zona buscarZona(Point punto) {

            double sx = getWidth() / (double) REF_ANCHO;
            double sy = getHeight() / (double) REF_ALTO;

            for (int i = zonas.size() - 1; i >= 0; i--) {

                Zona z = zonas.get(i);

                if (z.tipo() == Tipo.CERRAR && !avisoVisible) {
                    continue;
                }

                Rectangle r = new Rectangle(
                        (int) Math.round(z.x() * sx),
                        (int) Math.round(z.y() * sy),
                        (int) Math.round(z.w() * sx),
                        (int) Math.round(z.h() * sy)
                );

                if (r.contains(punto)) {
                    return z;
                }
            }

            return null;
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            if (fondo != null) {

                g2.drawImage(
                        fondo,
                        0, 0,
                        getWidth(), getHeight(),
                        null
                );

            } else {

                g2.setColor(FONDO);
                g2.fillRect(
                        0, 0,
                        getWidth(), getHeight()
                );

                g2.setColor(CREMA);
                g2.setFont(
                        new Font("Segoe UI", Font.BOLD, 24)
                );

                g2.drawString(
                        "No se encontró /nexusgym/SERVICIOS.jpg",
                        35, 50
                );
            }

            double sx = getWidth() / (double) REF_ANCHO;
            double sy = getHeight() / (double) REF_ALTO;

            if (!avisoVisible) {

                g2.setColor(FONDO);

                g2.fillRect(
                        0,
                        (int) Math.round(86 * sy),
                        getWidth(),
                        Math.max(
                                1,
                                (int) Math.round(54 * sy)
                        )
                );
            }

            if (zonaHover != null) {

                Zona z = zonaHover;

                int x = (int) Math.round(z.x() * sx);
                int y = (int) Math.round(z.y() * sy);
                int w = (int) Math.round(z.w() * sx);
                int h = (int) Math.round(z.h() * sy);

                if (z.tipo() == Tipo.MENU) {

                    g2.setColor(
                            new Color(255, 255, 255, 26)
                    );

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x, y, w, h, 12, 12
                            )
                    );

                    double ancho = w * 0.62;

                    g2.setColor(NARANJA);

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x + (w - ancho) / 2.0,
                                    y + h - 4,
                                    ancho,
                                    3,
                                    3, 3
                            )
                    );

                } else if (z.tipo() == Tipo.BOTON) {

                    g2.setColor(
                            new Color(232, 106, 36, 48)
                    );

                    g2.fill(
                            new RoundRectangle2D.Double(
                                    x, y, w, h, 12, 12
                            )
                    );

                    g2.setColor(NARANJA);
                    g2.setStroke(new BasicStroke(2f));

                    g2.draw(
                            new RoundRectangle2D.Double(
                                    x + 1,
                                    y + 1,
                                    w - 2,
                                    h - 2,
                                    12, 12
                            )
                    );
                }
            }

            g2.dispose();
        }
    }

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(
                () -> new ServiciosNexusGym().setVisible(true)
        );
    }
}