
package nexusgym;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Pantalla de clases de Nexus Gym dibujada sobre CLASES.jpg.
 * Mantiene el diseño original y reproduce el efecto hover
 * de la barra superior de PaginaPrincipal.
 */
public class ClasesNexusGym extends JFrame {

    private static final int REF_ANCHO = 1536;
    private static final int REF_ALTO = 924;

    private static final Color FONDO = new Color(13, 15, 20);
    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color NARANJA_HOVER = new Color(255, 145, 66);
    private static final Color CREMA = new Color(240, 232, 218);

    private enum Tipo {
        MENU, BOTON, CERRAR
    }

    private record Zona(
            String nombre,
            double x,
            double y,
            double w,
            double h,
            Tipo tipo,
            Runnable accion) {
    }

    private final List<Zona> zonas = new ArrayList<>();

    private BufferedImage imagen;
    private Zona zonaHover;
    private boolean avisoVisible = true;
    private Lienzo lienzo;

    public ClasesNexusGym() {

        setTitle("Nexus Gym | Clases");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagen();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1152, 693));

        setContentPane(lienzo);
        setMinimumSize(new Dimension(960, 577));

        pack();
        setLocationRelativeTo(null);

        configurarTeclado();
    }

    private void cargarImagen() {

        URL url = getClass().getResource("/nexusgym/CLASES.jpg");

        if (url == null) {
            url = getClass().getResource("/nexusgym/clases.jpg");
        }

        if (url != null) {
            try {
                imagen = ImageIO.read(url);
            } catch (IOException ignored) {
                imagen = null;
            }
        }
    }

    private void crearZonas() {

        // Barra superior
        zonas.add(new Zona("NEXUS GYM",
                38, 14, 253, 53, Tipo.MENU,
                () -> abrir(new PaginaPrincipal())));

        zonas.add(new Zona("SEDES",
                300, 12, 112, 54, Tipo.MENU,
                () -> abrir(new SedesNexusGym())));

        zonas.add(new Zona("SERVICIOS",
                426, 12, 137, 54, Tipo.MENU,
                () -> abrir(new ServiciosNexusGym())));

        zonas.add(new Zona("CLASES",
                594, 12, 110, 54, Tipo.MENU,
                null));

        zonas.add(new Zona("SUSCRIPCIONES / PLANES",
                728, 12, 302, 54, Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de suscripciones y planes estará disponible próximamente."
                )));

        zonas.add(new Zona("PAGOS",
                1065, 12, 105, 54, Tipo.MENU,
                () -> mostrarAviso(
                        "La sección de pagos estará disponible próximamente."
                )));

        zonas.add(new Zona("INICIAR SESIÓN",
                1287, 7, 221, 56, Tipo.BOTON,
                () -> abrir(new LoginNuevo())));

        // Aviso promocional
        zonas.add(new Zona("Más info",
                878, 81, 104, 39, Tipo.MENU,
                () -> mostrarAviso(
                        "Comienza tu viaje con 1 mes gratis. "
                        + "Consulta las condiciones en Nexus Gym."
                )));

        zonas.add(new Zona("Cerrar aviso",
                1474, 78, 52, 45, Tipo.CERRAR,
                () -> {
                    avisoVisible = false;
                    lienzo.repaint();
                }));

        // Botones de horarios: primera fila
        zonas.add(new Zona("SPINNING",
                39, 417, 207, 49, Tipo.BOTON,
                () -> mostrarHorario(
                        "SPINNING",
                        "Entrenamiento cardiovascular en bicicleta estática al ritmo de la música."
                )));

        zonas.add(new Zona("YOGA",
                412, 417, 202, 49, Tipo.BOTON,
                () -> mostrarHorario(
                        "YOGA",
                        "Sesiones de movilidad, equilibrio, respiración y flexibilidad."
                )));

        zonas.add(new Zona("CROSSFIT",
                796, 417, 201, 49, Tipo.BOTON,
                () -> mostrarHorario(
                        "CROSSFIT",
                        "Entrenamiento funcional de fuerza y resistencia en grupo."
                )));

        zonas.add(new Zona("ZUMBA",
                1199, 417, 205, 49, Tipo.BOTON,
                () -> mostrarHorario(
                        "ZUMBA",
                        "Clase grupal de baile y ejercicio cardiovascular."
                )));

        // Botones de horarios: segunda fila
        zonas.add(new Zona("PILATES",
                36, 779, 218, 50, Tipo.BOTON,
                () -> mostrarHorario(
                        "PILATES",
                        "Trabajo de control corporal, postura, fuerza del core y movilidad."
                )));

        zonas.add(new Zona("ENTRENAMIENTO FUNCIONAL",
                411, 779, 224, 50, Tipo.BOTON,
                () -> mostrarHorario(
                        "ENTRENAMIENTO FUNCIONAL",
                        "Circuitos para desarrollar fuerza, coordinación y resistencia."
                )));

        zonas.add(new Zona("BOXEO",
                800, 779, 229, 50, Tipo.BOTON,
                () -> mostrarHorario(
                        "BOXEO",
                        "Técnica, coordinación y acondicionamiento físico con ejercicios de boxeo."
                )));

        zonas.add(new Zona("STRETCHING",
                1187, 779, 229, 50, Tipo.BOTON,
                () -> mostrarHorario(
                        "STRETCHING",
                        "Sesiones enfocadas en flexibilidad, movilidad y recuperación."
                )));
    }

    private void configurarTeclado() {

        getRootPane().getInputMap(
                JComponent.WHEN_IN_FOCUSED_WINDOW
        ).put(
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                "volverInicio"
        );

        getRootPane().getActionMap().put(
                "volverInicio",
                new AbstractAction() {
                    @Override
                    public void actionPerformed(
                            java.awt.event.ActionEvent e) {
                        abrir(new PaginaPrincipal());
                    }
                }
        );
    }

    private void abrir(JFrame ventana) {

        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    private void mostrarAviso(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void mostrarHorario(
            String nombre,
            String descripcion) {

        JOptionPane.showMessageDialog(
                this,
                nombre + "\n\n"
                + descripcion
                + "\n\nConsulta los días y horas disponibles "
                + "en recepción o con tu sede.",
                "Horarios de " + nombre,
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private Zona zonaEn(Point p) {

        double sx = lienzo.getWidth() / (double) REF_ANCHO;
        double sy = lienzo.getHeight() / (double) REF_ALTO;

        double x = p.x / sx;
        double y = p.y / sy;

        for (int i = zonas.size() - 1; i >= 0; i--) {

            Zona z = zonas.get(i);

            if (z.nombre().equals("Cerrar aviso")
                    && !avisoVisible) {
                continue;
            }

            if (x >= z.x()
                    && x <= z.x() + z.w()
                    && y >= z.y()
                    && y <= z.y() + z.h()) {
                return z;
            }
        }

        return null;
    }

    private class Lienzo extends JPanel {

        Lienzo() {

            setBackground(FONDO);
            setFocusable(true);

            MouseAdapter raton = new MouseAdapter() {

                @Override
                public void mouseMoved(MouseEvent e) {

                    Zona nueva = zonaEn(e.getPoint());

                    if (nueva != zonaHover) {

                        zonaHover = nueva;

                        setCursor(Cursor.getPredefinedCursor(
                                nueva == null
                                        ? Cursor.DEFAULT_CURSOR
                                        : Cursor.HAND_CURSOR
                        ));

                        setToolTipText(
                                nueva == null ? null : nueva.nombre()
                        );

                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {

                    zonaHover = null;
                    setCursor(Cursor.getDefaultCursor());
                    setToolTipText(null);
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {

                    if (e.getButton() != MouseEvent.BUTTON1) {
                        return;
                    }

                    Zona z = zonaEn(e.getPoint());

                    if (z != null && z.accion() != null) {
                        z.accion().run();
                    }
                }
            };

            addMouseMotionListener(raton);
            addMouseListener(raton);
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            double sx = getWidth() / (double) REF_ANCHO;
            double sy = getHeight() / (double) REF_ALTO;

            // Imagen original sin modificar
            if (imagen != null) {

                g2.drawImage(
                        imagen,
                        0, 0,
                        getWidth(), getHeight(),
                        null
                );

            } else {

                g2.setColor(FONDO);
                g2.fillRect(0, 0, getWidth(), getHeight());

                g2.setColor(CREMA);
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 16));

                g2.drawString(
                        "No se encontró /nexusgym/CLASES.jpg",
                        30, 40
                );
            }

            // Ocultar la franja promocional al cerrar el aviso
            if (!avisoVisible) {

                g2.setColor(FONDO);

                g2.fillRect(
                        0,
                        (int) Math.round(76 * sy),
                        getWidth(),
                        Math.max(1, (int) Math.round(49 * sy))
                );
            }

            // Efectos visuales al pasar el ratón
            dibujarHover(g2, sx, sy);

            g2.dispose();
        }

        private void dibujarHover(
                Graphics2D g2,
                double sx,
                double sy) {

            if (zonaHover == null) {
                return;
            }

            Zona z = zonaHover;

            int x = (int) Math.round(z.x() * sx);
            int y = (int) Math.round(z.y() * sy);
            int w = (int) Math.round(z.w() * sx);
            int h = (int) Math.round(z.h() * sy);

            switch (z.tipo()) {

                case MENU -> {

                    // Recuadro suave, igual que en PaginaPrincipal
                    g2.setColor(new Color(255, 255, 255, 26));

                    g2.fillRoundRect(
                            x, y, w, h,
                            12, 12
                    );

                    // Línea naranja centrada debajo del elemento
                    double ancho = w * 0.62;

                    int lineaX = (int) Math.round(
                            x + (w - ancho) / 2.0
                    );

                    int lineaAncho = (int) Math.round(ancho);

                    g2.setColor(NARANJA);

                    g2.fillRoundRect(
                            lineaX,
                            y + h - 4,
                            lineaAncho,
                            3,
                            3, 3
                    );
                }

                case BOTON -> {

                    g2.setColor(
                            new Color(232, 106, 36, 48)
                    );

                    g2.fillRoundRect(
                            x, y, w, h,
                            12, 12
                    );

                    g2.setColor(NARANJA);
                    g2.setStroke(new BasicStroke(2f));

                    g2.drawRoundRect(
                            x + 1,
                            y + 1,
                            Math.max(0, w - 2),
                            Math.max(0, h - 2),
                            12, 12
                    );
                }

                case CERRAR -> {

                    g2.setColor(
                            new Color(255, 255, 255, 45)
                    );

                    g2.fillRoundRect(
                            x, y, w, h,
                            12, 12
                    );
                }
            }
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () -> new ClasesNexusGym().setVisible(true)
        );
    }
}
