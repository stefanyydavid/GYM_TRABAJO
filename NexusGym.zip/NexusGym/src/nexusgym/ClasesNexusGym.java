package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClasesNexusGym extends JFrame {

    private JPanel panelContenido;

    public ClasesNexusGym() {

        setTitle("Nexus Gym - Clases disponibles");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1160, 661);
        setResizable(false);
        setLocationRelativeTo(null);

        construirInterfaz();
        cargarClases();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(18, 18, 18));

        // =========================
        // BARRA SUPERIOR
        // =========================

        JPanel barraSuperior = new JPanel(new BorderLayout());
        barraSuperior.setBackground(new Color(25, 25, 25));
        barraSuperior.setBorder(
            new EmptyBorder(15, 25, 15, 25)
        );
        barraSuperior.setPreferredSize(
            new Dimension(1160, 75)
        );

        JLabel logo = new JLabel("NEXUS GYM");
        logo.setForeground(
            new Color(100, 220, 130)
        );
        logo.setFont(
            new Font("Segoe UI", Font.BOLD, 25)
        );

        JLabel titulo = new JLabel("Clases disponibles");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(
            new Font("Segoe UI", Font.BOLD, 22)
        );

        JButton volver = new JButton("VOLVER");
        volver.setFocusPainted(false);
        volver.setForeground(Color.WHITE);
        volver.setBackground(
            new Color(45, 45, 45)
        );
        volver.setBorderPainted(false);
        volver.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        volver.addActionListener(e -> {

            new PaginaPrincipal().setVisible(true);
            dispose();
        });

        barraSuperior.add(
            logo,
            BorderLayout.WEST
        );

        barraSuperior.add(
            titulo,
            BorderLayout.CENTER
        );

        barraSuperior.add(
            volver,
            BorderLayout.EAST
        );

        // =========================
        // CONTENIDO
        // =========================

        panelContenido = new JPanel();

        panelContenido.setLayout(
            new GridLayout(0, 2, 20, 20)
        );

        panelContenido.setBackground(
            new Color(18, 18, 18)
        );

        panelContenido.setBorder(
            new EmptyBorder(30, 30, 30, 30)
        );

        JScrollPane scroll = new JScrollPane(
            panelContenido
        );

        scroll.setBorder(null);

        scroll.getVerticalScrollBar()
            .setUnitIncrement(16);

        scroll.getViewport()
            .setBackground(
                new Color(18, 18, 18)
            );

        principal.add(
            barraSuperior,
            BorderLayout.NORTH
        );

        principal.add(
            scroll,
            BorderLayout.CENTER
        );

        setContentPane(principal);
    }

    private void cargarClases() {

        panelContenido.removeAll();

        String sql = """
            SELECT
                c.id_clase,
                c.nombre AS nombre_clase,
                c.descripcion,
                c.capacidad,
                hc.id_horario,
                hc.dia_semana,
                hc.hora_inicio,
                hc.hora_fin,
                s.nombre AS nombre_sede
            FROM clases c
            LEFT JOIN horarios_clases hc
                ON c.id_clase = hc.id_clase
                AND hc.activo = 1
            LEFT JOIN sedes s
                ON hc.id_sede = s.id_sede
            WHERE c.activo = 1
            ORDER BY c.id_clase, hc.dia_semana, hc.hora_inicio
            """;

        // ==========================================
        // CONEXIÓN CORREGIDA
        // ==========================================

        Conexion conexionBD = Conexion.getInstancia();
        Connection conexion = conexionBD.conectar();

        // Verificar conexión
        if (conexion == null) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudo establecer conexión con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try (
            PreparedStatement pst =
                conexion.prepareStatement(sql);

            ResultSet rs =
                pst.executeQuery()
        ) {

            int ultimaClase = -1;

            JPanel tarjetaActual = null;
            JPanel horariosPanel = null;

            while (rs.next()) {

                int idClase =
                    rs.getInt("id_clase");

                // =========================
                // NUEVA CLASE
                // =========================

                if (idClase != ultimaClase) {

                    ultimaClase = idClase;

                    String nombre =
                        rs.getString("nombre_clase");

                    String descripcion =
                        rs.getString("descripcion");

                    int capacidad =
                        rs.getInt("capacidad");

                    tarjetaActual =
                        crearTarjetaClase(
                            idClase,
                            nombre,
                            descripcion,
                            capacidad
                        );

                    horariosPanel =
                        new JPanel();

                    horariosPanel.setLayout(
                        new BoxLayout(
                            horariosPanel,
                            BoxLayout.Y_AXIS
                        )
                    );

                    horariosPanel.setBackground(
                        new Color(30, 30, 30)
                    );

                    tarjetaActual.add(
                        Box.createVerticalStrut(15)
                    );

                    tarjetaActual.add(
                        horariosPanel
                    );

                    panelContenido.add(
                        tarjetaActual
                    );
                }

                // =========================
                // HORARIO
                // =========================

                Object objetoHorario =
                    rs.getObject("id_horario");

                if (objetoHorario != null
                        && horariosPanel != null) {

                    String dia =
                        rs.getString("dia_semana");

                    String horaInicio =
                        rs.getString("hora_inicio");

                    String horaFin =
                        rs.getString("hora_fin");

                    String sede =
                        rs.getString("nombre_sede");

                    JLabel horario =
                        new JLabel(
                            "<html>"
                            + "<b>"
                            + textoSeguro(dia)
                            + "</b>"
                            + " | "
                            + textoSeguro(horaInicio)
                            + " - "
                            + textoSeguro(horaFin)
                            + "<br>"
                            + "Sede: "
                            + textoSeguro(sede)
                            + "</html>"
                        );

                    horario.setForeground(
                        Color.WHITE
                    );

                    horario.setFont(
                        new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            13
                        )
                    );

                    horario.setBorder(
                        new EmptyBorder(
                            4, 0, 4, 0
                        )
                    );

                    horariosPanel.add(
                        horario
                    );
                }
            }

            // =========================
            // SIN CLASES
            // =========================

            if (panelContenido.getComponentCount()
                    == 0) {

                JLabel mensaje =
                    new JLabel(
                        "No hay clases activas registradas."
                    );

                mensaje.setForeground(
                    Color.WHITE
                );

                mensaje.setFont(
                    new Font(
                        "Segoe UI",
                        Font.BOLD,
                        18
                    )
                );

                panelContenido.add(
                    mensaje
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudieron cargar las clases.\n\n"
                + "Error: "
                + ex.getMessage(),
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
        }

        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private JPanel crearTarjetaClase(
            int idClase,
            String nombre,
            String descripcion,
            int capacidad) {

        JPanel tarjeta = new JPanel();

        tarjeta.setLayout(
            new BoxLayout(
                tarjeta,
                BoxLayout.Y_AXIS
            )
        );

        tarjeta.setBackground(
            new Color(30, 30, 30)
        );

        tarjeta.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(55, 55, 55)
                ),
                new EmptyBorder(
                    20, 20, 20, 20
                )
            )
        );

        JLabel lblNombre =
            new JLabel(
                textoSeguro(nombre)
            );

        lblNombre.setForeground(
            new Color(100, 220, 130)
        );

        lblNombre.setFont(
            new Font(
                "Segoe UI",
                Font.BOLD,
                21
            )
        );

        JLabel lblId =
            new JLabel(
                "Clase #" + idClase
            );

        lblId.setForeground(
            new Color(150, 150, 150)
        );

        lblId.setFont(
            new Font(
                "Segoe UI",
                Font.PLAIN,
                12
            )
        );

        JLabel lblDescripcion =
            new JLabel(
                "<html>"
                + textoSeguro(descripcion)
                + "</html>"
            );

        lblDescripcion.setForeground(
            Color.WHITE
        );

        lblDescripcion.setFont(
            new Font(
                "Segoe UI",
                Font.PLAIN,
                14
            )
        );

        JLabel lblCapacidad =
            new JLabel(
                "Capacidad: "
                + capacidad
                + " personas"
            );

        lblCapacidad.setForeground(
            new Color(190, 190, 190)
        );

        lblCapacidad.setFont(
            new Font(
                "Segoe UI",
                Font.PLAIN,
                13
            )
        );

        tarjeta.add(lblNombre);

        tarjeta.add(
            Box.createVerticalStrut(5)
        );

        tarjeta.add(lblId);

        tarjeta.add(
            Box.createVerticalStrut(15)
        );

        tarjeta.add(lblDescripcion);

        tarjeta.add(
            Box.createVerticalStrut(12)
        );

        tarjeta.add(lblCapacidad);

        return tarjeta;
    }

    private String textoSeguro(String texto) {

        return texto == null
                || texto.isBlank()
                ? "No registrado"
                : texto;
    }

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {

            new ClasesNexusGym()
                .setVisible(true);
        });
    }
}