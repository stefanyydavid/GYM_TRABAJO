package nexusgym;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Catálogo comercial de planes Nexus Gym.
 * Vista pública para que los visitantes conozcan, comparen y seleccionen
 * los planes disponibles. La información comercial se consulta desde MySQL.
 */
public class PanelPlanes extends JPanel {

    // Paleta oficial de la interfaz Nexus Gym.
    private static final Color FONDO = new Color(8, 12, 17);
    private static final Color FONDO_2 = new Color(13, 19, 25);
    private static final Color PANEL = new Color(17, 23, 29);
    private static final Color NARANJA = new Color(235, 91, 25);
    private static final Color NARANJA_CLARO = new Color(255, 116, 43);
    private static final Color CREMA = new Color(239, 229, 211);
    private static final Color TEXTO = new Color(244, 242, 237);
    private static final Color GRIS = new Color(164, 169, 174);

    private static final Locale LOCALE_CO = Locale.forLanguageTag("es-CO");

    private final List<Plan> planes = new ArrayList<>();
    private final JPanel rejilla = new JPanel(new GridLayout(0, 3, 18, 18));
    private final JPanel contenedorRejilla = new JPanel(new BorderLayout());
    private final JTextField buscador = new JTextField();

    private final JComboBox<String> filtro = new JComboBox<>(new String[]{
            "Todos los planes",
            "Hasta 30 días",
            "Más de 30 días",
            "Con entrenador"
    });

    private final JLabel lblResultados = new JLabel("CARGANDO PLANES...");
    private final JLabel lblEstado = new JLabel(" ");
    private final JPanel barraPromo = new JPanel(new BorderLayout());

    private boolean promoVisible = true;

    private static Font fuente(int estilo, int tam) {
        return new Font("Segoe UI", estilo, tam);
    }

    private static Font tracking(Font f, float valor) {
        java.util.Map<java.awt.font.TextAttribute, Object> atributos =
                new java.util.HashMap<>();

        atributos.put(java.awt.font.TextAttribute.TRACKING, valor);

        return f.deriveFont(atributos);
    }

    private static void calidad(Graphics2D g) {
        g.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        g.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON
        );

        g.setRenderingHint(
                RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY
        );
    }

    private static JLabel etiqueta(
            String texto,
            int tam,
            int estilo,
            Color color
    ) {
        JLabel l = new JLabel(texto);
        l.setFont(fuente(estilo, tam));
        l.setForeground(color);
        return l;
    }

    private static String moneda(String valor) {
        try {
            BigDecimal numero = new BigDecimal(valor.trim());

            return "$" +
                    NumberFormat.getIntegerInstance(LOCALE_CO)
                            .format(numero.longValue())
                    + " COP";

        } catch (Exception ex) {
            return valor == null ? "$0 COP" : valor + " COP";
        }
    }

    private static int dias(String valor) {
        try {
            return Integer.parseInt(valor.trim());
        } catch (Exception ex) {
            return 0;
        }
    }

    private static boolean verdadero(String valor) {
        if (valor == null) {
            return false;
        }

        String v = valor.trim();

        return v.equals("1")
                || v.equalsIgnoreCase("true")
                || v.equalsIgnoreCase("si")
                || v.equalsIgnoreCase("sí")
                || v.equalsIgnoreCase("activo");
    }

    private static class Plan {

        int id;
        String nombre;
        String descripcion;
        String duracion;
        String precio;
        String limite;
        boolean entrenador;

        int dias() {
            return PanelPlanes.dias(duracion);
        }

        String precioBonito() {
            return moneda(precio);
        }
    }

    // ---------------------------------------------------------------------
    // Botones Nexus: naranja sólido y contorno naranja.
    // ---------------------------------------------------------------------

    private static class BotonNexus extends JButton {

        private final boolean principal;
        private boolean hover;

        BotonNexus(String texto, boolean principal) {
            super(texto);

            this.principal = principal;

            setFont(tracking(fuente(Font.BOLD, 12), .045f));
            setForeground(principal ? Color.WHITE : CREMA);

            setBorderPainted(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);

            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setMargin(new Insets(10, 18, 10, 18));

            addMouseListener(new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();

            return new Dimension(
                    Math.max(132, d.width + 22),
                    43
            );
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            calidad(g2);

            int w = getWidth();
            int h = getHeight();

            RoundRectangle2D forma =
                    new RoundRectangle2D.Double(
                            1, 1,
                            w - 2, h - 2,
                            12, 12
                    );

            if (principal) {

                g2.setPaint(
                        new GradientPaint(
                                0, 0,
                                hover ? NARANJA_CLARO : NARANJA,
                                0, h,
                                new Color(190, 63, 13)
                        )
                );

                g2.fill(forma);

                g2.setColor(new Color(255, 255, 255, 48));
                g2.draw(forma);

            } else {

                g2.setColor(
                        hover
                                ? new Color(235, 91, 25, 34)
                                : new Color(255, 255, 255, 5)
                );

                g2.fill(forma);

                g2.setColor(
                        hover
                                ? NARANJA_CLARO
                                : new Color(235, 91, 25, 180)
                );

                g2.setStroke(new BasicStroke(1.3f));
                g2.draw(forma);
            }

            g2.dispose();

            super.paintComponent(g);
        }
    }

    // ---------------------------------------------------------------------
    // Tarjetas de catálogo.
    // ---------------------------------------------------------------------

    private class TarjetaPlan extends JPanel {

        private final Plan plan;
        private boolean hover;
        private final boolean recomendado;

        TarjetaPlan(Plan plan, boolean recomendado) {

            this.plan = plan;
            this.recomendado = recomendado;

            setOpaque(false);
            setLayout(new BorderLayout());

            setBorder(
                    new EmptyBorder(22, 22, 20, 22)
            );

            setPreferredSize(new Dimension(320, 350));

            setCursor(
                    Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
            );

            construirContenido();

            addMouseListener(new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {

                    if (SwingUtilities.isLeftMouseButton(e)) {
                        mostrarDetalle(TarjetaPlan.this.plan);
                    }
                }
            });
        }

        private void construirContenido() {

            JPanel arriba = new JPanel();

            arriba.setOpaque(false);

            arriba.setLayout(
                    new BoxLayout(arriba, BoxLayout.Y_AXIS)
            );

            JPanel fila = new JPanel(new BorderLayout());

            fila.setOpaque(false);

            JLabel nombre = etiqueta(
                    plan.nombre.toUpperCase(Locale.ROOT),
                    15,
                    Font.BOLD,
                    CREMA
            );

            nombre.setFont(
                    tracking(nombre.getFont(), .035f)
            );

            fila.add(nombre, BorderLayout.WEST);

            JLabel duracion = new JLabel(
                    plan.duracion + " DÍAS"
            );

            duracion.setFont(fuente(Font.BOLD, 10));
            duracion.setForeground(CREMA);

            duracion.setBorder(
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(
                                    new Color(239, 229, 211, 110),
                                    1,
                                    true
                            ),
                            new EmptyBorder(5, 9, 5, 9)
                    )
            );

            fila.add(duracion, BorderLayout.EAST);

            arriba.add(fila);
            arriba.add(Box.createVerticalStrut(17));

            JLabel precio = etiqueta(
                    plan.precioBonito(),
                    27,
                    Font.BOLD,
                    NARANJA_CLARO
            );

            arriba.add(precio);
            arriba.add(Box.createVerticalStrut(7));

            JLabel periodo = etiqueta(
                    "POR " + plan.duracion + " DÍAS DE ENTRENAMIENTO",
                    9,
                    Font.BOLD,
                    GRIS
            );

            periodo.setFont(
                    tracking(periodo.getFont(), .10f)
            );

            arriba.add(periodo);
            arriba.add(Box.createVerticalStrut(20));

            JSeparator sep = new JSeparator();
            sep.setForeground(new Color(255, 255, 255, 35));

            arriba.add(sep);
            arriba.add(Box.createVerticalStrut(16));

            JPanel beneficios = new JPanel();

            beneficios.setOpaque(false);

            beneficios.setLayout(
                    new BoxLayout(beneficios, BoxLayout.Y_AXIS)
            );

            String descripcion = plan.descripcion == null
                    ? "Acceso a las instalaciones Nexus Gym"
                    : plan.descripcion;

            agregarBeneficio(
                    beneficios,
                    descripcion,
                    true
            );

            if (plan.entrenador) {

                agregarBeneficio(
                        beneficios,
                        "Entrenador personal incluido",
                        true
                );

            } else {

                agregarBeneficio(
                        beneficios,
                        "Entrenamiento a tu ritmo",
                        false
                );
            }

            String limite = plan.limite == null
                    ? ""
                    : plan.limite.trim();

            if (!limite.isEmpty()
                    && !limite.equalsIgnoreCase("NO APLICA")
                    && !limite.equals("0")) {

                agregarBeneficio(
                        beneficios,
                        "Hasta " + limite + " ingresos",
                        true
                );

            } else {

                agregarBeneficio(
                        beneficios,
                        "Ingresos sin límite indicado",
                        true
                );
            }

            arriba.add(beneficios);

            add(arriba, BorderLayout.CENTER);

            JPanel abajo = new JPanel();

            abajo.setOpaque(false);

            abajo.setLayout(
                    new BoxLayout(abajo, BoxLayout.Y_AXIS)
            );

            JSeparator linea = new JSeparator();

            linea.setForeground(
                    new Color(255, 255, 255, 35)
            );

            abajo.add(linea);
            abajo.add(Box.createVerticalStrut(15));

            BotonNexus elegir = new BotonNexus(
                    "ELEGIR ESTE PLAN   →",
                    true
            );

            elegir.setAlignmentX(Component.CENTER_ALIGNMENT);

            elegir.addActionListener(e ->
                    mostrarDetalle(plan)
            );

            abajo.add(elegir);

            add(abajo, BorderLayout.SOUTH);
        }

        private void agregarBeneficio(
                JPanel panel,
                String texto,
                boolean incluido
        ) {

            JPanel fila = new JPanel(
                    new BorderLayout(10, 0)
            );

            fila.setOpaque(false);

            fila.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel icono = etiqueta(
                    incluido ? "✓" : "•",
                    15,
                    Font.BOLD,
                    incluido ? NARANJA_CLARO : GRIS
            );

            JLabel contenido = etiqueta(
                    texto,
                    12,
                    Font.PLAIN,
                    new Color(220, 218, 211)
            );

            fila.add(icono, BorderLayout.WEST);
            fila.add(contenido, BorderLayout.CENTER);

            panel.add(fila);
            panel.add(Box.createVerticalStrut(12));
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            calidad(g2);

            int w = getWidth();
            int h = getHeight();

            RoundRectangle2D r =
                    new RoundRectangle2D.Double(
                            1, 1,
                            w - 3, h - 3,
                            18, 18
                    );

            g2.setPaint(
                    hover
                            ? new GradientPaint(
                                    0, 0,
                                    new Color(31, 36, 42),
                                    0, h,
                                    new Color(17, 22, 28)
                            )
                            : new GradientPaint(
                                    0, 0,
                                    new Color(23, 29, 35),
                                    0, h,
                                    new Color(13, 18, 23)
                            )
            );

            g2.fill(r);

            g2.setColor(
                    recomendado || hover
                            ? NARANJA
                            : new Color(255, 255, 255, 42)
            );

            g2.setStroke(
                    new BasicStroke(recomendado ? 1.8f : 1f)
            );

            g2.draw(r);

            g2.setPaint(
                    new GradientPaint(
                            0, 0,
                            NARANJA_CLARO,
                            w, 0,
                            new Color(190, 61, 15)
                    )
            );

            g2.fillRoundRect(
                    1, 1,
                    w - 2, 5,
                    8, 8
            );

            if (recomendado) {

                g2.setFont(
                        tracking(fuente(Font.BOLD, 9), .12f)
                );

                String tag = "MÁS ELEGIDO";

                int tw = g2.getFontMetrics()
                        .stringWidth(tag) + 20;

                g2.setColor(
                        new Color(235, 91, 25, 34)
                );

                g2.fillRoundRect(
                        w - tw - 18,
                        h - 9,
                        tw,
                        5,
                        5,
                        5
                );
            }

            g2.dispose();

            super.paintComponent(g);
        }
    }

    // ---------------------------------------------------------------------
    // Construcción de la página.
    // ---------------------------------------------------------------------

    public PanelPlanes() {

        setLayout(new BorderLayout());
        setBackground(FONDO);

        construirPagina();
        cargarPlanes();
    }

    private void construirPagina() {

        JPanel pagina = new JPanel(
                new BorderLayout()
        );

        pagina.setBackground(FONDO);

        add(pagina, BorderLayout.CENTER);

        pagina.add(
                construirNavegacion(),
                BorderLayout.NORTH
        );

        JPanel centro = new JPanel(
                new BorderLayout()
        );

        centro.setBackground(FONDO);

        pagina.add(
                centro,
                BorderLayout.CENTER
        );

        JPanel contenido = new JPanel();

        contenido.setBackground(FONDO);

        contenido.setLayout(
                new BoxLayout(contenido, BoxLayout.Y_AXIS)
        );

        contenido.setBorder(
                new EmptyBorder(30, 34, 34, 34)
        );

        contenido.add(construirHero());
        contenido.add(Box.createVerticalStrut(27));
        contenido.add(construirHerramientas());
        contenido.add(Box.createVerticalStrut(15));

        lblResultados.setFont(
                tracking(fuente(Font.BOLD, 10), .12f)
        );

        lblResultados.setForeground(GRIS);
        lblResultados.setAlignmentX(Component.LEFT_ALIGNMENT);

        contenido.add(lblResultados);
        contenido.add(Box.createVerticalStrut(13));

        rejilla.setOpaque(false);
        rejilla.setBorder(
                new EmptyBorder(2, 2, 14, 2)
        );

        contenedorRejilla.setOpaque(false);

        contenedorRejilla.add(
                rejilla,
                BorderLayout.NORTH
        );

        rejilla.setAlignmentX(Component.LEFT_ALIGNMENT);

        contenido.add(rejilla);
        contenido.add(Box.createVerticalStrut(25));
        contenido.add(construirPie());

        JScrollPane paginaScroll = new JScrollPane(
                contenido,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
        );

        paginaScroll.setBorder(null);
        paginaScroll.setOpaque(false);

        paginaScroll.getViewport().setOpaque(false);

        paginaScroll.getViewport().addComponentListener(
                new java.awt.event.ComponentAdapter() {

                    @Override
                    public void componentResized(
                            java.awt.event.ComponentEvent e
                    ) {

                        ajustarColumnas(
                                paginaScroll.getViewport().getWidth()
                        );
                    }
                }
        );

        paginaScroll.getVerticalScrollBar()
                .setUnitIncrement(18);

        paginaScroll.getVerticalScrollBar()
                .setPreferredSize(new Dimension(8, 0));

        paginaScroll.getVerticalScrollBar().setUI(
                new javax.swing.plaf.basic.BasicScrollBarUI() {

                    @Override
                    protected JButton createDecreaseButton(int o) {
                        return botonVacio();
                    }

                    @Override
                    protected JButton createIncreaseButton(int o) {
                        return botonVacio();
                    }

                    private JButton botonVacio() {

                        JButton b = new JButton();

                        b.setPreferredSize(
                                new Dimension(0, 0)
                        );

                        return b;
                    }

                    @Override
                    protected void configureScrollBarColors() {
                        thumbColor = NARANJA;
                        trackColor = FONDO;
                    }
                }
        );

        centro.add(
                paginaScroll,
                BorderLayout.CENTER
        );
    }

    private JPanel construirNavegacion() {

        JPanel envoltura = new JPanel();

        envoltura.setLayout(
                new BoxLayout(envoltura, BoxLayout.Y_AXIS)
        );

        envoltura.setBackground(FONDO);

        JPanel nav = new JPanel(
                new BorderLayout()
        );

        nav.setBackground(
                new Color(5, 9, 14)
        );

        nav.setBorder(
                new EmptyBorder(13, 36, 13, 30)
        );

        nav.setPreferredSize(
                new Dimension(1200, 76)
        );

        nav.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 76)
        );

        JLabel marca = etiqueta(
                "NEXUS GYM",
                25,
                Font.BOLD,
                TEXTO
        );

        marca.setFont(
                tracking(marca.getFont(), -.015f)
        );

        marca.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        marca.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                abrirVentana(new PaginaPrincipal());
            }
        });

        nav.add(marca, BorderLayout.WEST);

        JPanel enlaces = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 21, 8)
        );

        enlaces.setOpaque(false);

        enlaces.add(
                enlace(
                        "SEDES",
                        () -> abrirVentana(new SedesNexusGym()),
                        false
                )
        );

        enlaces.add(
                enlace(
                        "SERVICIOS",
                        () -> abrirVentana(new ServiciosNexusGym()),
                        false
                )
        );

        enlaces.add(
                enlace(
                        "CLASES",
                        () -> abrirVentana(new ClasesNexusGym()),
                        false
                )
        );

        enlaces.add(
                enlace(
                        "SUSCRIPCIONES / PLANES",
                        null,
                        true
                )
        );

        enlaces.add(
                enlace(
                        "PAGOS",
                        () -> mensaje(
                                "PAGOS",
                                "La consulta de pagos estará disponible desde tu cuenta Nexus Gym."
                        ),
                        false
                )
        );

        nav.add(
                enlaces,
                BorderLayout.CENTER
        );

        BotonNexus iniciar = new BotonNexus(
                "INICIAR SESIÓN",
                false
        );

        iniciar.addActionListener(e -> abrirLogin());

        nav.add(
                iniciar,
                BorderLayout.EAST
        );

        envoltura.add(nav);

        barraPromo.setBackground(CREMA);

        barraPromo.setBorder(
                new EmptyBorder(9, 18, 9, 18)
        );

        JLabel promo = new JLabel(
                "Comienza tu viaje con 1 mes GRATIS   ·   Más información en Nexus Gym"
        );

        promo.setFont(
                fuente(Font.PLAIN, 15)
        );

        promo.setForeground(
                new Color(24, 27, 30)
        );

        promo.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        barraPromo.add(
                promo,
                BorderLayout.CENTER
        );

        JButton cerrar = new JButton("×");

        cerrar.setFont(
                fuente(Font.PLAIN, 22)
        );

        cerrar.setForeground(
                new Color(35, 35, 35)
        );

        cerrar.setBorderPainted(false);
        cerrar.setContentAreaFilled(false);
        cerrar.setFocusPainted(false);

        cerrar.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        cerrar.addActionListener(e -> {
            promoVisible = false;
            barraPromo.setVisible(false);
        });

        barraPromo.add(
                cerrar,
                BorderLayout.EAST
        );

        barraPromo.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 43)
        );

        envoltura.add(barraPromo);

        return envoltura;
    }

    private JButton enlace(
            String texto,
            Runnable accion,
            boolean activo
    ) {

        JButton b = new JButton(texto);

        b.setFont(
                tracking(
                        fuente(
                                activo ? Font.BOLD : Font.PLAIN,
                                13
                        ),
                        .015f
                )
        );

        b.setForeground(
                activo ? CREMA : new Color(235, 235, 235)
        );

        b.setBorder(
                BorderFactory.createEmptyBorder(
                        7, 1, 7, 1
                )
        );

        b.setContentAreaFilled(false);
        b.setFocusPainted(false);

        b.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        if (activo) {

            b.setBorder(
                    BorderFactory.createMatteBorder(
                            0, 0, 2, 0,
                            NARANJA
                    )
            );
        }

        if (accion != null) {
            b.addActionListener(e -> accion.run());
        }

        return b;
    }

    private JPanel construirHero() {

        JPanel hero = new JPanel(
                new BorderLayout(10, 12)
        );

        hero.setOpaque(false);

        hero.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        hero.setBorder(
                new EmptyBorder(13, 0, 5, 0)
        );

        JPanel texto = new JPanel();

        texto.setOpaque(false);

        texto.setLayout(
                new BoxLayout(texto, BoxLayout.Y_AXIS)
        );

        JLabel eyebrow = etiqueta(
                "NEXUS GYM  /  MEMBRESÍAS",
                11,
                Font.BOLD,
                NARANJA_CLARO
        );

        eyebrow.setFont(
                tracking(eyebrow.getFont(), .19f)
        );

        texto.add(eyebrow);
        texto.add(Box.createVerticalStrut(12));

        JLabel titulo = etiqueta(
                "ELIGE TU PLAN.",
                38,
                Font.BOLD,
                TEXTO
        );

        titulo.setFont(
                tracking(titulo.getFont(), -.025f)
        );

        texto.add(titulo);
        texto.add(Box.createVerticalStrut(8));

        JLabel subtitulo = etiqueta(
                "Encuentra la membresía ideal para alcanzar tus objetivos.",
                15,
                Font.PLAIN,
                GRIS
        );

        texto.add(subtitulo);

        hero.add(
                texto,
                BorderLayout.WEST
        );

        JPanel sello = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 8, 8)
        );

        sello.setOpaque(false);

        sello.add(punto("PRECIOS EN COP"));
        sello.add(punto("PLANES ACTIVOS"));

        hero.add(
                sello,
                BorderLayout.SOUTH
        );

        hero.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 130)
        );

        return hero;
    }

    private JLabel punto(String texto) {

        JLabel l = new JLabel("●  " + texto);

        l.setFont(
                tracking(fuente(Font.BOLD, 9), .08f)
        );

        l.setForeground(GRIS);

        l.setBorder(
                new EmptyBorder(7, 10, 7, 10)
        );

        return l;
    }

    private JPanel construirHerramientas() {

        JPanel panel = new JPanel(
                new BorderLayout(12, 0)
        );

        panel.setOpaque(false);

        panel.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        JPanel busqueda = new JPanel(
                new BorderLayout(9, 0)
        );

        busqueda.setBackground(PANEL);

        busqueda.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(255, 255, 255, 38)
                        ),
                        new EmptyBorder(0, 13, 0, 13)
                )
        );

        JLabel lupa = etiqueta(
                "⌕",
                23,
                Font.PLAIN,
                GRIS
        );

        busqueda.add(
                lupa,
                BorderLayout.WEST
        );

        buscador.setFont(
                fuente(Font.PLAIN, 13)
        );

        buscador.setForeground(TEXTO);
        buscador.setCaretColor(NARANJA_CLARO);
        buscador.setBackground(PANEL);

        buscador.setBorder(
                BorderFactory.createEmptyBorder(
                        11, 2, 11, 2
                )
        );

        buscador.setToolTipText(
                "Busca un plan por nombre o descripción"
        );

        buscador.putClientProperty(
                "JTextField.placeholderText",
                "Buscar un plan..."
        );

        busqueda.add(
                buscador,
                BorderLayout.CENTER
        );

        busqueda.setPreferredSize(
                new Dimension(350, 45)
        );

        panel.add(
                busqueda,
                BorderLayout.CENTER
        );

        filtro.setFont(
                fuente(Font.PLAIN, 12)
        );

        filtro.setForeground(TEXTO);
        filtro.setBackground(PANEL);

        filtro.setPreferredSize(
                new Dimension(190, 45)
        );

        filtro.setFocusable(false);

        panel.add(
                filtro,
                BorderLayout.EAST
        );

        DocumentListener listener = new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent e) {
                aplicarFiltros();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                aplicarFiltros();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                aplicarFiltros();
            }
        };

        buscador.getDocument().addDocumentListener(listener);

        filtro.addActionListener(e -> aplicarFiltros());

        return panel;
    }

    private JPanel construirPie() {

        JPanel pie = new JPanel(
                new BorderLayout()
        );

        pie.setOpaque(false);

        JLabel marca = etiqueta(
                "NEXUS GYM",
                13,
                Font.BOLD,
                CREMA
        );

        marca.setFont(
                tracking(marca.getFont(), .08f)
        );

        JLabel nota = etiqueta(
                "ENTRENA. PROGRESA. SUPERA TUS LÍMITES.",
                9,
                Font.BOLD,
                GRIS
        );

        nota.setFont(
                tracking(nota.getFont(), .12f)
        );

        pie.add(
                marca,
                BorderLayout.WEST
        );

        pie.add(
                nota,
                BorderLayout.EAST
        );

        pie.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(
                                1, 0, 0, 0,
                                new Color(255, 255, 255, 35)
                        ),
                        new EmptyBorder(18, 2, 4, 2)
                )
        );

        pie.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 55)
        );

        return pie;
    }

    // ---------------------------------------------------------------------
    // Datos y filtros.
    // ---------------------------------------------------------------------

    private void cargarPlanes() {

        planes.clear();

        Connection cx =
                Conexion.getInstancia().conectar();

        if (cx == null) {

            lblEstado.setText(
                    "No fue posible conectar con la base de datos."
            );

            mostrarEstadoVacio(
                    "No pudimos conectar con Nexus Gym",
                    "Verifica la conexión con MySQL e inténtalo de nuevo."
            );

            return;
        }

        String sql =
                "SELECT id_plan, nombre, descripcion, duracion_dias, precio, "
                + "limite_ingresos, incluye_entrenador "
                + "FROM planes WHERE activo = 1 "
                + "ORDER BY CAST(duracion_dias AS UNSIGNED), "
                + "CAST(precio AS DECIMAL(12,2))";

        try (
                PreparedStatement ps = cx.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Plan p = new Plan();

                p.id = rs.getInt("id_plan");
                p.nombre = rs.getString("nombre");
                p.descripcion = rs.getString("descripcion");
                p.duracion = rs.getString("duracion_dias");
                p.precio = rs.getString("precio");
                p.limite = rs.getString("limite_ingresos");

                p.entrenador = verdadero(
                        rs.getString("incluye_entrenador")
                );

                planes.add(p);
            }

            lblEstado.setText(" ");

            aplicarFiltros();

        } catch (SQLException ex) {

            lblEstado.setText(
                    "Error consultando los planes."
            );

            mostrarEstadoVacio(
                    "No se pudieron cargar los planes",
                    ex.getMessage()
            );
        }
    }

    private void aplicarFiltros() {

        if (rejilla == null) {
            return;
        }

        rejilla.removeAll();

        String texto = buscador.getText() == null
                ? ""
                : buscador.getText().trim().toLowerCase(Locale.ROOT);

        String tipo = String.valueOf(
                filtro.getSelectedItem()
        );

        List<Plan> visibles = new ArrayList<>();

        for (Plan p : planes) {

            boolean coincideTexto =
                    texto.isEmpty()
                    || (p.nombre != null
                    && p.nombre.toLowerCase(Locale.ROOT).contains(texto))
                    || (p.descripcion != null
                    && p.descripcion.toLowerCase(Locale.ROOT).contains(texto));

            boolean coincideFiltro = switch (tipo) {

                case "Hasta 30 días" ->
                        p.dias() > 0 && p.dias() <= 30;

                case "Más de 30 días" ->
                        p.dias() > 30;

                case "Con entrenador" ->
                        p.entrenador;

                default ->
                        true;
            };

            if (coincideTexto && coincideFiltro) {
                visibles.add(p);
            }
        }

        if (visibles.isEmpty()) {

            lblResultados.setText(
                    "0 PLANES ENCONTRADOS"
            );

            rejilla.setLayout(
                    new BorderLayout()
            );

            rejilla.add(
                    estadoVacio(
                            "No encontramos ese plan",
                            "Prueba con otro nombre o cambia el filtro."
                    ),
                    BorderLayout.CENTER
            );

        } else {

            ajustarColumnas(getWidth());

            lblResultados.setText(
                    visibles.size()
                    + (visibles.size() == 1
                    ? " PLAN DISPONIBLE"
                    : " PLANES DISPONIBLES")
            );

            for (int i = 0; i < visibles.size(); i++) {

                Plan p = visibles.get(i);

                boolean recomendado =
                        p.entrenador || p.dias() >= 90;

                rejilla.add(
                        new TarjetaPlan(p, recomendado)
                );
            }
        }

        rejilla.revalidate();
        rejilla.repaint();
    }

    private void ajustarColumnas(int ancho) {

        int columnas =
                ancho > 0 && ancho < 1080
                        ? 2
                        : 3;

        rejilla.setLayout(
                new GridLayout(0, columnas, 18, 18)
        );

        rejilla.revalidate();
    }

    private void mostrarEstadoVacio(
            String titulo,
            String detalle
    ) {

        rejilla.removeAll();

        rejilla.setLayout(
                new BorderLayout()
        );

        rejilla.add(
                estadoVacio(titulo, detalle),
                BorderLayout.CENTER
        );

        rejilla.revalidate();
        rejilla.repaint();

        lblResultados.setText(
                "CATÁLOGO DE PLANES"
        );
    }

    private JPanel estadoVacio(
            String titulo,
            String detalle
    ) {

        JPanel p = new JPanel();

        p.setOpaque(false);

        p.setBorder(
                new EmptyBorder(50, 15, 50, 15)
        );

        p.setLayout(
                new BoxLayout(p, BoxLayout.Y_AXIS)
        );

        JLabel t = etiqueta(
                titulo,
                20,
                Font.BOLD,
                CREMA
        );

        t.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        JLabel d = etiqueta(
                detalle == null ? "" : detalle,
                12,
                Font.PLAIN,
                GRIS
        );

        d.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        p.add(t);
        p.add(Box.createVerticalStrut(9));
        p.add(d);
        p.add(Box.createVerticalStrut(18));

        BotonNexus recargar = new BotonNexus(
                "ACTUALIZAR CATÁLOGO",
                false
        );

        recargar.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        recargar.addActionListener(e ->
                cargarPlanes()
        );

        p.add(recargar);

        return p;
    }

    // ---------------------------------------------------------------------
    // Detalle del plan y paso de contratación.
    // ---------------------------------------------------------------------

    private void mostrarDetalle(Plan plan) {

        JDialog dialogo = new JDialog(
                (Frame) SwingUtilities.getWindowAncestor(this),
                "Nexus Gym | " + plan.nombre,
                Dialog.ModalityType.APPLICATION_MODAL
        );

        dialogo.setDefaultCloseOperation(
                WindowConstants.DISPOSE_ON_CLOSE
        );

        dialogo.setSize(560, 510);

        dialogo.setMinimumSize(
                new Dimension(500, 470)
        );

        dialogo.setLocationRelativeTo(this);

        JPanel raiz = new JPanel(
                new BorderLayout()
        );

        raiz.setBackground(FONDO_2);

        raiz.setBorder(
                new EmptyBorder(25, 28, 24, 28)
        );

        dialogo.setContentPane(raiz);

        JPanel encabezado = new JPanel(
                new BorderLayout()
        );

        encabezado.setOpaque(false);

        JPanel titulos = new JPanel();

        titulos.setOpaque(false);

        titulos.setLayout(
                new BoxLayout(titulos, BoxLayout.Y_AXIS)
        );

        JLabel eyebrow = etiqueta(
                "DETALLE DE MEMBRESÍA",
                10,
                Font.BOLD,
                NARANJA_CLARO
        );

        eyebrow.setFont(
                tracking(eyebrow.getFont(), .15f)
        );

        JLabel nombre = etiqueta(
                plan.nombre.toUpperCase(Locale.ROOT),
                24,
                Font.BOLD,
                CREMA
        );

        nombre.setFont(
                tracking(nombre.getFont(), -.01f)
        );

        titulos.add(eyebrow);
        titulos.add(Box.createVerticalStrut(8));
        titulos.add(nombre);

        encabezado.add(
                titulos,
                BorderLayout.WEST
        );

        JButton cerrar = new JButton("×");

        cerrar.setFont(
                fuente(Font.PLAIN, 25)
        );

        cerrar.setForeground(GRIS);

        cerrar.setBorderPainted(false);
        cerrar.setContentAreaFilled(false);
        cerrar.setFocusPainted(false);

        cerrar.addActionListener(e ->
                dialogo.dispose()
        );

        encabezado.add(
                cerrar,
                BorderLayout.EAST
        );

        raiz.add(
                encabezado,
                BorderLayout.NORTH
        );

        JPanel cuerpo = new JPanel();

        cuerpo.setOpaque(false);

        cuerpo.setLayout(
                new BoxLayout(cuerpo, BoxLayout.Y_AXIS)
        );

        cuerpo.setBorder(
                new EmptyBorder(28, 0, 20, 0)
        );

        JLabel precio = etiqueta(
                plan.precioBonito(),
                34,
                Font.BOLD,
                NARANJA_CLARO
        );

        precio.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        cuerpo.add(precio);

        JLabel duracion = etiqueta(
                "VIGENCIA DE " + plan.duracion + " DÍAS",
                10,
                Font.BOLD,
                GRIS
        );

        duracion.setFont(
                tracking(duracion.getFont(), .12f)
        );

        duracion.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        cuerpo.add(Box.createVerticalStrut(6));
        cuerpo.add(duracion);
        cuerpo.add(Box.createVerticalStrut(23));
        cuerpo.add(separador());
        cuerpo.add(Box.createVerticalStrut(17));
        cuerpo.add(tituloDetalle("LO QUE INCLUYE"));
        cuerpo.add(Box.createVerticalStrut(12));

        agregarDetalle(
                cuerpo,
                plan.descripcion == null
                        ? "Acceso a instalaciones Nexus Gym"
                        : plan.descripcion
        );

        agregarDetalle(
                cuerpo,
                plan.entrenador
                        ? "Entrenador personal incluido"
                        : "Entrenamiento a tu propio ritmo"
        );

        String limite = plan.limite == null
                ? ""
                : plan.limite.trim();

        if (!limite.isEmpty()
                && !limite.equalsIgnoreCase("NO APLICA")
                && !limite.equals("0")) {

            agregarDetalle(
                    cuerpo,
                    "Límite de " + limite + " ingresos durante la vigencia"
            );

        } else {

            agregarDetalle(
                    cuerpo,
                    "Accesos según las condiciones del plan"
            );
        }

        cuerpo.add(Box.createVerticalStrut(18));
        cuerpo.add(separador());
        cuerpo.add(Box.createVerticalStrut(15));

        JLabel nota = etiqueta(
                "Elige tu sede y completa la contratación iniciando sesión.",
                11,
                Font.PLAIN,
                GRIS
        );

        nota.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        cuerpo.add(nota);

        raiz.add(
                cuerpo,
                BorderLayout.CENTER
        );

        JPanel acciones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 10, 0)
        );

        acciones.setOpaque(false);

        BotonNexus volver = new BotonNexus(
                "SEGUIR EXPLORANDO",
                false
        );

        volver.addActionListener(e ->
                dialogo.dispose()
        );

        BotonNexus contratar = new BotonNexus(
                "INICIAR CONTRATACIÓN  →",
                true
        );

        contratar.addActionListener(e -> {
            dialogo.dispose();
            abrirLogin();
        });

        acciones.add(volver);
        acciones.add(contratar);

        raiz.add(
                acciones,
                BorderLayout.SOUTH
        );

        dialogo.setVisible(true);
    }

    private JComponent separador() {

        JSeparator s = new JSeparator();

        s.setForeground(
                new Color(255, 255, 255, 40)
        );

        s.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 1)
        );

        return s;
    }

    private JLabel tituloDetalle(String texto) {

        JLabel l = etiqueta(
                texto,
                10,
                Font.BOLD,
                NARANJA_CLARO
        );

        l.setFont(
                tracking(l.getFont(), .15f)
        );

        l.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        return l;
    }

    private void agregarDetalle(
            JPanel panel,
            String texto
    ) {

        JPanel fila = new JPanel(
                new BorderLayout(10, 0)
        );

        fila.setOpaque(false);

        fila.setAlignmentX(
                Component.LEFT_ALIGNMENT
        );

        JLabel check = etiqueta(
                "✓",
                15,
                Font.BOLD,
                NARANJA_CLARO
        );

        JLabel t = etiqueta(
                texto,
                13,
                Font.PLAIN,
                TEXTO
        );

        fila.add(
                check,
                BorderLayout.WEST
        );

        fila.add(
                t,
                BorderLayout.CENTER
        );

        panel.add(fila);
        panel.add(Box.createVerticalStrut(11));
    }

    private void abrirLogin() {

        try {

            LoginNuevo login = new LoginNuevo();

            login.setLocationRelativeTo(this);
            login.setVisible(true);

        } catch (Exception ex) {

            mensaje(
                    "INICIAR SESIÓN",
                    "No fue posible abrir la ventana de inicio de sesión.\n"
                    + ex.getMessage()
            );
        }
    }

    private void mensaje(
            String titulo,
            String texto
    ) {

        JOptionPane.showMessageDialog(
                this,
                texto,
                titulo,
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void abrirVentana(JFrame ventana) {

        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);

        Window actual =
                SwingUtilities.getWindowAncestor(this);

        if (actual != null) {
            actual.dispose();
        }
    }

    // ---------------------------------------------------------------------
    // Compatibilidad con las llamadas existentes del proyecto.
    // ---------------------------------------------------------------------

    public void abrirVentana() {

        JFrame f = crearVentana();

        f.setVisible(true);
    }

    public static JFrame crearVentana() {

        JFrame f = new JFrame(
                "Nexus Gym | Suscripciones y planes"
        );

        f.setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        f.setContentPane(
                new PanelPlanes()
        );

        f.setMinimumSize(
                new Dimension(980, 680)
        );

        f.setSize(1280, 850);

        f.setLocationRelativeTo(null);

        return f;
    }
}