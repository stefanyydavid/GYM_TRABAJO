
package nexusgym;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelNexusGym extends JFrame {

    private static final Color FONDO = new Color(17, 19, 24);
    private static final Color PANEL = new Color(25, 28, 35);
    private static final Color PANEL_CLARO = new Color(34, 38, 47);
    private static final Color NARANJA = new Color(255, 119, 0);
    private static final Color NARANJA_CLARO = new Color(255, 157, 61);
    private static final Color BLANCO = new Color(242, 244, 248);
    private static final Color GRIS = new Color(164, 170, 181);

    private final String nombreUsuario;
    private final String correoUsuario;

    private JPanel contenido;
    private JLabel tituloSeccion;
    private JLabel subtituloSeccion;

    public PanelNexusGym() {
        this("Usuario", "");
    }

    public PanelNexusGym(String nombre, String correo) {
        this.nombreUsuario = nombre == null || nombre.isBlank()
                ? "Usuario" : nombre;
        this.correoUsuario = correo == null ? "" : correo;

        configurarVentana();
        construirInterfaz();
        mostrarInicio();

        setLocationRelativeTo(null);
    }

    private void configurarVentana() {
        setTitle("NexusGym | Panel principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 760);
        setMinimumSize(new Dimension(950, 620));
        getContentPane().setBackground(FONDO);
        setLayout(new BorderLayout());
    }

    private void construirInterfaz() {
        add(crearMenuLateral(), BorderLayout.WEST);
        add(crearAreaPrincipal(), BorderLayout.CENTER);
    }

    private JPanel crearMenuLateral() {
        JPanel menu = new JPanel();
        menu.setBackground(PANEL);
        menu.setPreferredSize(new Dimension(245, 0));
        menu.setLayout(new BorderLayout());
        menu.setBorder(BorderFactory.createMatteBorder(
                0, 0, 0, 1, new Color(48, 51, 60)));

        JPanel superior = new JPanel();
        superior.setOpaque(false);
        superior.setLayout(new BoxLayout(superior, BoxLayout.Y_AXIS));
        superior.setBorder(new EmptyBorder(28, 20, 20, 20));

        JLabel logo = new JLabel("NEXUS");
        logo.setFont(new Font("SansSerif", Font.BOLD, 29));
        logo.setForeground(NARANJA);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel logo2 = new JLabel("GYM  |  FITNESS");
        logo2.setFont(new Font("SansSerif", Font.BOLD, 11));
        logo2.setForeground(GRIS);
        logo2.setAlignmentX(Component.LEFT_ALIGNMENT);

        superior.add(logo);
        superior.add(Box.createVerticalStrut(3));
        superior.add(logo2);
        superior.add(Box.createVerticalStrut(35));

        JLabel etiqueta = new JLabel("MENÚ PRINCIPAL");
        etiqueta.setFont(new Font("SansSerif", Font.BOLD, 11));
        etiqueta.setForeground(GRIS);
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
        superior.add(etiqueta);
        superior.add(Box.createVerticalStrut(12));

        superior.add(crearBotonMenu("⌂", "Inicio", this::mostrarInicio));
        superior.add(Box.createVerticalStrut(8));
        superior.add(crearBotonMenu("▦", "Horarios", this::mostrarHorarios));
        superior.add(Box.createVerticalStrut(8));
        superior.add(crearBotonMenu("✦", "Clases", this::mostrarClases));
        superior.add(Box.createVerticalStrut(8));
        superior.add(crearBotonMenu("●", "Mi perfil", this::mostrarPerfil));

        menu.add(superior, BorderLayout.NORTH);

        JPanel inferior = new JPanel();
        inferior.setOpaque(false);
        inferior.setLayout(new BoxLayout(inferior, BoxLayout.Y_AXIS));
        inferior.setBorder(new EmptyBorder(15, 18, 22, 18));

        JLabel estado = new JLabel("●  SISTEMA ACTIVO");
        estado.setForeground(new Color(90, 210, 140));
        estado.setFont(new Font("SansSerif", Font.BOLD, 11));

        JButton salir = new JButton("Cerrar sesión");
        estilizarBotonSecundario(salir);
        salir.setAlignmentX(Component.LEFT_ALIGNMENT);
        salir.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        salir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Deseas cerrar la sesión?",
                    "Cerrar sesión",
                    JOptionPane.YES_NO_OPTION
            );

            if (opcion == JOptionPane.YES_OPTION) {
                dispose();
            }
        });

        inferior.add(estado);
        inferior.add(Box.createVerticalStrut(18));
        inferior.add(salir);

        menu.add(inferior, BorderLayout.SOUTH);

        return menu;
    }

    private JButton crearBotonMenu(
            String icono, String texto, Runnable accion) {

        JButton boton = new JButton(icono + "    " + texto);
        boton.setFont(new Font("SansSerif", Font.BOLD, 14));
        boton.setForeground(BLANCO);
        boton.setBackground(PANEL);
        boton.setHorizontalAlignment(SwingConstants.LEFT);
        boton.setBorder(new EmptyBorder(14, 13, 14, 10));
        boton.setFocusPainted(false);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(PANEL_CLARO);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(PANEL);
            }
        });

        boton.addActionListener(e -> accion.run());

        return boton;
    }

    private JPanel crearAreaPrincipal() {
        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(FONDO);

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(FONDO);
        encabezado.setBorder(new EmptyBorder(25, 32, 20, 32));

        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));

        tituloSeccion = new JLabel("Inicio");
        tituloSeccion.setFont(new Font("SansSerif", Font.BOLD, 27));
        tituloSeccion.setForeground(BLANCO);

        subtituloSeccion = new JLabel("Bienvenido a NexusGym");
        subtituloSeccion.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtituloSeccion.setForeground(GRIS);

        textos.add(tituloSeccion);
        textos.add(Box.createVerticalStrut(5));
        textos.add(subtituloSeccion);

        JPanel usuario = new JPanel(new FlowLayout(
                FlowLayout.RIGHT, 12, 0));
        usuario.setOpaque(false);

        JLabel iniciales = new JLabel(obtenerIniciales(nombreUsuario),
                SwingConstants.CENTER);
        iniciales.setPreferredSize(new Dimension(43, 43));
        iniciales.setOpaque(true);
        iniciales.setBackground(NARANJA);
        iniciales.setForeground(Color.WHITE);
        iniciales.setFont(new Font("SansSerif", Font.BOLD, 15));

        JPanel datos = new JPanel();
        datos.setOpaque(false);
        datos.setLayout(new BoxLayout(datos, BoxLayout.Y_AXIS));

        JLabel nombre = new JLabel(nombreUsuario);
        nombre.setForeground(BLANCO);
        nombre.setFont(new Font("SansSerif", Font.BOLD, 13));

        JLabel rol = new JLabel("Miembro NexusGym");
        rol.setForeground(GRIS);
        rol.setFont(new Font("SansSerif", Font.PLAIN, 11));

        datos.add(nombre);
        datos.add(Box.createVerticalStrut(4));
        datos.add(rol);

        usuario.add(datos);
        usuario.add(iniciales);

        encabezado.add(textos, BorderLayout.WEST);
        encabezado.add(usuario, BorderLayout.EAST);

        contenido = new JPanel(new BorderLayout(0, 20));
        contenido.setBackground(FONDO);
        contenido.setBorder(new EmptyBorder(0, 32, 30, 32));

        principal.add(encabezado, BorderLayout.NORTH);
        principal.add(contenido, BorderLayout.CENTER);

        return principal;
    }

    private void prepararSeccion(String titulo, String subtitulo) {
        tituloSeccion.setText(titulo);
        subtituloSeccion.setText(subtitulo);
        contenido.removeAll();
    }

    private void terminarSeccion() {
        contenido.revalidate();
        contenido.repaint();
    }

    private void mostrarInicio() {
        prepararSeccion(
                "¡Hola, " + nombreUsuario + "!",
                "Tu espacio personal de entrenamiento."
        );

        JPanel pagina = new JPanel();
        pagina.setOpaque(false);
        pagina.setLayout(new BoxLayout(pagina, BoxLayout.Y_AXIS));

        JPanel bienvenida = new JPanel(new BorderLayout(20, 10));
        bienvenida.setBackground(PANEL);
        bienvenida.setBorder(new EmptyBorder(28, 28, 28, 28));

        JPanel mensaje = new JPanel();
        mensaje.setOpaque(false);
        mensaje.setLayout(new BoxLayout(mensaje, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("SUPERA TUS LÍMITES");
        titulo.setForeground(NARANJA_CLARO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 13));

        JLabel frase = new JLabel(
                "<html><div style='width:440px'>"
                + "Cada entrenamiento te acerca a tu mejor versión."
                + "</div></html>"
        );
        frase.setForeground(BLANCO);
        frase.setFont(new Font("SansSerif", Font.BOLD, 23));

        JLabel descripcion = new JLabel(
                "<html><div style='width:440px'>"
                + "Organiza tu tiempo, explora nuestras clases "
                + "y mantén tu motivación."
                + "</div></html>"
        );
        descripcion.setForeground(GRIS);
        descripcion.setFont(new Font("SansSerif", Font.PLAIN, 14));

        mensaje.add(titulo);
        mensaje.add(Box.createVerticalStrut(13));
        mensaje.add(frase);
        mensaje.add(Box.createVerticalStrut(12));
        mensaje.add(descripcion);

        JButton botonClases = crearBotonPrimario(
                "Explorar clases  →");
        botonClases.addActionListener(e -> mostrarClases());

        bienvenida.add(mensaje, BorderLayout.CENTER);
        bienvenida.add(botonClases, BorderLayout.SOUTH);
        bienvenida.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));

        pagina.add(bienvenida);
        pagina.add(Box.createVerticalStrut(24));

        JLabel seccion = crearTitulo("TU ESPACIO FITNESS");
        seccion.setAlignmentX(Component.LEFT_ALIGNMENT);
        pagina.add(seccion);
        pagina.add(Box.createVerticalStrut(14));

        JPanel tarjetas = new JPanel(new GridLayout(1, 3, 15, 0));
        tarjetas.setOpaque(false);

        tarjetas.add(crearTarjeta(
                "▦", "Horarios", "Consulta y organiza tus entrenamientos",
                "Ver horarios", this::mostrarHorarios
        ));

        tarjetas.add(crearTarjeta(
                "✦", "Clases", "Encuentra la actividad ideal para ti",
                "Ver clases", this::mostrarClases
        ));

        tarjetas.add(crearTarjeta(
                "●", "Mi perfil", "Consulta tus datos personales",
                "Ver perfil", this::mostrarPerfil
        ));

        tarjetas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));
        pagina.add(tarjetas);

        JScrollPane scroll = crearScroll(pagina);
        contenido.add(scroll, BorderLayout.CENTER);
        terminarSeccion();
    }

    private void mostrarHorarios() {
        prepararSeccion(
                "Horarios",
                "Organiza tus sesiones de entrenamiento."
        );

        JPanel pagina = crearPaginaVertical();

        JLabel descripcion = crearTexto(
                "Selecciona una actividad y consulta su horario."
        );
        pagina.add(descripcion);
        pagina.add(Box.createVerticalStrut(20));

        String[] columnas = {
            "Actividad", "Día", "Hora", "Duración"
        };

        Object[][] datos = {
            {"Spinning", "Lunes", "7:00 a. m.", "45 min"},
            {"Yoga", "Martes", "8:00 a. m.", "60 min"},
            {"CrossFit", "Miércoles", "6:00 p. m.", "60 min"},
            {"Zumba", "Jueves", "5:00 p. m.", "45 min"},
            {"Pilates", "Viernes", "9:00 a. m.", "60 min"}
        };

        JTable tabla = new JTable(datos, columnas);
        tabla.setRowHeight(44);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tabla.setForeground(BLANCO);
        tabla.setBackground(PANEL);
        tabla.setGridColor(new Color(53, 57, 66));
        tabla.setSelectionBackground(new Color(91, 54, 29));
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setFillsViewportHeight(true);

        tabla.getTableHeader().setBackground(PANEL_CLARO);
        tabla.getTableHeader().setForeground(NARANJA_CLARO);
        tabla.getTableHeader().setFont(
                new Font("SansSerif", Font.BOLD, 13));
        tabla.getTableHeader().setPreferredSize(
                new Dimension(0, 42));

        JScrollPane tablaScroll = new JScrollPane(tabla);
        tablaScroll.setBorder(BorderFactory.createLineBorder(
                new Color(53, 57, 66)));
        tablaScroll.getViewport().setBackground(PANEL);

        pagina.add(tablaScroll);

        JLabel nota = crearTexto(
                "Nota: estos horarios son de ejemplo y se pueden "
                + "reemplazar por los horarios reales del gimnasio."
        );
        pagina.add(Box.createVerticalStrut(15));
        pagina.add(nota);

        contenido.add(crearScroll(pagina), BorderLayout.CENTER);
        terminarSeccion();
    }

    private void mostrarClases() {
        prepararSeccion(
                "Nuestras clases",
                "Encuentra tu próxima actividad favorita."
        );

        JPanel pagina = new JPanel(new GridLayout(0, 2, 16, 16));
        pagina.setOpaque(false);

        pagina.add(crearClase(
                "SPINNING",
                "Entrenamiento cardiovascular sobre bicicleta.",
                "45 minutos"
        ));

        pagina.add(crearClase(
                "YOGA",
                "Equilibrio, flexibilidad y control de la respiración.",
                "60 minutos"
        ));

        pagina.add(crearClase(
                "CROSSFIT",
                "Fuerza y acondicionamiento físico de alta intensidad.",
                "60 minutos"
        ));

        pagina.add(crearClase(
                "ZUMBA",
                "Ejercicio dinámico acompañado de música y baile.",
                "45 minutos"
        ));

        pagina.add(crearClase(
                "PILATES",
                "Control corporal, movilidad y fortalecimiento.",
                "60 minutos"
        ));

        contenido.add(crearScroll(pagina), BorderLayout.CENTER);
        terminarSeccion();
    }

    private JPanel crearClase(
            String nombre, String descripcion, String duracion) {

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(PANEL);
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(new EmptyBorder(23, 23, 23, 23));

        JLabel icono = new JLabel("✦");
        icono.setForeground(NARANJA);
        icono.setFont(new Font("SansSerif", Font.BOLD, 27));

        JLabel titulo = new JLabel(nombre);
        titulo.setForeground(BLANCO);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 19));

        JLabel detalle = new JLabel(
                "<html><div style='width:260px'>"
                + descripcion + "</div></html>"
        );
        detalle.setForeground(GRIS);
        detalle.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JLabel tiempo = new JLabel("Duración: " + duracion);
        tiempo.setForeground(NARANJA_CLARO);
        tiempo.setFont(new Font("SansSerif", Font.BOLD, 12));

        tarjeta.add(icono);
        tarjeta.add(Box.createVerticalStrut(13));
        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(10));
        tarjeta.add(detalle);
        tarjeta.add(Box.createVerticalStrut(17));
        tarjeta.add(tiempo);

        return tarjeta;
    }

    private void mostrarPerfil() {
        prepararSeccion(
                "Mi perfil",
                "Consulta la información de tu cuenta."
        );

        JPanel pagina = crearPaginaVertical();

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(PANEL);
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(new EmptyBorder(28, 28, 28, 28));

        JLabel iniciales = new JLabel(
                obtenerIniciales(nombreUsuario),
                SwingConstants.CENTER
        );
        iniciales.setOpaque(true);
        iniciales.setBackground(NARANJA);
        iniciales.setForeground(Color.WHITE);
        iniciales.setFont(new Font("SansSerif", Font.BOLD, 25));
        iniciales.setPreferredSize(new Dimension(75, 75));
        iniciales.setMaximumSize(new Dimension(75, 75));
        iniciales.setAlignmentX(Component.LEFT_ALIGNMENT);

        tarjeta.add(iniciales);
        tarjeta.add(Box.createVerticalStrut(22));
        tarjeta.add(crearDatoPerfil("Nombre", nombreUsuario));
        tarjeta.add(Box.createVerticalStrut(17));
        tarjeta.add(crearDatoPerfil(
                "Correo electrónico",
                correoUsuario.isBlank() ? "No registrado" : correoUsuario
        ));
        tarjeta.add(Box.createVerticalStrut(17));
        tarjeta.add(crearDatoPerfil("Membresía", "Miembro NexusGym"));

        tarjeta.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));

        pagina.add(tarjeta);
        contenido.add(crearScroll(pagina), BorderLayout.CENTER);
        terminarSeccion();
    }

    private JPanel crearDatoPerfil(String etiqueta, String valor) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titulo = crearTexto(etiqueta);
        JLabel contenidoDato = new JLabel(valor);
        contenidoDato.setForeground(BLANCO);
        contenidoDato.setFont(
                new Font("SansSerif", Font.BOLD, 15));

        panel.add(titulo);
        panel.add(Box.createVerticalStrut(5));
        panel.add(contenidoDato);

        return panel;
    }

    private JPanel crearTarjeta(
            String icono,
            String titulo,
            String descripcion,
            String textoBoton,
            Runnable accion) {

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(PANEL);
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(new EmptyBorder(20, 18, 20, 18));

        JLabel simbolo = new JLabel(icono);
        simbolo.setForeground(NARANJA);
        simbolo.setFont(new Font("SansSerif", Font.BOLD, 26));

        JLabel nombre = new JLabel(titulo);
        nombre.setForeground(BLANCO);
        nombre.setFont(new Font("SansSerif", Font.BOLD, 17));

        JLabel detalle = new JLabel(
                "<html><div style='width:200px'>"
                + descripcion + "</div></html>"
        );
        detalle.setForeground(GRIS);
        detalle.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JButton boton = crearBotonPrimario(textoBoton);
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);
        boton.addActionListener(e -> accion.run());

        tarjeta.add(simbolo);
        tarjeta.add(Box.createVerticalStrut(12));
        tarjeta.add(nombre);
        tarjeta.add(Box.createVerticalStrut(8));
        tarjeta.add(detalle);
        tarjeta.add(Box.createVerticalGlue());
        tarjeta.add(Box.createVerticalStrut(18));
        tarjeta.add(boton);

        return tarjeta;
    }

    private JLabel crearTitulo(String texto) {
        JLabel label = new JLabel(texto);
        label.setForeground(BLANCO);
        label.setFont(new Font("SansSerif", Font.BOLD, 17));
        return label;
    }

    private JLabel crearTexto(String texto) {
        JLabel label = new JLabel(texto);
        label.setForeground(GRIS);
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        return label;
    }

    private JPanel crearPaginaVertical() {
        JPanel panel = new JPanel();
        panel.setBackground(FONDO);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        return panel;
    }

    private JScrollPane crearScroll(Component componente) {
        JScrollPane scroll = new JScrollPane(componente);
        scroll.setBorder(null);
        scroll.setBackground(FONDO);
        scroll.getViewport().setBackground(FONDO);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        return scroll;
    }

    private JButton crearBotonPrimario(String texto) {
        JButton boton = new JButton(texto);
        boton.setBackground(NARANJA);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
        boton.setBorder(new EmptyBorder(12, 16, 12, 16));
        boton.setCursor(Cursor.getPredefinedCursor(
                Cursor.HAND_CURSOR));
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);
        return boton;
    }

    private void estilizarBotonSecundario(JButton boton) {
        boton.setBackground(PANEL_CLARO);
        boton.setForeground(BLANCO);
        boton.setFont(new Font("SansSerif", Font.BOLD, 12));
        boton.setFocusPainted(false);
        boton.setBorder(new EmptyBorder(12, 14, 12, 14));
        boton.setCursor(Cursor.getPredefinedCursor(
                Cursor.HAND_CURSOR));
    }

    private String obtenerIniciales(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            return "U";
        }

        String[] partes = nombre.trim().split("\\s+");
        String resultado = partes[0].substring(0, 1).toUpperCase();

        if (partes.length > 1) {
            resultado += partes[partes.length - 1]
                    .substring(0, 1).toUpperCase();
        }

        return resultado;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PanelNexusGym ventana = new PanelNexusGym(
                    "Usuario", "usuario@ejemplo.com");
            ventana.setVisible(true);
        });
    }
}
