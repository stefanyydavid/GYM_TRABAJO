package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import java.awt.*;

public class PanelNexusGym extends JFrame {

    private final String nombre;
    private final String correo;

    private final Color FONDO = new Color(13, 15, 18);
    private final Color SIDEBAR = new Color(19, 21, 25);
    private final Color TARJETA = new Color(25, 28, 33);
    private final Color VERDE = new Color(86, 210, 125);
    private final Color BLANCO = new Color(245, 245, 245);
    private final Color GRIS = new Color(160, 165, 175);

    private JPanel contenido;
    private JLabel tituloSeccion;

    public PanelNexusGym(String nombre, String correo) {

        this.nombre = nombre;
        this.correo = correo;

        setTitle("NexusGym");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        construirInterfaz();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(FONDO);

        principal.add(crearMenu(), BorderLayout.WEST);

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBackground(FONDO);

        centro.add(crearBarraSuperior(), BorderLayout.NORTH);

        contenido = new JPanel(new BorderLayout());
        contenido.setBackground(FONDO);

        contenido.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 25, 25, 25
                )
        );

        mostrarInicio();

        centro.add(contenido, BorderLayout.CENTER);

        principal.add(centro, BorderLayout.CENTER);

        setContentPane(principal);
    }

    private JPanel crearMenu() {

        JPanel menu = new JPanel();
        menu.setPreferredSize(new Dimension(220, 0));
        menu.setBackground(SIDEBAR);

        menu.setLayout(
                new BorderLayout()
        );

        JPanel superior = new JPanel();

        superior.setBackground(SIDEBAR);

        superior.setLayout(
                new BoxLayout(
                        superior,
                        BoxLayout.Y_AXIS
                )
        );

        superior.setBorder(
                BorderFactory.createEmptyBorder(
                        30, 20, 20, 20
                )
        );

        JLabel nexus = new JLabel("NEXUS");

        nexus.setForeground(VERDE);
        nexus.setFont(
                new Font("Arial", Font.BOLD, 27)
        );

        JLabel gym = new JLabel("GYM");

        gym.setForeground(BLANCO);
        gym.setFont(
                new Font("Arial", Font.BOLD, 27)
        );

        superior.add(nexus);
        superior.add(gym);

        superior.add(
                Box.createVerticalStrut(45)
        );

        JButton inicio = crearBotonMenu("INICIO");
        JButton horarios = crearBotonMenu("HORARIOS");
        JButton clases = crearBotonMenu("CLASES");
        JButton perfil = crearBotonMenu("MI PERFIL");

        inicio.addActionListener(
                e -> mostrarInicio()
        );

        horarios.addActionListener(
                e -> mostrarHorarios()
        );

        clases.addActionListener(
                e -> mostrarClases()
        );

        perfil.addActionListener(
                e -> mostrarPerfil()
        );

        superior.add(inicio);
        superior.add(Box.createVerticalStrut(8));

        superior.add(horarios);
        superior.add(Box.createVerticalStrut(8));

        superior.add(clases);
        superior.add(Box.createVerticalStrut(8));

        superior.add(perfil);

        menu.add(
                superior,
                BorderLayout.NORTH
        );

        JButton cerrar = crearBotonMenu(
                "CERRAR SESIÓN"
        );

        cerrar.addActionListener(e -> {

            new PaginaPrincipal().setVisible(true);

            dispose();
        });

        JPanel inferior = new JPanel();

        inferior.setBackground(SIDEBAR);

        inferior.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 25, 20
                )
        );

        inferior.setLayout(
                new BorderLayout()
        );

        inferior.add(
                cerrar,
                BorderLayout.CENTER
        );

        menu.add(
                inferior,
                BorderLayout.SOUTH
        );

        return menu;
    }

    private JLabel crearIniciales() {

        String iniciales = "";

        if (nombre != null && !nombre.isEmpty()) {

            String[] partes = nombre.trim().split("\\s+");

            if (partes.length >= 2) {

                iniciales =
                        partes[0].substring(0, 1)
                        +
                        partes[1].substring(0, 1);

            } else {

                iniciales =
                        partes[0].substring(0, 1);
            }
        }

        JLabel circulo = new JLabel(
                iniciales.toUpperCase()
        );

        circulo.setPreferredSize(
                new Dimension(42, 42)
        );

        circulo.setMinimumSize(
                new Dimension(42, 42)
        );

        circulo.setMaximumSize(
                new Dimension(42, 42)
        );

        circulo.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        circulo.setVerticalAlignment(
                SwingConstants.CENTER
        );

        circulo.setForeground(Color.BLACK);
        circulo.setBackground(VERDE);
        circulo.setOpaque(true);

        circulo.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        return circulo;
    }

    private JPanel crearBarraSuperior() {

        JPanel barra = new JPanel(
                new BorderLayout()
        );

        barra.setBackground(FONDO);

        barra.setPreferredSize(
                new Dimension(0, 85)
        );

        barra.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 25, 10, 25
                )
        );

        tituloSeccion = new JLabel(
                "INICIO"
        );

        tituloSeccion.setForeground(BLANCO);

        tituloSeccion.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        barra.add(
                tituloSeccion,
                BorderLayout.WEST
        );

        JPanel usuario = new JPanel(
                new FlowLayout(
                        FlowLayout.RIGHT,
                        10,
                        0
                )
        );

        usuario.setBackground(FONDO);

        JLabel nombreUsuario =
                new JLabel(nombre);

        nombreUsuario.setForeground(BLANCO);

        nombreUsuario.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        usuario.add(nombreUsuario);
        usuario.add(crearIniciales());

        barra.add(
                usuario,
                BorderLayout.EAST
        );

        return barra;
    }

    private void mostrarInicio() {

        tituloSeccion.setText("INICIO");

        JPanel panel = new JPanel();

        panel.setBackground(FONDO);

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel bienvenida =
                new JLabel(
                        "Bienvenido, " + nombre
                );

        bienvenida.setForeground(BLANCO);

        bienvenida.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        JLabel descripcion =
                new JLabel(
                        "Gestiona tu entrenamiento desde NexusGym."
                );

        descripcion.setForeground(GRIS);

        descripcion.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        panel.add(bienvenida);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(descripcion);

        panel.add(
                Box.createVerticalStrut(30)
        );

        JPanel tarjetas = new JPanel(
                new GridLayout(
                        1,
                        3,
                        15,
                        0
                )
        );

        tarjetas.setBackground(FONDO);

        tarjetas.add(
                crearTarjeta(
                        "USUARIO",
                        nombre
                )
        );

        tarjetas.add(
                crearTarjeta(
                        "CORREO",
                        correo
                )
        );

        tarjetas.add(
                crearTarjeta(
                        "MEMBRESÍA",
                        "ACTIVA"
                )
        );

        panel.add(tarjetas);

        contenido.removeAll();

        contenido.add(
                panel,
                BorderLayout.CENTER
        );

        actualizar();
    }

    private JPanel crearTarjeta(
            String titulo,
            String valor) {

        JPanel tarjeta = new JPanel();

        tarjeta.setBackground(TARJETA);

        tarjeta.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        tarjeta.setLayout(
                new BoxLayout(
                        tarjeta,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel t = new JLabel(titulo);

        t.setForeground(GRIS);

        t.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        11
                )
        );

        JLabel v = new JLabel(valor);

        v.setForeground(VERDE);

        v.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        tarjeta.add(t);

        tarjeta.add(
                Box.createVerticalStrut(12)
        );

        tarjeta.add(v);

        return tarjeta;
    }

    private void mostrarHorarios() {

        tituloSeccion.setText(
                "HORARIOS"
        );

        JPanel panel = new JPanel(
                new BorderLayout(0, 20)
        );

        panel.setBackground(FONDO);

        JLabel texto = new JLabel(
                "Consulta los horarios disponibles."
        );

        texto.setForeground(GRIS);

        panel.add(
                texto,
                BorderLayout.NORTH
        );

        JPanel lista = new JPanel(
                new GridLayout(
                        5,
                        1,
                        0,
                        10
                )
        );

        lista.setBackground(FONDO);

        lista.add(
                crearHorario(
                        "LUNES",
                        "06:00",
                        "FUNCIONAL"
                )
        );

        lista.add(
                crearHorario(
                        "MARTES",
                        "18:00",
                        "SPINNING"
                )
        );

        lista.add(
                crearHorario(
                        "MIÉRCOLES",
                        "07:00",
                        "MUSCULACIÓN"
                )
        );

        lista.add(
                crearHorario(
                        "JUEVES",
                        "19:00",
                        "FUNCIONAL"
                )
        );

        lista.add(
                crearHorario(
                        "VIERNES",
                        "17:00",
                        "CARDIO"
                )
        );

        panel.add(
                lista,
                BorderLayout.CENTER
        );

        contenido.removeAll();

        contenido.add(
                panel,
                BorderLayout.CENTER
        );

        actualizar();
    }

    private JPanel crearHorario(
            String dia,
            String hora,
            String clase) {

        JPanel fila = new JPanel(
                new BorderLayout()
        );

        fila.setBackground(TARJETA);

        fila.setBorder(
                BorderFactory.createEmptyBorder(
                        12, 20, 12, 20
                )
        );

        JLabel d = new JLabel(dia);

        d.setForeground(VERDE);

        d.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        JLabel c = new JLabel(clase);

        c.setForeground(BLANCO);

        c.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        JLabel h = new JLabel(hora);

        h.setForeground(BLANCO);

        h.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        fila.add(
                d,
                BorderLayout.WEST
        );

        fila.add(
                c,
                BorderLayout.CENTER
        );

        fila.add(
                h,
                BorderLayout.EAST
        );

        return fila;
    }

    private void mostrarClases() {

        tituloSeccion.setText(
                "CLASES"
        );

        JPanel panel = new JPanel(
                new GridLayout(
                        2,
                        2,
                        15,
                        15
                )
        );

        panel.setBackground(FONDO);

        panel.add(
                crearClase(
                        "FUNCIONAL",
                        "Entrenamiento completo"
                )
        );

        panel.add(
                crearClase(
                        "SPINNING",
                        "Cardio y resistencia"
                )
        );

        panel.add(
                crearClase(
                        "MUSCULACIÓN",
                        "Fuerza y desarrollo"
                )
        );

        panel.add(
                crearClase(
                        "CARDIO",
                        "Resistencia física"
                )
        );

        contenido.removeAll();

        contenido.add(
                panel,
                BorderLayout.CENTER
        );

        actualizar();
    }

    private JPanel crearClase(
            String nombreClase,
            String descripcion) {

        JPanel tarjeta = new JPanel();

        tarjeta.setBackground(TARJETA);

        tarjeta.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        tarjeta.setLayout(
                new BoxLayout(
                        tarjeta,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel titulo =
                new JLabel(nombreClase);

        titulo.setForeground(VERDE);

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        19
                )
        );

        JLabel texto =
                new JLabel(descripcion);

        texto.setForeground(GRIS);

        texto.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        JButton boton =
                new JButton("VER CLASE");

        boton.setBackground(VERDE);

        boton.setForeground(Color.BLACK);

        boton.setFocusPainted(false);

        boton.setBorderPainted(false);

        boton.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        tarjeta.add(titulo);

        tarjeta.add(
                Box.createVerticalStrut(12)
        );

        tarjeta.add(texto);

        tarjeta.add(
                Box.createVerticalStrut(20)
        );

        tarjeta.add(boton);

        return tarjeta;
    }

    private void mostrarPerfil() {

        tituloSeccion.setText(
                "MI PERFIL"
        );

        JPanel panel = new JPanel();

        panel.setBackground(TARJETA);

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        30, 30, 30, 30
                )
        );

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel titulo =
                new JLabel(
                        "Información de tu cuenta"
                );

        titulo.setForeground(BLANCO);

        titulo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        23
                )
        );

        JLabel lblNombre =
                new JLabel(
                        "Nombre: " + nombre
                );

        lblNombre.setForeground(GRIS);

        lblNombre.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        JLabel lblCorreo =
                new JLabel(
                        "Correo: " + correo
                );

        lblCorreo.setForeground(GRIS);

        lblCorreo.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        panel.add(titulo);

        panel.add(
                Box.createVerticalStrut(25)
        );

        panel.add(lblNombre);

        panel.add(
                Box.createVerticalStrut(12)
        );

        panel.add(lblCorreo);

        contenido.removeAll();

        contenido.add(
                panel,
                BorderLayout.CENTER
        );

        actualizar();
    }

    private JButton crearBotonMenu(
            String texto) {

        JButton boton =
                new JButton(texto);

        boton.setMaximumSize(
                new Dimension(
                        180,
                        43
                )
        );

        boton.setMinimumSize(
                new Dimension(
                        180,
                        43
                )
        );

        boton.setPreferredSize(
                new Dimension(
                        180,
                        43
                )
        );

        boton.setHorizontalAlignment(
                SwingConstants.LEFT
        );

        boton.setForeground(GRIS);

        boton.setBackground(SIDEBAR);

        boton.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        boton.setBorder(
                BorderFactory.createEmptyBorder(
                        0, 15, 0, 0
                )
        );

        boton.setFocusPainted(false);

        boton.setBorderPainted(false);

        boton.setContentAreaFilled(false);

        boton.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        boton.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            java.awt.event.MouseEvent e) {

                        boton.setForeground(VERDE);
                    }

                    @Override
                    public void mouseExited(
                            java.awt.event.MouseEvent e) {

                        boton.setForeground(GRIS);
                    }
                }
        );

        return boton;
    }

    private void actualizar() {

        contenido.revalidate();
        contenido.repaint();
    }

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {

            new PanelNexusGym(
                    "Usuario",
                    "correo@ejemplo.com"
            ).setVisible(true);

        });
    }
}