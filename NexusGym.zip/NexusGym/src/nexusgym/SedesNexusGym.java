package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Pantalla de sedes dibujada sobre SEDES.jpg, usando el mismo sistema de zonas
 * clicables y efectos hover que PaginaPrincipal.
 */
public class SedesNexusGym extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color FONDO = new Color(13, 15, 20);

    // Medidas originales de SEDES.jpg. Las zonas se escalan con la imagen.
    private static final int REF_ANCHO = 1536;
    private static final int REF_ALTO = 883;

    private enum Tipo { MENU, BOTON }

    private record Zona(String nombre, double x, double y, double w, double h,
                        Tipo tipo, Runnable accion) { }

    private final List<Zona> zonas = new ArrayList<>();
    private BufferedImage imagen;
    private Zona zonaHover;
    private Lienzo lienzo;

    public SedesNexusGym() {
        setTitle("Nexus Gym | Sedes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagen();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1160, 667));
        setContentPane(lienzo);
        setMinimumSize(new Dimension(960, 520));
        pack();
        setLocationRelativeTo(null);
        configurarTeclado();
    }

    private void cargarImagen() {
        URL url = getClass().getResource("/nexusgym/SEDES.jpg");
        if (url == null) {
            url = getClass().getResource("/nexusgym/sedes.jpg");
        }
        if (url != null) {
            try {
                imagen = ImageIO.read(url);
            } catch (IOException ex) {
                imagen = null;
            }
        }
    }

    private void crearZonas() {
        // Coordenadas medidas sobre la imagen original SEDES.jpg (1536 x 883).
        // El logotipo también es clicable y devuelve a la página principal.
        zonas.add(new Zona("NEXUS GYM", 42, 18, 235, 62, Tipo.MENU,
                () -> abrirVentana(new PaginaPrincipal())));
        // Las zonas corresponden a las etiquetas y botones visibles, no a una imagen distinta.
        zonas.add(new Zona("SEDES", 309, 25, 100, 42, Tipo.MENU, () -> { }));
        zonas.add(new Zona("SERVICIOS", 424, 25, 137, 42, Tipo.MENU,
                () -> abrirVentana(new ServiciosNexusGym())));
        zonas.add(new Zona("CLASES", 579, 25, 105, 42, Tipo.MENU,
                () -> abrirVentana(new ClasesNexusGym())));
        zonas.add(new Zona("SUSCRIPCIONES / PLANES", 700, 25, 307, 42, Tipo.MENU,
                () -> mostrarEnProceso("SUSCRIPCIONES / PLANES")));
        zonas.add(new Zona("PAGOS", 1029, 25, 91, 42, Tipo.MENU,
                () -> mostrarEnProceso("PAGOS")));
        zonas.add(new Zona("INICIAR SESIÓN", 1298, 22, 205, 54, Tipo.BOTON,
                () -> abrirVentana(new LoginNuevo())));

        // Franja promocional: enlace Más info y botón para cerrar el aviso.
        zonas.add(new Zona("Más info", 910, 108, 91, 39, Tipo.MENU,
                () -> mostrarEnProceso("Promoción de un mes gratis")));
        zonas.add(new Zona("Cerrar aviso", 1486, 106, 38, 42, Tipo.MENU,
                () -> { avisoVisible = false; lienzo.repaint(); }));

        // Botones VER SEDE: límites ajustados a los botones naranjas del JPG.
        zonas.add(new Zona("VER SEDE Chapinero", 53, 776, 122, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(0, "Chapinero")));
        zonas.add(new Zona("VER SEDE Poblado", 553, 776, 123, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(1, "Poblado")));
        zonas.add(new Zona("VER SEDE Norte", 1057, 776, 123, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(2, "Norte")));
    }

    private boolean avisoVisible = true;

    private void configurarTeclado() {
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "volver");
        getRootPane().getActionMap().put("volver", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                abrirVentana(new PaginaPrincipal());
            }
        });
    }

    private void abrirVentana(JFrame ventana) {
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    private void mostrarDetalleSede(int posicion, String nombreVisible) {
        String sql = "SELECT id_sede, nombre, direccion, telefono, email "
                + "FROM sedes WHERE activo = 1 ORDER BY id_sede LIMIT 1 OFFSET ?";
        Connection conexion = Conexion.getInstancia().conectar();
        if (conexion == null) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo conectar con la base de datos.", "Nexus Gym",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try (PreparedStatement pst = conexion.prepareStatement(sql)) {
            pst.setInt(1, posicion);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String nombre = valor(rs.getString("nombre"), nombreVisible);
                    String direccion = valor(rs.getString("direccion"), "No registrada");
                    String telefono = valor(rs.getString("telefono"), "No registrado");
                    String email = valor(rs.getString("email"), "No registrado");
                    String mensaje = nombre + "\n\nDirección: " + direccion
                            + "\nTeléfono: " + telefono + "\nEmail: " + email;
                    JOptionPane.showMessageDialog(this, mensaje, "Sede " + nombreVisible,
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                            "No hay datos activos registrados para esta sede en la base de datos.",
                            "Sede " + nombreVisible, JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "No fue posible consultar la sede.\n\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String valor(String texto, String alternativa) {
        return texto == null || texto.isBlank() ? alternativa : texto;
    }

    private void mostrarEnProceso(String seccion) {
        JOptionPane.showMessageDialog(this,
                "La sección " + seccion + " estará disponible próximamente.",
                "Nexus Gym", JOptionPane.INFORMATION_MESSAGE);
    }

    private void abrirUrl(String url) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(java.net.URI.create(url));
            } else {
                mostrarEnProceso("Redes sociales");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo abrir el enlace.",
                    "Nexus Gym", JOptionPane.WARNING_MESSAGE);
        }
    }

    private class Lienzo extends JPanel {
        Lienzo() {
            setBackground(FONDO);
            setFocusable(true);
            MouseAdapter raton = new MouseAdapter() {
                @Override public void mouseMoved(MouseEvent e) {
                    Zona nueva = zonaEn(e.getPoint());
                    if (nueva != zonaHover) {
                        zonaHover = nueva;
                        setCursor(Cursor.getPredefinedCursor(
                                nueva == null ? Cursor.DEFAULT_CURSOR : Cursor.HAND_CURSOR));
                        setToolTipText(nueva == null ? null : nueva.nombre());
                        repaint();
                    }
                }
                @Override public void mouseExited(MouseEvent e) {
                    zonaHover = null;
                    setCursor(Cursor.getDefaultCursor());
                    setToolTipText(null);
                    repaint();
                }
                @Override public void mouseReleased(MouseEvent e) {
                    if (e.getButton() != MouseEvent.BUTTON1) return;
                    Zona z = zonaEn(e.getPoint());
                    if (z != null) z.accion().run();
                }
            };
            addMouseListener(raton);
            addMouseMotionListener(raton);
        }

        private Rectangle2D.Double areaImagen() {
            double escala = Math.min(getWidth() / (double) REF_ANCHO,
                    getHeight() / (double) REF_ALTO);
            double w = REF_ANCHO * escala;
            double h = REF_ALTO * escala;
            return new Rectangle2D.Double((getWidth() - w) / 2.0,
                    (getHeight() - h) / 2.0, w, h);
        }

        private Rectangle2D.Double aPantalla(Zona z, Rectangle2D.Double a) {
            double s = a.width / REF_ANCHO;
            return new Rectangle2D.Double(a.x + z.x() * s, a.y + z.y() * s,
                    z.w() * s, z.h() * s);
        }

        private Zona zonaEn(Point p) {
            Rectangle2D.Double a = areaImagen();
            for (int i = zonas.size() - 1; i >= 0; i--) {
                if (aPantalla(zonas.get(i), a).contains(p)) return zonas.get(i);
            }
            return null;
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(FONDO);
            g2.fillRect(0, 0, getWidth(), getHeight());
            Rectangle2D.Double a = areaImagen();

            if (imagen != null) {
                g2.drawImage(imagen, (int) a.x, (int) a.y,
                        (int) a.width, (int) a.height, null);
            } else {
                g2.setColor(CREMA);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 22));
                g2.drawString("No se encontró /nexusgym/SEDES.jpg",
                        (int) a.x + 30, (int) a.y + 60);
            }

            if (!avisoVisible) {
                double s = a.width / REF_ANCHO;
                int x = (int) (a.x + 0 * s);
                int y = (int) (a.y + 62 * s);
                int w = (int) a.width;
                int h = (int) (a.height * 60.0 / REF_ALTO);
                g2.setColor(new Color(13, 15, 20));
                g2.fillRect(x, y, w, h);
            }

            dibujarHover(g2, a);
            g2.dispose();
        }

        private void dibujarHover(Graphics2D g2, Rectangle2D.Double a) {
            if (zonaHover == null) return;
            Rectangle2D.Double r = aPantalla(zonaHover, a);
            if (zonaHover.tipo() == Tipo.MENU) {
                g2.setColor(new Color(255, 255, 255, 28));
                g2.fill(new RoundRectangle2D.Double(r.x, r.y, r.width, r.height, 9, 9));
                double ancho = r.width * 0.62;
                g2.setColor(NARANJA);
                g2.fill(new RoundRectangle2D.Double(r.x + (r.width - ancho) / 2,
                        r.y + r.height - 3, ancho, 3, 3, 3));
            } else {
                g2.setColor(new Color(232, 106, 36, 55));
                g2.fill(new RoundRectangle2D.Double(r.x, r.y, r.width, r.height, 10, 10));
                g2.setColor(NARANJA);
                g2.setStroke(new BasicStroke(2f));
                g2.draw(new RoundRectangle2D.Double(r.x + 1, r.y + 1,
                        r.width - 2, r.height - 2, 10, 10));
            }
        }
    }

    public static void main(String[] args) {
        FlatDarkLaf.setup();
        SwingUtilities.invokeLater(() -> new SedesNexusGym().setVisible(true));
    }
}
