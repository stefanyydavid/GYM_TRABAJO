package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Pantalla de sedes dibujada sobre SEDES.jpg, usando el mismo sistema de zonas
 * clicables y efectos hover que PaginaPrincipal.
 */
public class SedesNexusGym extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color FONDO = new Color(13, 15, 20);
    private static final Color VERDE = new Color(102, 165, 88);
    private static final Color GRIS = new Color(150, 152, 158);
    private static final Color TEXTO_OSCURO = new Color(32, 28, 24);

    // Medidas originales de SEDES.jpg. Las zonas se escalan con la imagen.
    private static final int REF_ANCHO = 1536;
    private static final int REF_ALTO = 883;

    private enum Tipo { MENU, BOTON }

    private record Zona(String nombre, double x, double y, double w, double h,
                        Tipo tipo, Runnable accion) { }

    private final List<Zona> zonas = new ArrayList<>();
    private BufferedImage imagen;
    private Zona zonaHover;
    private Lienzo lienzo;
    private boolean avisoVisible = true;

    public SedesNexusGym() {
        setTitle("Nexus Gym | Sedes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagen();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1160, 667));
        setContentPane(lienzo);
        setMinimumSize(new Dimension(960, 520));
        pack();
        setLocationRelativeTo(null);
        configurarTeclado();
    }

    private void cargarImagen() {
        URL url = getClass().getResource("/nexusgym/SEDES.jpg");
        if (url == null) {
            url = getClass().getResource("/nexusgym/sedes.jpg");
        }
        if (url != null) {
            try {
                imagen = ImageIO.read(url);
            } catch (IOException ex) {
                imagen = null;
            }
        }
    }

    private void crearZonas() {
        zonas.add(new Zona("NEXUS GYM", 42, 18, 235, 62, Tipo.MENU,
                () -> abrirVentana(new PaginaPrincipal())));
        zonas.add(new Zona("SEDES", 309, 25, 100, 42, Tipo.MENU, () -> { }));
        zonas.add(new Zona("SERVICIOS", 424, 25, 137, 42, Tipo.MENU,
                () -> abrirVentana(new ServiciosNexusGym())));
        zonas.add(new Zona("CLASES", 579, 25, 105, 42, Tipo.MENU,
                () -> abrirVentana(new ClasesNexusGym())));
        zonas.add(new Zona("SUSCRIPCIONES / PLANES", 700, 25, 307, 42, Tipo.MENU,
                () -> mostrarEnProceso("SUSCRIPCIONES / PLANES")));
        zonas.add(new Zona("PAGOS", 1029, 25, 91, 42, Tipo.MENU,
                () -> mostrarEnProceso("PAGOS")));
        zonas.add(new Zona("INICIAR SESIÓN", 1298, 22, 205, 54, Tipo.BOTON,
                () -> abrirVentana(new LoginNuevo())));

        zonas.add(new Zona("Más info", 910, 108, 91, 39, Tipo.MENU,
                () -> mostrarEnProceso("Promoción de un mes gratis")));
        zonas.add(new Zona("Cerrar aviso", 1486, 106, 38, 42, Tipo.MENU,
                () -> { avisoVisible = false; lienzo.repaint(); }));

        zonas.add(new Zona("VER SEDE Chapinero", 53, 776, 122, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(0, "Chapinero")));
        zonas.add(new Zona("VER SEDE Poblado", 553, 776, 123, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(1, "Poblado")));
        zonas.add(new Zona("VER SEDE Norte", 1057, 776, 123, 43, Tipo.BOTON,
                () -> mostrarDetalleSede(2, "Norte")));
    }

    private void configurarTeclado() {
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "volver");
        getRootPane().getActionMap().put("volver", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                abrirVentana(new PaginaPrincipal());
            }
        });
    }

    private void abrirVentana(JFrame ventana) {
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    // =====================================================================
    //  DETALLE DE SEDE (ESTÉTICA NEXUS GYM)
    // =====================================================================

    private static String familiaFuente;

    private static Font fuente(int estilo, int tam) {
        if (familiaFuente == null) {
            Set<String> disponibles = new HashSet<>(Arrays.asList(
                    GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
            familiaFuente = "SansSerif";
            for (String f : new String[]{"Montserrat", "Poppins", "Roboto", "Segoe UI", "Helvetica Neue"}) {
                if (disponibles.contains(f)) {
                    familiaFuente = f;
                    break;
                }
            }
        }
        return new Font(familiaFuente, estilo, tam);
    }

    private static Font espaciado(Font f, float tracking) {
        Map<java.awt.font.TextAttribute, Object> m = new HashMap<>();
        m.put(java.awt.font.TextAttribute.TRACKING, tracking);
        return f.deriveFont(m);
    }

    private static void calidad(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    private static String recortar(String t, FontMetrics fm, int max) {
        if (t == null) return "";
        if (fm.stringWidth(t) <= max) return t;
        String s = t;
        while (s.length() > 1 && fm.stringWidth(s + "…") > max) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "…";
    }

    private static int baseline(FontMetrics fm, int alto) {
        return (alto - fm.getHeight()) / 2 + fm.getAscent();
    }

    private static JLabel etiqueta(String texto, Font fuente, Color color) {
        JLabel l = new JLabel(texto);
        l.setFont(fuente);
        l.setForeground(color);
        return l;
    }

    private static void fijarAlto(JComponent c, int alto) {
        c.setPreferredSize(new Dimension(100, alto));
        c.setMinimumSize(new Dimension(0, alto));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, alto));
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    // ---------- Contenedor principal con sombra y degradado ----------
    private static class Tarjeta extends JPanel {
        static final int M = 18;

        Tarjeta() {
            super(new BorderLayout());
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(M, M, M, M));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setComposite(AlphaComposite.Clear);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setComposite(AlphaComposite.SrcOver);

            int w = getWidth();
            int h = getHeight();
            // Sombra suave
            for (int k = 0; k < M; k++) {
                g2.setColor(new Color(0, 0, 0, 6));
                g2.fill(new RoundRectangle2D.Double(M - k, M - k + 5, w - 2 * M + 2 * k,
                        h - 2 * M + 2 * k, 24 + k, 24 + k));
            }
            RoundRectangle2D cuerpo = new RoundRectangle2D.Double(M, M, w - 2 * M, h - 2 * M, 24, 24);
            g2.setPaint(new GradientPaint(0, M, new Color(24, 27, 35), 0, h - M, new Color(11, 13, 17)));
            g2.fill(cuerpo);
            // Resplandor naranja inferior
            g2.setPaint(new RadialGradientPaint(new java.awt.geom.Point2D.Float(M + 40, h - M),
                    w * 0.55f, new float[]{0f, 1f},
                    new Color[]{new Color(232, 106, 36, 38), new Color(232, 106, 36, 0)}));
            g2.fill(cuerpo);
            g2.setColor(new Color(255, 255, 255, 38));
            g2.setStroke(new BasicStroke(1f));
            g2.draw(new RoundRectangle2D.Double(M + 0.5, M + 0.5, w - 2 * M - 1, h - 2 * M - 1, 24, 24));
            g2.dispose();
        }
    }

    // ---------- Cabecera tipo hero con luces geométricas ----------
    private static class Cabecera extends JPanel {
        private final String nombre;
        private final String subtitulo;

        Cabecera(String nombre, String subtitulo) {
            super(new BorderLayout());
            this.nombre = nombre.toUpperCase();
            this.subtitulo = subtitulo;
            setOpaque(false);
            setPreferredSize(new Dimension(100, 150));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            g2.setClip(new Rectangle(0, 0, w, h));
            RoundRectangle2D forma = new RoundRectangle2D.Double(0, 0, w, h + 30, 24, 24);
            g2.setPaint(new GradientPaint(0, 0, new Color(8, 10, 14), w, h, new Color(40, 45, 57)));
            g2.fill(forma);
            g2.setPaint(new RadialGradientPaint(new java.awt.geom.Point2D.Float(w * 0.82f, h * 0.1f),
                    w * 0.45f, new float[]{0f, 1f},
                    new Color[]{new Color(232, 106, 36, 100), new Color(232, 106, 36, 0)}));
            g2.fill(forma);

            // Luces geométricas (inspiradas en el techo del gimnasio)
            Path2D.Double poligono = new Path2D.Double();
            poligono.moveTo(w * 0.50, h * 0.34);
            poligono.lineTo(w * 0.73, h * 0.10);
            poligono.lineTo(w * 0.91, h * 0.46);
            poligono.lineTo(w * 0.66, h * 0.70);
            poligono.closePath();
            Path2D.Double diagonal = new Path2D.Double();
            diagonal.moveTo(w * 0.73, h * 0.10);
            diagonal.lineTo(w * 0.66, h * 0.70);
            float[] anchos = {12f, 7f, 3f};
            int[] alfas = {22, 45, 235};
            for (int i = 0; i < anchos.length; i++) {
                g2.setStroke(new BasicStroke(anchos[i], BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.setColor(new Color(255, 255, 255, alfas[i]));
                g2.draw(poligono);
                g2.draw(diagonal);
            }

            // Velo izquierdo para dar legibilidad al texto
            g2.setPaint(new GradientPaint(0, 0, new Color(8, 10, 14, 215), w * 0.62f, 0, new Color(8, 10, 14, 0)));
            g2.fill(forma);

            // Línea inferior de acento
            g2.setPaint(new GradientPaint(0, 0, NARANJA, w, 0, new Color(232, 106, 36, 0)));
            g2.fillRect(0, h - 3, w, 3);

            // Textos
            g2.setFont(espaciado(fuente(Font.BOLD, 12), 0.25f));
            g2.setColor(NARANJA);
            g2.drawString("NEXUS GYM", 32, 40);

            Font fNombre = fuente(Font.BOLD, 34);
            g2.setFont(fNombre);
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            g2.drawString(recortar(nombre, fm, (int) (w * 0.6)), 32, 88);

            g2.setFont(espaciado(fuente(Font.PLAIN, 12), 0.12f));
            g2.setColor(GRIS);
            g2.drawString(subtitulo, 32, 118);
            int anchoSub = g2.getFontMetrics().stringWidth(subtitulo);

            // Insignia ACTIVA
            int bx = 32 + anchoSub + 14;
            g2.setColor(new Color(102, 165, 88, 45));
            g2.fillRoundRect(bx, 104, 74, 20, 20, 20);
            g2.setColor(VERDE);
            g2.fillOval(bx + 9, 111, 6, 6);
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.12f));
            g2.drawString("ACTIVA", bx + 20, 118);
            g2.dispose();
        }
    }

    // ---------- Botón de cerrar dibujado ----------
    private static class BotonCerrar extends JButton {
        private boolean hover;

        BotonCerrar() {
            setPreferredSize(new Dimension(34, 34));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setColor(hover ? NARANJA : new Color(255, 255, 255, 28));
            g2.fillOval(1, 1, getWidth() - 2, getHeight() - 2);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            int c = getWidth() / 2;
            g2.drawLine(c - 5, c - 5, c + 5, c + 5);
            g2.drawLine(c + 5, c - 5, c - 5, c + 5);
            g2.dispose();
        }
    }

    // ---------- Botones principales ----------
    private static class BotonNexus extends JButton {
        private boolean hover;
        private final boolean relleno;

        BotonNexus(String texto, boolean relleno) {
            super(texto);
            this.relleno = relleno;
            setFont(espaciado(fuente(Font.BOLD, 12), 0.1f));
            setForeground(Color.WHITE);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(166, 54));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            int m = 7;
            RoundRectangle2D forma = new RoundRectangle2D.Double(m, m, w - 2 * m, h - 2 * m, 12, 12);
            if (relleno) {
                if (hover) {
                    for (int i = 1; i <= 6; i++) {
                        g2.setColor(new Color(232, 106, 36, 16));
                        g2.fill(new RoundRectangle2D.Double(m - i, m - i, w - 2 * m + 2 * i,
                                h - 2 * m + 2 * i, 12 + i, 12 + i));
                    }
                }
                boolean pulsado = getModel().isPressed();
                g2.setPaint(new GradientPaint(0, m,
                        pulsado ? new Color(214, 92, 24) : new Color(255, 135, 58),
                        0, h - m,
                        pulsado ? new Color(170, 70, 14) : new Color(214, 92, 24)));
                g2.fill(forma);
                g2.setColor(new Color(255, 255, 255, 55));
                g2.setStroke(new BasicStroke(1f));
                g2.draw(new RoundRectangle2D.Double(m + 0.5, m + 0.5, w - 2 * m - 1, h - 2 * m - 1, 12, 12));
            } else {
                g2.setColor(hover ? new Color(232, 106, 36, 50) : new Color(255, 255, 255, 8));
                g2.fill(forma);
                g2.setColor(hover ? NARANJA : new Color(232, 106, 36, 170));
                g2.setStroke(new BasicStroke(1.6f));
                g2.draw(new RoundRectangle2D.Double(m + 0.8, m + 0.8, w - 2 * m - 1.6, h - 2 * m - 1.6, 12, 12));
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ---------- Tarjeta de estadística ----------
    private static class Tile extends JPanel {
        private final String valor;
        private final String titulo;

        Tile(String valor, String titulo) {
            this.valor = valor;
            this.titulo = titulo;
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 16, 16);
            g2.setPaint(new GradientPaint(0, 0, new Color(38, 42, 52), 0, h, new Color(22, 25, 32)));
            g2.fill(r);
            g2.setColor(new Color(255, 255, 255, 30));
            g2.draw(r);
            g2.setColor(NARANJA);
            g2.fillRoundRect(0, 18, 4, h - 36, 4, 4);

            g2.setFont(fuente(Font.BOLD, 26));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            g2.drawString(recortar(valor, fm, w - 36), 20, 40);
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.12f));
            g2.setColor(GRIS);
            g2.drawString(titulo, 20, 62);
            g2.dispose();
        }
    }

    // ---------- Tarjeta crema (estilo cuadro "Tu próximo paso") ----------
    private static class TarjetaCrema extends JPanel {
        TarjetaCrema() {
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            g2.setColor(new Color(0, 0, 0, 40));
            g2.fill(new RoundRectangle2D.Double(2, 5, w - 4, h - 5, 18, 18));
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, w, h - 4, 18, 18);
            g2.setPaint(new GradientPaint(0, 0, new Color(250, 244, 233), 0, h, new Color(232, 221, 202)));
            g2.fill(r);
            g2.setColor(NARANJA);
            g2.fillRoundRect(0, 0, w, 4, 4, 4);
            g2.dispose();
        }
    }

    private JPanel celdaDato(String titulo, String texto) {
        JPanel c = new JPanel();
        c.setOpaque(false);
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        JLabel t = etiqueta(titulo, espaciado(fuente(Font.BOLD, 10), 0.15f), NARANJA);
        JLabel v = etiqueta(texto, fuente(Font.BOLD, 14), TEXTO_OSCURO);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        v.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.add(t);
        c.add(Box.createVerticalStrut(4));
        c.add(v);
        return c;
    }

    // ---------- Fila de clase ----------
    private static class FilaClase extends JPanel {
        private final String[] datos;
        private final boolean encabezado;
        private final boolean par;
        private boolean hover;

        FilaClase(String[] datos, boolean encabezado, boolean par) {
            this.datos = datos;
            this.encabezado = encabezado;
            this.par = par;
            setOpaque(false);
            if (!encabezado) {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                });
            }
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            if (encabezado) {
                g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.15f));
                FontMetrics fm = g2.getFontMetrics();
                g2.setColor(GRIS);
                int y = baseline(fm, h);
                g2.drawString(datos[0], 16, y);
                g2.drawString(datos[1], 132, y);
                g2.drawString(datos[2], 272, y);
                g2.drawString(datos[3], w - 16 - fm.stringWidth(datos[3]), y);
                g2.dispose();
                return;
            }
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 2, w, h - 4, 12, 12);
            g2.setColor(hover ? new Color(232, 106, 36, 36)
                    : (par ? new Color(255, 255, 255, 12) : new Color(255, 255, 255, 5)));
            g2.fill(r);
            if (hover) {
                g2.setColor(NARANJA);
                g2.fillRoundRect(0, 9, 3, h - 18, 3, 3);
            }
            // Píldora del día
            g2.setFont(espaciado(fuente(Font.BOLD, 10), 0.1f));
            FontMetrics fm = g2.getFontMetrics();
            int ph = 24;
            int py = (h - ph) / 2;
            g2.setColor(new Color(232, 106, 36, 46));
            g2.fillRoundRect(16, py, 96, ph, ph, ph);
            g2.setColor(NARANJA);
            String dia = datos[0].toUpperCase();
            g2.drawString(dia, 16 + (96 - fm.stringWidth(dia)) / 2, py + baseline(fm, ph));

            g2.setFont(fuente(Font.PLAIN, 13));
            fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            g2.drawString(datos[1], 132, baseline(fm, h));

            g2.setFont(fuente(Font.BOLD, 13));
            fm = g2.getFontMetrics();
            g2.setColor(Color.WHITE);
            g2.drawString(recortar(datos[2], fm, 190), 272, baseline(fm, h));

            g2.setFont(fuente(Font.PLAIN, 12));
            fm = g2.getFontMetrics();
            g2.setColor(GRIS);
            String ent = recortar(datos[3], fm, 190);
            g2.drawString(ent, w - 16 - fm.stringWidth(ent), baseline(fm, h));
            g2.dispose();
        }
    }

    // ---------- Tarjeta de plan ----------
    private static class PlanCard extends JPanel {
        private final String[] datos;
        private boolean hover;

        PlanCard(String[] datos) {
            this.datos = datos;
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            int w = getWidth();
            int h = getHeight();
            RoundRectangle2D r = new RoundRectangle2D.Double(1, 1, w - 3, h - 3, 14, 14);
            g2.setPaint(hover
                    ? new GradientPaint(0, 0, new Color(60, 38, 26), 0, h, new Color(30, 22, 20))
                    : new GradientPaint(0, 0, new Color(36, 40, 50), 0, h, new Color(22, 25, 32)));
            g2.fill(r);
            g2.setColor(hover ? NARANJA : new Color(255, 255, 255, 32));
            g2.setStroke(new BasicStroke(hover ? 1.8f : 1f));
            g2.draw(r);

            g2.setFont(fuente(Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(CREMA);
            String n = recortar(datos[0], fm, w - 16);
            g2.drawString(n, (w - fm.stringWidth(n)) / 2, 27);

            g2.setFont(fuente(Font.BOLD, 17));
            fm = g2.getFontMetrics();
            g2.setColor(NARANJA);
            String p = recortar(datos[1], fm, w - 12);
            g2.drawString(p, (w - fm.stringWidth(p)) / 2, 52);

            g2.setFont(fuente(Font.PLAIN, 11));
            fm = g2.getFontMetrics();
            g2.setColor(GRIS);
            g2.drawString(datos[2], (w - fm.stringWidth(datos[2])) / 2, 70);
            g2.dispose();
        }
    }

    // ---------- Panel que acompaña el ancho del scroll ----------
    private static class PanelScroll extends JPanel implements Scrollable {
        PanelScroll() {
            setOpaque(false);
        }
        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 18; }
        @Override public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 90; }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }

    // ---------- Barra de scroll delgada ----------
    private static class BarraNexus extends javax.swing.plaf.basic.BasicScrollBarUI {
        private JButton cero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            b.setMinimumSize(new Dimension(0, 0));
            b.setMaximumSize(new Dimension(0, 0));
            return b;
        }
        @Override protected JButton createDecreaseButton(int orientation) { return cero(); }
        @Override protected JButton createIncreaseButton(int orientation) { return cero(); }
        @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
        @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            calidad(g2);
            g2.setColor(isThumbRollover() || isDragging ? NARANJA : new Color(255, 255, 255, 70));
            g2.fillRoundRect(r.x + 3, r.y + 2, r.width - 6, r.height - 4, 8, 8);
            g2.dispose();
        }
    }

    private JComponent tituloSeccion(String texto) {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setOpaque(false);
        p.add(etiqueta(texto, espaciado(fuente(Font.BOLD, 12), 0.2f), NARANJA), BorderLayout.WEST);
        JSeparator s = new JSeparator();
        s.setForeground(new Color(255, 255, 255, 35));
        p.add(s, BorderLayout.CENTER);
        fijarAlto(p, 26);
        return p;
    }

    // =====================================================================
    //  CONSULTA A LA BASE DE DATOS
    // =====================================================================

    private void mostrarDetalleSede(int posicion, String nombreVisible) {
        Connection conexion = Conexion.getInstancia().conectar();
        if (conexion == null) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar con la base de datos.",
                    "Nexus Gym", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String sqlSede = "SELECT id_sede, nombre, direccion, telefono, email, fecha_creacion "
                + "FROM sedes WHERE activo = 1 ORDER BY id_sede LIMIT 1 OFFSET ?";
        String sqlClases = "SELECT h.dia_semana, h.hora_inicio, h.hora_fin, c.nombre AS clase, "
                + "CONCAT(e.nombres, ' ', e.apellidos) AS entrenador "
                + "FROM horarios_clases h "
                + "JOIN clases c ON c.id_clase = h.id_clase "
                + "JOIN entrenadores e ON e.id_entrenador = h.id_entrenador "
                + "WHERE h.id_sede = ? AND h.activo = 1 "
                + "ORDER BY FIELD(h.dia_semana,'LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'), "
                + "h.hora_inicio";
        String sqlPlanes = "SELECT nombre, precio, duracion_dias FROM planes WHERE activo = 1 ORDER BY precio + 0";

        try (PreparedStatement pst = conexion.prepareStatement(sqlSede)) {
            pst.setInt(1, posicion);
            try (ResultSet rs = pst.executeQuery()) {
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this,
                            "No hay datos activos registrados para esta sede.",
                            "Sede " + nombreVisible, JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                int idSede = rs.getInt("id_sede");
                String nombre = valor(rs.getString("nombre"), "Sede " + nombreVisible);
                String direccion = valor(rs.getString("direccion"), "No registrada");
                String telefono = valor(rs.getString("telefono"), "No registrado");
                String email = valor(rs.getString("email"), "No registrado");
                String desde = "—";
                if (rs.getTimestamp("fecha_creacion") != null) {
                    desde = new java.text.SimpleDateFormat("dd/MM/yyyy")
                            .format(rs.getTimestamp("fecha_creacion"));
                }

                List<String[]> clases = new ArrayList<>();
                try (PreparedStatement pc = conexion.prepareStatement(sqlClases)) {
                    pc.setInt(1, idSede);
                    try (ResultSet rc = pc.executeQuery()) {
                        while (rc.next()) {
                            String dia = rc.getString("dia_semana");
                            dia = dia.charAt(0) + dia.substring(1).toLowerCase();
                            String hora = rc.getString("hora_inicio").substring(0, 5) + " - "
                                    + rc.getString("hora_fin").substring(0, 5);
                            clases.add(new String[]{dia, hora, rc.getString("clase"),
                                    rc.getString("entrenador")});
                        }
                    }
                }

                List<String[]> planes = new ArrayList<>();
                java.text.NumberFormat moneda = java.text.NumberFormat.getInstance(
                        java.util.Locale.forLanguageTag("es-CO"));
                try (PreparedStatement pp = conexion.prepareStatement(sqlPlanes);
                     ResultSet rp = pp.executeQuery()) {
                    while (rp.next()) {
                        String precio = "$" + moneda.format((long) Double.parseDouble(rp.getString("precio")));
                        planes.add(new String[]{rp.getString("nombre"), precio,
                                rp.getString("duracion_dias") + " días"});
                    }
                }
                construirDialogoSede(idSede, nombre, direccion, telefono, email, desde, clases, planes);
            }
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "No fue posible consultar la sede.\n\n" + ex.getMessage(),
                    "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================================
    //  CONSTRUCCIÓN DEL DIÁLOGO
    // =====================================================================

    private void construirDialogoSede(int idSede, String nombre, String direccion, String telefono,
                                      String email, String desde, List<String[]> clases,
                                      List<String[]> planes) {
        final JDialog d = new JDialog(this, true);
        d.setUndecorated(true);
        boolean translucido = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
                .isWindowTranslucencySupported(GraphicsDevice.WindowTranslucency.PERPIXEL_TRANSLUCENT);
        d.setBackground(translucido ? new Color(0, 0, 0, 0) : FONDO);

        // Ciudad a partir de la dirección
        String ciudad = "";
        int coma = direccion.lastIndexOf(',');
        if (coma >= 0 && coma < direccion.length() - 1) {
            ciudad = direccion.substring(coma + 1).trim().toUpperCase();
        }
        String subtitulo = "SEDE #" + idSede + (ciudad.isEmpty() ? "" : "  ·  " + ciudad);

        Tarjeta raiz = new Tarjeta();

        // ---------- Cabecera ----------
        Cabecera cab = new Cabecera(nombre, subtitulo);
        BotonCerrar btnX = new BotonCerrar();
        btnX.addActionListener(e -> d.dispose());
        JPanel esquina = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        esquina.setOpaque(false);
        esquina.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 16));
        esquina.add(btnX);
        cab.add(esquina, BorderLayout.NORTH);
        final int[] desfase = new int[2];
        MouseAdapter arrastre = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                desfase[0] = e.getXOnScreen() - d.getX();
                desfase[1] = e.getYOnScreen() - d.getY();
            }
            @Override public void mouseDragged(MouseEvent e) {
                d.setLocation(e.getXOnScreen() - desfase[0], e.getYOnScreen() - desfase[1]);
            }
        };
        cab.addMouseListener(arrastre);
        cab.addMouseMotionListener(arrastre);
        raiz.add(cab, BorderLayout.NORTH);

        // ---------- Cuerpo ----------
        PanelScroll cuerpo = new PanelScroll();
        cuerpo.setLayout(new BoxLayout(cuerpo, BoxLayout.Y_AXIS));
        cuerpo.setBorder(BorderFactory.createEmptyBorder(18, 28, 10, 28));

        // Estadísticas
        Set<String> entrenadores = new HashSet<>();
        for (String[] c : clases) {
            entrenadores.add(c[3]);
        }
        JPanel fila = new JPanel(new GridLayout(1, 3, 12, 0));
        fila.setOpaque(false);
        fila.add(new Tile(String.valueOf(clases.size()), "CLASES POR SEMANA"));
        fila.add(new Tile(String.valueOf(entrenadores.size()), "ENTRENADORES"));
        fila.add(new Tile(planes.isEmpty() ? "—" : planes.get(0)[1], "PLANES DESDE"));
        fijarAlto(fila, 84);
        cuerpo.add(fila);
        cuerpo.add(Box.createVerticalStrut(16));

        // Tarjeta crema con datos de contacto
        TarjetaCrema crema = new TarjetaCrema();
        crema.setLayout(new GridLayout(2, 2, 24, 14));
        crema.setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));
        crema.add(celdaDato("DIRECCIÓN", direccion));
        crema.add(celdaDato("TELÉFONO", telefono));
        crema.add(celdaDato("EMAIL", email));
        crema.add(celdaDato("ABIERTA DESDE", desde));
        fijarAlto(crema, 132);
        cuerpo.add(crema);
        cuerpo.add(Box.createVerticalStrut(22));

        // Clases
        cuerpo.add(tituloSeccion("CLASES DE LA SEDE"));
        cuerpo.add(Box.createVerticalStrut(6));
        if (clases.isEmpty()) {
            JLabel vacio = etiqueta("Sin clases programadas por el momento.", fuente(Font.PLAIN, 13), GRIS);
            vacio.setBorder(BorderFactory.createEmptyBorder(8, 4, 8, 4));
            vacio.setAlignmentX(Component.LEFT_ALIGNMENT);
            cuerpo.add(vacio);
        } else {
            FilaClase enc = new FilaClase(new String[]{"DÍA", "HORARIO", "CLASE", "ENTRENADOR"}, true, false);
            fijarAlto(enc, 26);
            cuerpo.add(enc);
            for (int i = 0; i < clases.size(); i++) {
                FilaClase fc = new FilaClase(clases.get(i), false, i % 2 == 0);
                fijarAlto(fc, 42);
                cuerpo.add(fc);
            }
        }
        cuerpo.add(Box.createVerticalStrut(22));

        // Planes
        cuerpo.add(tituloSeccion("PLANES DISPONIBLES"));
        cuerpo.add(Box.createVerticalStrut(10));
        if (!planes.isEmpty()) {
            JPanel filaPlanes = new JPanel(new GridLayout(1, planes.size(), 10, 0));
            filaPlanes.setOpaque(false);
            for (String[] p : planes) {
                filaPlanes.add(new PlanCard(p));
            }
            fijarAlto(filaPlanes, 86);
            cuerpo.add(filaPlanes);
        }
        cuerpo.add(Box.createVerticalStrut(8));

        JScrollPane sp = new JScrollPane(cuerpo,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
        sp.setViewportBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
        sp.getVerticalScrollBar().setUI(new BarraNexus());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        sp.getVerticalScrollBar().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        raiz.add(sp, BorderLayout.CENTER);

        // ---------- Pie ----------
        JPanel pie = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 22));
                g2.drawLine(24, 0, getWidth() - 24, 0);
                g2.dispose();
            }
        };
        pie.setOpaque(false);
        pie.setBorder(BorderFactory.createEmptyBorder(6, 28, 12, 18));
        pie.add(etiqueta("ESC para cerrar", fuente(Font.PLAIN, 11), GRIS), BorderLayout.WEST);
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        botones.setOpaque(false);
        BotonNexus btnCerrar = new BotonNexus("CERRAR", false);
        btnCerrar.addActionListener(e -> d.dispose());
        BotonNexus btnClases = new BotonNexus("VER CLASES", true);
        btnClases.addActionListener(e -> {
            d.dispose();
            abrirVentana(new ClasesNexusGym());
        });
        botones.add(btnCerrar);
        botones.add(btnClases);
        pie.add(botones, BorderLayout.EAST);
        raiz.add(pie, BorderLayout.SOUTH);

        d.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "cerrarSede");
        d.getRootPane().getActionMap().put("cerrarSede", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { d.dispose(); }
        });

        d.setContentPane(raiz);
        int altoPantalla = Toolkit.getDefaultToolkit().getScreenSize().height;
        d.setSize(new Dimension(800, Math.min(830, altoPantalla - 50)));
        d.setLocationRelativeTo(this);

        // Aparición suave
        try {
            d.setOpacity(0f);
            final javax.swing.Timer fade = new javax.swing.Timer(15, null);
            fade.addActionListener(ev -> {
                float o = Math.min(1f, d.getOpacity() + 0.1f);
                try {
                    d.setOpacity(o);
                } catch (Exception ex) {
                    fade.stop();
                }
                if (o >= 1f) fade.stop();
            });
            fade.start();
        } catch (Exception ignorada) {
            // Si el sistema no soporta opacidad, se muestra directamente.
        }
        d.setVisible(true);
    }

    private String valor(String texto, String alternativa) {
        return texto == null || texto.isBlank() ? alternativa : texto;
    }

    private void mostrarEnProceso(String seccion) {
        JOptionPane.showMessageDialog(this,
                "La sección " + seccion + " estará disponible próximamente.",
                "Nexus Gym", JOptionPane.INFORMATION_MESSAGE);
    }

    private void abrirUrl(String url) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(java.net.URI.create(url));
            } else {
                mostrarEnProceso("Redes sociales");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo abrir el enlace.",
                    "Nexus Gym", JOptionPane.WARNING_MESSAGE);
        }
    }

    // =====================================================================
    //  LIENZO
    // =====================================================================

    private class Lienzo extends JPanel {
        Lienzo() {
            setBackground(FONDO);
            setFocusable(true);
            MouseAdapter raton = new MouseAdapter() {
                @Override public void mouseMoved(MouseEvent e) {
                    Zona nueva = zonaEn(e.getPoint());
                    if (nueva != zonaHover) {
                        zonaHover = nueva;
                        setCursor(Cursor.getPredefinedCursor(
                                nueva == null ? Cursor.DEFAULT_CURSOR : Cursor.HAND_CURSOR));
                        setToolTipText(nueva == null ? null : nueva.nombre());
                        repaint();
                    }
                }
                @Override public void mouseExited(MouseEvent e) {
                    zonaHover = null;
                    setCursor(Cursor.getDefaultCursor());
                    setToolTipText(null);
                    repaint();
                }
                @Override public void mouseReleased(MouseEvent e) {
                    if (e.getButton() != MouseEvent.BUTTON1) return;
                    Zona z = zonaEn(e.getPoint());
                    if (z != null) z.accion().run();
                }
            };
            addMouseListener(raton);
            addMouseMotionListener(raton);
        }

        private Rectangle2D.Double areaImagen() {
            double escala = Math.min(getWidth() / (double) REF_ANCHO,
                    getHeight() / (double) REF_ALTO);
            double w = REF_ANCHO * escala;
            double h = REF_ALTO * escala;
            return new Rectangle2D.Double((getWidth() - w) / 2.0,
                    (getHeight() - h) / 2.0, w, h);
        }

        private Rectangle2D.Double aPantalla(Zona z, Rectangle2D.Double a) {
            double s = a.width / REF_ANCHO;
            return new Rectangle2D.Double(a.x + z.x() * s, a.y + z.y() * s,
                    z.w() * s, z.h() * s);
        }

        private Zona zonaEn(Point p) {
            Rectangle2D.Double a = areaImagen();
            for (int i = zonas.size() - 1; i >= 0; i--) {
                if (aPantalla(zonas.get(i), a).contains(p)) return zonas.get(i);
            }
            return null;
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(FONDO);
            g2.fillRect(0, 0, getWidth(), getHeight());
            Rectangle2D.Double a = areaImagen();

            if (imagen != null) {
                g2.drawImage(imagen, (int) a.x, (int) a.y,
                        (int) a.width, (int) a.height, null);
            } else {
                g2.setColor(CREMA);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 22));
                g2.drawString("No se encontró /nexusgym/SEDES.jpg",
                        (int) a.x + 30, (int) a.y + 60);
            }

            if (!avisoVisible) {
                double s = a.width / REF_ANCHO;
                int x = (int) a.x;
                int y = (int) (a.y + 62 * s);
                int w = (int) a.width;
                int h = (int) (a.height * 60.0 / REF_ALTO);
                g2.setColor(new Color(13, 15, 20));
                g2.fillRect(x, y, w, h);
            }

            dibujarHover(g2, a);
            g2.dispose();
        }

        private void dibujarHover(Graphics2D g2, Rectangle2D.Double a) {
            if (zonaHover == null) return;
            Rectangle2D.Double r = aPantalla(zonaHover, a);
            if (zonaHover.tipo() == Tipo.MENU) {
                g2.setColor(new Color(255, 255, 255, 28));
                g2.fill(new RoundRectangle2D.Double(r.x, r.y, r.width, r.height, 9, 9));
                double ancho = r.width * 0.62;
                g2.setColor(NARANJA);
                g2.fill(new RoundRectangle2D.Double(r.x + (r.width - ancho) / 2,
                        r.y + r.height - 3, ancho, 3, 3, 3));
            } else {
                g2.setColor(new Color(232, 106, 36, 55));
                g2.fill(new RoundRectangle2D.Double(r.x, r.y, r.width, r.height, 10, 10));
                g2.setColor(NARANJA);
                g2.setStroke(new BasicStroke(2f));
                g2.draw(new RoundRectangle2D.Double(r.x + 1, r.y + 1,
                        r.width - 2, r.height - 2, 10, 10));
            }
        }
    }

    public static void main(String[] args) {
        FlatDarkLaf.setup();
        SwingUtilities.invokeLater(() -> new SedesNexusGym().setVisible(true));
    }
}