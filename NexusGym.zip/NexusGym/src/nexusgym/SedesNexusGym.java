package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SedesNexusGym extends JFrame {

    private JPanel panelContenido;

    public SedesNexusGym() {
        setTitle("Nexus Gym - Nuestras sedes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1160, 661);
        setResizable(false);
        setLocationRelativeTo(null);

        construirInterfaz();
        cargarSedes();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(18, 18, 18));

        // =========================
        // BARRA SUPERIOR
        // =========================
        JPanel barraSuperior = new JPanel(new BorderLayout());
        barraSuperior.setBackground(new Color(25, 25, 25));
        barraSuperior.setBorder(new EmptyBorder(15, 25, 15, 25));
        barraSuperior.setPreferredSize(new Dimension(1160, 75));

        JLabel logo = new JLabel("NEXUS GYM");
        logo.setForeground(new Color(100, 220, 130));
        logo.setFont(new Font("Segoe UI", Font.BOLD, 25));

        JLabel titulo = new JLabel("Nuestras sedes");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JButton volver = new JButton("VOLVER");
        volver.setFocusPainted(false);
        volver.setForeground(Color.WHITE);
        volver.setBackground(new Color(45, 45, 45));
        volver.setBorderPainted(false);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));

        volver.addActionListener(e -> {
            new PaginaPrincipal().setVisible(true);
            dispose();
        });

        barraSuperior.add(logo, BorderLayout.WEST);
        barraSuperior.add(titulo, BorderLayout.CENTER);
        barraSuperior.add(volver, BorderLayout.EAST);

        // =========================
        // CONTENIDO
        // =========================
        panelContenido = new JPanel();
        panelContenido.setLayout(new GridLayout(0, 3, 20, 20));
        panelContenido.setBackground(new Color(18, 18, 18));
        panelContenido.setBorder(new EmptyBorder(30, 30, 30, 30));

        JScrollPane scroll = new JScrollPane(panelContenido);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(new Color(18, 18, 18));

        principal.add(barraSuperior, BorderLayout.NORTH);
        principal.add(scroll, BorderLayout.CENTER);

        setContentPane(principal);
    }

    private void cargarSedes() {

        panelContenido.removeAll();

        String sql = """
            SELECT id_sede, nombre, direccion, telefono, email
            FROM sedes
            WHERE activo = 1
            ORDER BY id_sede
            """;

        // ==========================================
        // CORRECCIÓN: obtener la instancia de Conexion
        // ==========================================
        Conexion conexionBD = Conexion.getInstancia();
        Connection conexion = conexionBD.conectar();

        // Verificar que la conexión exista
        if (conexion == null) {
            JOptionPane.showMessageDialog(
                this,
                "No se pudo establecer conexión con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (
            PreparedStatement pst = conexion.prepareStatement(sql);
            ResultSet rs = pst.executeQuery()
        ) {

            boolean haySedes = false;

            while (rs.next()) {

                haySedes = true;

                int idSede = rs.getInt("id_sede");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String telefono = rs.getString("telefono");
                String email = rs.getString("email");

                panelContenido.add(
                    crearTarjetaSede(
                        idSede,
                        nombre,
                        direccion,
                        telefono,
                        email
                    )
                );
            }

            if (!haySedes) {
                JLabel mensaje = new JLabel(
                    "No hay sedes activas registradas."
                );

                mensaje.setForeground(Color.WHITE);
                mensaje.setFont(
                    new Font("Segoe UI", Font.BOLD, 18)
                );

                panelContenido.add(mensaje);
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudieron cargar las sedes.\n\n"
                + "Error: " + ex.getMessage(),
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
        }

        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private JPanel crearTarjetaSede(
            int idSede,
            String nombre,
            String direccion,
            String telefono,
            String email) {

        JPanel tarjeta = new JPanel();

        tarjeta.setLayout(
            new BoxLayout(tarjeta, BoxLayout.Y_AXIS)
        );

        tarjeta.setBackground(new Color(30, 30, 30));

        tarjeta.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(55, 55, 55)
                ),
                new EmptyBorder(20, 20, 20, 20)
            )
        );

        JLabel lblNombre = new JLabel(nombre);
        lblNombre.setForeground(
            new Color(100, 220, 130)
        );
        lblNombre.setFont(
            new Font("Segoe UI", Font.BOLD, 20)
        );
        lblNombre.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        JLabel lblId = new JLabel(
            "Sede #" + idSede
        );

        lblId.setForeground(
            new Color(150, 150, 150)
        );

        lblId.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );

        lblId.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        JLabel lblDireccion = new JLabel(
            "<html><b>Dirección:</b> "
            + textoSeguro(direccion)
            + "</html>"
        );

        lblDireccion.setForeground(Color.WHITE);
        lblDireccion.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        lblDireccion.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        JLabel lblTelefono = new JLabel(
            "<html><b>Teléfono:</b> "
            + textoSeguro(telefono)
            + "</html>"
        );

        lblTelefono.setForeground(Color.WHITE);
        lblTelefono.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        lblTelefono.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        JLabel lblEmail = new JLabel(
            "<html><b>Email:</b> "
            + textoSeguro(email)
            + "</html>"
        );

        lblEmail.setForeground(Color.WHITE);
        lblEmail.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        lblEmail.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        JButton ver = new JButton("VER SEDE");

        ver.setFocusPainted(false);
        ver.setForeground(Color.WHITE);
        ver.setBackground(
            new Color(55, 130, 75)
        );
        ver.setBorderPainted(false);
        ver.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );
        ver.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        ver.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "NOMBRE: " + nombre
                + "\nDIRECCIÓN: "
                + textoSeguro(direccion)
                + "\nTELÉFONO: "
                + textoSeguro(telefono)
                + "\nEMAIL: "
                + textoSeguro(email),
                "Información de la sede",
                JOptionPane.INFORMATION_MESSAGE
            )
        );

        tarjeta.add(lblNombre);
        tarjeta.add(
            Box.createVerticalStrut(5)
        );

        tarjeta.add(lblId);
        tarjeta.add(
            Box.createVerticalStrut(20)
        );

        tarjeta.add(lblDireccion);
        tarjeta.add(
            Box.createVerticalStrut(10)
        );

        tarjeta.add(lblTelefono);
        tarjeta.add(
            Box.createVerticalStrut(10)
        );

        tarjeta.add(lblEmail);
        tarjeta.add(
            Box.createVerticalGlue()
        );

        tarjeta.add(
            Box.createVerticalStrut(15)
        );

        tarjeta.add(ver);

        return tarjeta;
    }

    private String textoSeguro(String texto) {

        return texto == null || texto.isBlank()
                ? "No registrado"
                : texto;
    }

    public static void main(String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {
            new SedesNexusGym().setVisible(true);
        });
    }
}