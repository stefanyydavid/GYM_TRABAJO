package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PaginaPrincipal extends JFrame {

    private JLabel fondo;

    private final String[] imagenesCarrusel = {
        "/nexusgym/NexusGym_mockup.png",
        "/nexusgym/NexusGym_mockup2.png",
        "/nexusgym/NexusGym_mockup3.png",
        "/nexusgym/NexusGym_mockup4.png",
        "/nexusgym/NexusGym_mockup5.png"
    };

    private int indiceCarrusel = 0;
    private Timer timerCarrusel;

    public PaginaPrincipal() {

        setTitle("Nexus Gym");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1160, 661);
        setResizable(false);
        setLocationRelativeTo(null);

        construirInterfaz();
        iniciarCarrusel();
    }

    private void construirInterfaz() {

        JLayeredPane capas = new JLayeredPane();

        capas.setPreferredSize(
            new Dimension(1160, 661)
        );

        fondo = new JLabel();

        fondo.setBounds(
            0,
            0,
            1160,
            661
        );

        fondo.setHorizontalAlignment(
            SwingConstants.CENTER
        );

        fondo.setVerticalAlignment(
            SwingConstants.CENTER
        );

        cargarImagenCarrusel();

        capas.add(
            fondo,
            Integer.valueOf(0)
        );

        JButton sedes = botonInvisible(
            190,
            17,
            75,
            45
        );

        sedes.setToolTipText(
            "Consultar nuestras sedes"
        );

        sedes.addActionListener(e -> {

            detenerCarrusel();

            abrirVentana(
                new SedesNexusGym()
            );
        });

        capas.add(
            sedes,
            Integer.valueOf(1)
        );

        JButton servicios = botonInvisible(
            270,
            17,
            100,
            45
        );

        servicios.setToolTipText(
            "Consultar servicios"
        );

        servicios.addActionListener(e -> {

            detenerCarrusel();

            abrirVentana(
                new ServiciosNexusGym()
            );
        });

        capas.add(
            servicios,
            Integer.valueOf(1)
        );

        JButton clases = botonInvisible(
            375,
            17,
            90,
            45
        );

        clases.setToolTipText(
            "Consultar clases disponibles"
        );

        clases.addActionListener(e -> {

            detenerCarrusel();

            abrirVentana(
                new ClasesNexusGym()
            );
        });

        capas.add(
            clases,
            Integer.valueOf(1)
        );

        JButton iniciarSesion = botonInvisible(
            975,
            13,
            165,
            50
        );

        iniciarSesion.setToolTipText(
            "Iniciar sesión"
        );

        iniciarSesion.addActionListener(e -> {

            detenerCarrusel();

            abrirVentana(
                new LoginNuevo()
            );
        });

        capas.add(
            iniciarSesion,
            Integer.valueOf(2)
        );

        JButton masInfo = botonInvisible(
            680,
            66,
            90,
            35
        );

        masInfo.setToolTipText(
            "Información de Nexus Gym"
        );

        masInfo.addActionListener(e -> {

            mostrarInformacion();
        });

        capas.add(
            masInfo,
            Integer.valueOf(2)
        );

        JButton izquierda = botonInvisible(
            25,
            350,
            50,
            60
        );

        izquierda.setToolTipText(
            "Contenido anterior"
        );

        izquierda.addActionListener(e -> {

            anteriorCarrusel();
        });

        capas.add(
            izquierda,
            Integer.valueOf(2)
        );

        JButton derecha = botonInvisible(
            1080,
            350,
            50,
            60
        );

        derecha.setToolTipText(
            "Siguiente contenido"
        );

        derecha.addActionListener(e -> {

            siguienteCarrusel();
        });

        capas.add(
            derecha,
            Integer.valueOf(2)
        );

        JButton inscribete = botonInvisible(
            965,
            530,
            130,
            55
        );

        inscribete.setToolTipText(
            "Crear una cuenta en Nexus Gym"
        );

        inscribete.addActionListener(e -> {

            detenerCarrusel();

            abrirVentana(
                new RegistroNexusGym()
            );
        });

        capas.add(
            inscribete,
            Integer.valueOf(2)
        );

        JButton whatsapp = botonInvisible(
            1090,
            570,
            65,
            70
        );

        whatsapp.setToolTipText(
            "Información de contacto"
        );

        whatsapp.addActionListener(e -> {

            mostrarContactos();
        });

        capas.add(
            whatsapp,
            Integer.valueOf(2)
        );

        JButton aceptar = botonInvisible(
            1015,
            610,
            125,
            45
        );

        aceptar.setToolTipText(
            "Aceptar"
        );

        aceptar.addActionListener(e -> {

            JOptionPane.showMessageDialog(
                this,
                "¡Bienvenido a Nexus Gym!",
                "Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
            );
        });

        capas.add(
            aceptar,
            Integer.valueOf(2)
        );

        setContentPane(capas);
    }

    private void iniciarCarrusel() {

        timerCarrusel =
            new Timer(
                5000,
                e -> siguienteCarrusel()
            );

        timerCarrusel.setRepeats(true);
        timerCarrusel.start();
    }

    private void detenerCarrusel() {

        if (timerCarrusel != null) {
            timerCarrusel.stop();
        }
    }

    private void siguienteCarrusel() {

        indiceCarrusel++;

        if (indiceCarrusel >= imagenesCarrusel.length) {
            indiceCarrusel = 0;
        }

        cargarImagenCarrusel();
        reiniciarTemporizador();
    }

    private void anteriorCarrusel() {

        indiceCarrusel--;

        if (indiceCarrusel < 0) {
            indiceCarrusel =
                imagenesCarrusel.length - 1;
        }

        cargarImagenCarrusel();
        reiniciarTemporizador();
    }

    private void reiniciarTemporizador() {

        if (timerCarrusel != null) {
            timerCarrusel.restart();
        }
    }

    private void cargarImagenCarrusel() {

        java.net.URL urlImagen =
            getClass().getResource(
                imagenesCarrusel[indiceCarrusel]
            );

        if (urlImagen != null) {

            ImageIcon imagenOriginal =
                new ImageIcon(urlImagen);

            Image imagenAjustada =
                ajustarImagen(
                    imagenOriginal.getImage(),
                    1160,
                    661
                );

            fondo.setIcon(
                new ImageIcon(imagenAjustada)
            );

            fondo.setText("");

        } else {

            fondo.setIcon(null);

            fondo.setText(
                "NEXUS GYM - No se encontró la imagen "
                + (indiceCarrusel + 1)
            );

            fondo.setForeground(Color.WHITE);

            fondo.setFont(
                new Font(
                    "Segoe UI",
                    Font.BOLD,
                    24
                )
            );

            fondo.setBackground(
                new Color(18, 18, 18)
            );

            fondo.setOpaque(true);
        }

        fondo.revalidate();
        fondo.repaint();
    }

    private Image ajustarImagen(
            Image imagen,
            int anchoObjetivo,
            int altoObjetivo) {

        int anchoOriginal =
            imagen.getWidth(null);

        int altoOriginal =
            imagen.getHeight(null);

        if (anchoOriginal <= 0
                || altoOriginal <= 0) {

            return imagen;
        }

        double escalaX =
            (double) anchoObjetivo
            / anchoOriginal;

        double escalaY =
            (double) altoObjetivo
            / altoOriginal;

        double escala =
            Math.min(
                escalaX,
                escalaY
            );

        int nuevoAncho =
            (int) Math.round(
                anchoOriginal * escala
            );

        int nuevoAlto =
            (int) Math.round(
                altoOriginal * escala
            );

        BufferedImage imagenNueva =
            new BufferedImage(
                nuevoAncho,
                nuevoAlto,
                BufferedImage.TYPE_INT_ARGB
            );

        Graphics2D g2 =
            imagenNueva.createGraphics();

        g2.setRenderingHint(
            RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_BICUBIC
        );

        g2.setRenderingHint(
            RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY
        );

        g2.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        );

        g2.drawImage(
            imagen,
            0,
            0,
            nuevoAncho,
            nuevoAlto,
            null
        );

        g2.dispose();

        return imagenNueva;
    }

    private void abrirVentana(JFrame ventana) {

        ventana.setVisible(true);
        dispose();
    }

    private void mostrarInformacion() {

        String sqlSedes =
            "SELECT COUNT(*) AS total "
            + "FROM sedes "
            + "WHERE activo = 1";

        String sqlClases =
            "SELECT COUNT(*) AS total "
            + "FROM clases "
            + "WHERE activo = 1";

        int totalSedes = 0;
        int totalClases = 0;

        Conexion conexionBD =
            Conexion.getInstancia();

        Connection conexion =
            conexionBD.conectar();

        if (conexion == null) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudo conectar con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try (
            PreparedStatement pstSedes =
                conexion.prepareStatement(
                    sqlSedes
                );

            PreparedStatement pstClases =
                conexion.prepareStatement(
                    sqlClases
                );

            ResultSet rsSedes =
                pstSedes.executeQuery();

            ResultSet rsClases =
                pstClases.executeQuery()
        ) {

            if (rsSedes.next()) {

                totalSedes =
                    rsSedes.getInt("total");
            }

            if (rsClases.next()) {

                totalClases =
                    rsClases.getInt("total");
            }

            JOptionPane.showMessageDialog(
                this,
                """
                NEXUS GYM

                Plataforma de gestión y consulta
                para nuestros usuarios.

                Sedes activas: %d
                Clases activas: %d

                Consulta nuestras sedes y clases
                disponibles desde el menú principal.

                Si ya tienes una cuenta,
                puedes iniciar sesión.
                """.formatted(
                    totalSedes,
                    totalClases
                ),
                "Información de Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                """
                NEXUS GYM

                No fue posible consultar la
                información de la base de datos.

                Error:
                %s
                """.formatted(
                    ex.getMessage()
                ),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void mostrarContactos() {

        String sql = """
            SELECT nombre, telefono, email
            FROM sedes
            WHERE activo = 1
            ORDER BY id_sede
            """;

        StringBuilder contactos =
            new StringBuilder();

        contactos.append(
            "CONTACTO NEXUS GYM\n\n"
        );

        Conexion conexionBD =
            Conexion.getInstancia();

        Connection conexion =
            conexionBD.conectar();

        if (conexion == null) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudo conectar con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        try (
            PreparedStatement pst =
                conexion.prepareStatement(sql);

            ResultSet rs =
                pst.executeQuery()
        ) {

            boolean hayContactos = false;

            while (rs.next()) {

                hayContactos = true;

                String nombre =
                    rs.getString("nombre");

                String telefono =
                    rs.getString("telefono");

                String email =
                    rs.getString("email");

                contactos.append(nombre);

                contactos.append(
                    "\nTeléfono: "
                );

                contactos.append(
                    textoSeguro(telefono)
                );

                contactos.append(
                    "\nEmail: "
                );

                contactos.append(
                    textoSeguro(email)
                );

                contactos.append("\n\n");
            }

            if (!hayContactos) {

                contactos.append(
                    "No hay sedes activas registradas."
                );
            }

            JOptionPane.showMessageDialog(
                this,
                contactos.toString(),
                "Contacto Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible cargar los contactos.\n\n"
                + "Error: "
                + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private String textoSeguro(
            String texto) {

        if (texto == null
                || texto.isBlank()) {

            return "No registrado";
        }

        return texto;
    }

    private JButton botonInvisible(
            int x,
            int y,
            int ancho,
            int alto) {

        JButton boton =
            new JButton();

        boton.setBounds(
            x,
            y,
            ancho,
            alto
        );

        boton.setOpaque(false);
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);

        boton.setCursor(
            new Cursor(
                Cursor.HAND_CURSOR
            )
        );

        return boton;
    }

    public static void main(
            String[] args) {

        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {

            PaginaPrincipal pagina =
                new PaginaPrincipal();

            pagina.setVisible(true);
        });
    }
}