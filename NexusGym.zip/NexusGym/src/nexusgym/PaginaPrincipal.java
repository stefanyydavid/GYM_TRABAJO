
package nexusgym;

import com.formdev.flatlaf.FlatDarkLaf;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaginaPrincipal extends JFrame {

    private static final Color NARANJA = new Color(232, 106, 36);
    private static final Color CREMA = new Color(240, 232, 218);
    private static final Color FONDO = new Color(13, 15, 20);

    private static final int REF_ANCHO = 1536;
    private static final int DURACION_SLIDE = 5000;
    private static final int DURACION_FADE = 450;
    private static final int TICK = 16;

    private enum Tipo {
        MENU, BOTON, FLECHA
    }

    /*
     * diapositiva:
     * -1 = zona común para todas las imágenes.
     *  0 = primera imagen.
     *  1 = segunda imagen.
     *  2 = tercera imagen.
     *  3 = cuarta imagen.
     *  4 = quinta imagen.
     */
    private record Zona(
            String nombre,
            double x,
            double y,
            double w,
            double h,
            Tipo tipo,
            Runnable accion,
            int diapositiva) {

        Zona(String nombre, double x, double y, double w, double h,
             Tipo tipo, Runnable accion) {
            this(nombre, x, y, w, h, tipo, accion, -1);
        }
    }

    private final String[] rutas = {
        "/nexusgym/NexusGym_mockup.png",
        "/nexusgym/NexusGym_mockup2.png",
        "/nexusgym/NexusGym_mockup3.png",
        "/nexusgym/NexusGym_mockup4.png",
        "/nexusgym/NexusGym_mockup5.png"
    };

    /*
     * Alturas reales de las imágenes proporcionadas.
     * El ancho de las cinco imágenes es 1536 píxeles.
     */
    private final int[] altosImagen = {
        883, 875, 886, 879, 909
    };

    private final BufferedImage[] imagenes =
            new BufferedImage[rutas.length];

    private final List<Zona> zonas = new ArrayList<>();
    private final Rectangle rectContacto = new Rectangle();

    private int actual = 0;
    private int anterior = -1;

    private float fade = 1f;
    private int progresoMs = 0;

    private boolean pausado = false;
    private boolean hoverContacto = false;

    private Zona zonaHover = null;

    private Timer reloj;
    private Lienzo lienzo;

    public PaginaPrincipal() {
        setTitle("Nexus Gym");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cargarImagenes();
        crearZonas();

        lienzo = new Lienzo();
        lienzo.setPreferredSize(new Dimension(1200, 690));

        setContentPane(lienzo);
        setMinimumSize(new Dimension(960, 560));

        pack();
        setLocationRelativeTo(null);

        configurarTeclado();
        iniciarReloj();
    }

    // ---------------------------------------------------------
    // CARGA DE IMÁGENES
    // ---------------------------------------------------------

    private void cargarImagenes() {
        for (int i = 0; i < rutas.length; i++) {
            URL url = getClass().getResource(rutas[i]);

            if (url == null) {
                System.err.println(
                    "No se encontró la imagen: " + rutas[i]
                );
                continue;
            }

            try {
                imagenes[i] = ImageIO.read(url);

                if (imagenes[i] != null) {
                    System.out.println(
                        "Imagen " + (i + 1) + ": "
                        + imagenes[i].getWidth() + " x "
                        + imagenes[i].getHeight()
                    );
                }
            } catch (IOException ex) {
                System.err.println(
                    "Error al cargar " + rutas[i] + ": "
                    + ex.getMessage()
                );
            }
        }
    }

    // ---------------------------------------------------------
    // ZONAS INTERACTIVAS
    // ---------------------------------------------------------

    private void crearZonas() {

        // MENÚ SUPERIOR: zonas comunes.
        zonas.add(new Zona(
            "NEXUS GYM",
            30, 5, 245, 65,
            Tipo.MENU,
            () -> abrirVentana(new PaginaPrincipal())
        ));

        zonas.add(new Zona(
            "SEDES",
            290, 5, 110, 65,
            Tipo.MENU,
            () -> abrirVentana(new SedesNexusGym())
        ));

        zonas.add(new Zona(
            "SERVICIOS",
            410, 5, 155, 65,
            Tipo.MENU,
            () -> abrirVentana(new ServiciosNexusGym())
        ));

        zonas.add(new Zona(
            "CLASES",
            580, 5, 115, 65,
            Tipo.MENU,
            () -> abrirVentana(new ClasesNexusGym())
        ));

        zonas.add(new Zona(
            "SUSCRIPCIONES / PLANES",
            705, 5, 310, 65,
            Tipo.MENU,
            () -> mostrarEnProceso("PLANES")
        ));

        zonas.add(new Zona(
            "PAGOS",
            1015, 5, 115, 65,
            Tipo.MENU,
            () -> mostrarEnProceso("PAGOS")
        ));

        zonas.add(new Zona(
            "INICIAR SESIÓN",
            1250, 5, 260, 65,
            Tipo.BOTON,
            () -> abrirVentana(new LoginNuevo())
        ));

        // BARRA PROMOCIONAL.
        zonas.add(new Zona(
            "Más info",
            860, 75, 140, 55,
            Tipo.MENU,
            this::mostrarInformacion
        ));

        // FLECHAS LATERALES.
        zonas.add(new Zona(
            "Anterior",
            0, 370, 85, 120,
            Tipo.FLECHA,
            () -> irA(actual - 1)
        ));

        zonas.add(new Zona(
            "Siguiente",
            1450, 370, 86, 120,
            Tipo.FLECHA,
            () -> irA(actual + 1)
        ));

        /*
         * BOTÓN DE INSCRIPCIÓN.
         * La posición cambia según la diapositiva.
         * Las coordenadas corresponden a cada imagen original.
         */

        zonas.add(new Zona(
            "Inscríbete hoy",
            1310, 680, 175, 60,
            Tipo.BOTON,
            () -> abrirVentana(new RegistroNexusGym()),
            0
        ));

        zonas.add(new Zona(
            "Inscríbete hoy",
            1300, 660, 185, 65,
            Tipo.BOTON,
            () -> abrirVentana(new RegistroNexusGym()),
            1
        ));

        zonas.add(new Zona(
            "Inscríbete hoy",
            1290, 680, 190, 65,
            Tipo.BOTON,
            () -> abrirVentana(new RegistroNexusGym()),
            2
        ));

        zonas.add(new Zona(
            "Inscríbete hoy",
            1290, 685, 210, 70,
            Tipo.BOTON,
            () -> abrirVentana(new RegistroNexusGym()),
            3
        ));

        zonas.add(new Zona(
            "Inscríbete hoy",
            1240, 690, 240, 75,
            Tipo.BOTON,
            () -> abrirVentana(new RegistroNexusGym()),
            4
        ));

        // CONTADOR INFERIOR IZQUIERDO.
        for (int i = 0; i < rutas.length; i++) {
            final int diapositiva = i;

            zonas.add(new Zona(
                "Siguiente",
                35, altosImagen[i] - 145, 135, 75,
                Tipo.MENU,
                () -> irA(diapositiva + 1),
                diapositiva
            ));
        }
    }

    // ---------------------------------------------------------
    // TECLADO
    // ---------------------------------------------------------

    private void configurarTeclado() {

        InputMap im = getRootPane().getInputMap(
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        ActionMap am = getRootPane().getActionMap();

        im.put(
            KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0),
            "anterior"
        );

        im.put(
            KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0),
            "siguiente"
        );

        im.put(
            KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
            "cerrar"
        );

        am.put("anterior", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                irA(actual - 1);
            }
        });

        am.put("siguiente", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                irA(actual + 1);
            }
        });

        am.put("cerrar", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    // ---------------------------------------------------------
    // CARRUSEL
    // ---------------------------------------------------------

    private void iniciarReloj() {

        reloj = new Timer(TICK, e -> {

            boolean cambio = false;

            if (fade < 1f) {
                fade = Math.min(
                    1f,
                    fade + (float) TICK / DURACION_FADE
                );

                cambio = true;
            }

            if (!pausado && fade >= 1f) {

                progresoMs += TICK;
                cambio = true;

                if (progresoMs >= DURACION_SLIDE) {
                    irA(actual + 1);
                }
            }

            if (cambio) {
                lienzo.repaint();
            }
        });

        reloj.start();
    }

    private void irA(int indice) {

        int total = rutas.length;
        int nuevo = ((indice % total) + total) % total;

        if (nuevo == actual) {
            return;
        }

        anterior = actual;
        actual = nuevo;

        fade = 0f;
        progresoMs = 0;

        zonaHover = null;
        hoverContacto = false;

        lienzo.repaint();
    }

    private void abrirVentana(JFrame ventana) {

        if (reloj != null) {
            reloj.stop();
        }

        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        dispose();
    }

    @Override
    public void dispose() {
        if (reloj != null) {
            reloj.stop();
        }

        super.dispose();
    }

    // ---------------------------------------------------------
    // LIENZO PRINCIPAL
    // ---------------------------------------------------------

    private class Lienzo extends JPanel {

        Lienzo() {
            setBackground(FONDO);
            setFocusable(true);

            MouseAdapter raton = new MouseAdapter() {

                @Override
                public void mouseMoved(MouseEvent e) {
                    actualizarHover(e.getPoint());
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    limpiarHover();
                }

                @Override
                public void mouseReleased(MouseEvent e) {

                    if (e.getButton() != MouseEvent.BUTTON1) {
                        return;
                    }

                    Point p = e.getPoint();

                    if (rectContacto.contains(p)) {
                        mostrarContactos();
                        return;
                    }

                    Zona z = zonaEn(p);

                    if (z != null && z.accion() != null) {
                        z.accion().run();
                    }
                }
            };

            addMouseListener(raton);
            addMouseMotionListener(raton);
        }

        /*
         * Cada imagen utiliza sus propias dimensiones reales.
         * No se fuerza a todas a tener una misma altura.
         */
        Rectangle2D.Double areaImagen() {

            BufferedImage img = imagenes[actual];

            int ancho = img != null
                ? img.getWidth()
                : REF_ANCHO;

            int alto = img != null
                ? img.getHeight()
                : altosImagen[actual];

            double escala = Math.min(
                getWidth() / (double) ancho,
                getHeight() / (double) alto
            );

            double w = ancho * escala;
            double h = alto * escala;

            return new Rectangle2D.Double(
                (getWidth() - w) / 2.0,
                (getHeight() - h) / 2.0,
                w,
                h
            );
        }

        /*
         * Convierte las coordenadas originales de una zona
         * a coordenadas de pantalla usando la escala real.
         */
        Rectangle2D.Double aPantalla(
                Zona z,
                Rectangle2D.Double a) {

            BufferedImage img = imagenes[actual];

            double ancho = img != null
                ? img.getWidth()
                : REF_ANCHO;

            double alto = img != null
                ? img.getHeight()
                : altosImagen[actual];

            double sx = a.width / ancho;
            double sy = a.height / alto;

            return new Rectangle2D.Double(
                a.x + z.x() * sx,
                a.y + z.y() * sy,
                z.w() * sx,
                z.h() * sy
            );
        }

        Zona zonaEn(Point p) {

            Rectangle2D.Double a = areaImagen();

            for (int i = zonas.size() - 1; i >= 0; i--) {

                Zona z = zonas.get(i);

                // Ignorar las zonas que pertenecen a otra imagen.
                if (z.diapositiva() != -1
                        && z.diapositiva() != actual) {
                    continue;
                }

                if (aPantalla(z, a).contains(p)) {
                    return z;
                }
            }

            return null;
        }

        void actualizarHover(Point p) {

            Zona nueva = zonaEn(p);
            boolean contacto = rectContacto.contains(p);

            if (nueva != zonaHover
                    || contacto != hoverContacto) {

                zonaHover = nueva;
                hoverContacto = contacto;

                pausado = nueva != null || contacto;

                repaint();
            }

            if (contacto) {
                setToolTipText("Contacto");
            } else if (nueva != null) {
                setToolTipText(nueva.nombre());
            } else {
                setToolTipText(null);
            }

            setCursor(Cursor.getPredefinedCursor(
                nueva != null || contacto
                    ? Cursor.HAND_CURSOR
                    : Cursor.DEFAULT_CURSOR
            ));
        }

        void limpiarHover() {

            zonaHover = null;
            hoverContacto = false;
            pausado = false;

            setToolTipText(null);
            setCursor(Cursor.getDefaultCursor());

            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC
            );

            g2.setRenderingHint(
                RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY
            );

            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            g2.setColor(FONDO);
            g2.fillRect(0, 0, getWidth(), getHeight());

            Rectangle2D.Double a = areaImagen();

            if (anterior >= 0 && fade < 1f) {

                float t = fade * fade * (3f - 2f * fade);

                dibujarImagen(g2, anterior, a, 1f);
                dibujarImagen(g2, actual, a, t);

            } else {
                dibujarImagen(g2, actual, a, 1f);
            }

            dibujarHover(g2, a);
            dibujarProgreso(g2, a);
            dibujarContacto(g2, a);

            g2.dispose();
        }

        void dibujarImagen(
                Graphics2D g2,
                int indice,
                Rectangle2D.Double a,
                float alpha) {

            Graphics2D g = (Graphics2D) g2.create();

            g.setComposite(AlphaComposite.getInstance(
                AlphaComposite.SRC_OVER,
                Math.max(0f, Math.min(1f, alpha))
            ));

            BufferedImage img = imagenes[indice];

            int x = (int) Math.round(a.x);
            int y = (int) Math.round(a.y);
            int w = (int) Math.round(a.width);
            int h = (int) Math.round(a.height);

            if (img != null) {

                /*
                 * Se dibuja la imagen dentro de su área calculada.
                 * El escalado conserva la proporción original.
                 */
                g.drawImage(img, x, y, w, h, null);

            } else {

                g.setPaint(new GradientPaint(
                    0, y, new Color(30, 36, 46),
                    0, y + h, FONDO
                ));

                g.fillRect(x, y, w, h);

                g.setColor(Color.WHITE);
                g.setFont(new Font(
                    "Segoe UI", Font.BOLD, 24
                ));

                String texto =
                    "NEXUS GYM - No se encontró la imagen "
                    + (indice + 1);

                FontMetrics fm = g.getFontMetrics();

                g.drawString(
                    texto,
                    x + (w - fm.stringWidth(texto)) / 2,
                    y + h / 2
                );
            }

            g.dispose();
        }

        void dibujarHover(
                Graphics2D g2,
                Rectangle2D.Double a) {

            if (zonaHover == null) {
                return;
            }

            Rectangle2D.Double r = aPantalla(zonaHover, a);

            switch (zonaHover.tipo()) {

                case MENU -> {

                    g2.setColor(new Color(255, 255, 255, 26));

                    g2.fill(new RoundRectangle2D.Double(
                        r.x, r.y, r.width, r.height, 12, 12
                    ));

                    double ancho = r.width * 0.62;

                    g2.setColor(NARANJA);

                    g2.fill(new RoundRectangle2D.Double(
                        r.x + (r.width - ancho) / 2.0,
                        r.y + r.height - 4,
                        ancho, 3, 3, 3
                    ));
                }

                case BOTON -> {

                    g2.setColor(new Color(232, 106, 36, 48));

                    g2.fill(new RoundRectangle2D.Double(
                        r.x, r.y, r.width, r.height, 12, 12
                    ));

                    g2.setColor(NARANJA);
                    g2.setStroke(new BasicStroke(2f));

                    g2.draw(new RoundRectangle2D.Double(
                        r.x + 1, r.y + 1,
                        r.width - 2, r.height - 2,
                        12, 12
                    ));
                }

                case FLECHA -> {

                    double d = Math.min(r.width, r.height);

                    g2.setColor(new Color(255, 255, 255, 34));

                    g2.fill(new Ellipse2D.Double(
                        r.x + (r.width - d) / 2.0,
                        r.y + (r.height - d) / 2.0,
                        d, d
                    ));
                }
            }
        }

        void dibujarProgreso(
                Graphics2D g2,
                Rectangle2D.Double a) {

            int w = (int) (
                a.width * progresoMs / (double) DURACION_SLIDE
            );

            g2.setColor(new Color(232, 106, 36, 210));

            g2.fillRect(
                (int) a.x,
                (int) (a.y + a.height - 3),
                w, 3
            );
        }

        void dibujarContacto(
                Graphics2D g2,
                Rectangle2D.Double a) {

            int d = 46;

            int x = (int) (a.x + a.width - d - 24);
            int y = (int) (a.y + a.height - d - 8);

            rectContacto.setBounds(x, y, d, d);

            int crece = hoverContacto ? 3 : 0;

            double bx = x - crece;
            double by = y - crece;
            double bd = d + crece * 2;

            g2.setColor(new Color(0, 0, 0, 90));

            g2.fill(new Ellipse2D.Double(
                bx + 1, by + 3, bd, bd
            ));

            g2.setPaint(new GradientPaint(
                0, (float) by, new Color(247, 138, 64),
                0, (float) (by + bd), new Color(214, 90, 22)
            ));

            g2.fill(new Ellipse2D.Double(
                bx, by, bd, bd
            ));

            double cx = bx + bd / 2.0;
            double cy = by + bd / 2.0;

            g2.setColor(Color.WHITE);

            g2.fill(new RoundRectangle2D.Double(
                cx - 11, cy - 10, 22, 16, 7, 7
            ));

            Polygon pico = new Polygon();

            pico.addPoint((int) (cx - 5), (int) (cy + 5));
            pico.addPoint((int) (cx - 7), (int) (cy + 12));
            pico.addPoint((int) (cx + 2), (int) (cy + 5));

            g2.fill(pico);

            g2.setColor(NARANJA);

            g2.fill(new Ellipse2D.Double(
                cx - 6.5, cy - 4, 3.4, 3.4
            ));

            g2.fill(new Ellipse2D.Double(
                cx - 1.7, cy - 4, 3.4, 3.4
            ));

            g2.fill(new Ellipse2D.Double(
                cx + 3.1, cy - 4, 3.4, 3.4
            ));
        }
    }

    // ---------------------------------------------------------
    // VENTANA DE SECCIÓN EN PROCESO
    // ---------------------------------------------------------

    private void mostrarEnProceso(String nombreSeccion) {

        JDialog dialogo = new JDialog(this, true);

        dialogo.setUndecorated(true);
        dialogo.setBackground(new Color(0, 0, 0, 0));

        JPanel panel = new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {

                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                g2.setPaint(new GradientPaint(
                    0, 0, new Color(30, 36, 46),
                    0, getHeight(), new Color(13, 15, 20)
                ));

                g2.fillRoundRect(
                    0, 0,
                    getWidth() - 1,
                    getHeight() - 1,
                    28, 28
                );

                g2.setColor(NARANJA);
                g2.setStroke(new BasicStroke(2f));

                g2.drawRoundRect(
                    1, 1,
                    getWidth() - 3,
                    getHeight() - 3,
                    28, 28
                );

                g2.dispose();
            }
        };

        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(
            panel, BoxLayout.Y_AXIS
        ));

        panel.setBorder(BorderFactory.createEmptyBorder(
            30, 44, 30, 44
        ));

        JLabel marca = new JLabel("NEXUS GYM");
        marca.setFont(new Font(
            "Segoe UI", Font.BOLD, 14
        ));
        marca.setForeground(NARANJA);
        marca.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titulo = new JLabel(nombreSeccion);
        titulo.setFont(new Font(
            "Segoe UI", Font.BOLD, 38
        ));
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel estado = new JLabel("Sección en proceso");
        estado.setFont(new Font(
            "Segoe UI", Font.BOLD, 18
        ));
        estado.setForeground(CREMA);
        estado.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel mensaje = new JLabel(
            "<html><div style='text-align:center;'>"
            + "Estamos preparando esta sección<br>"
            + "para que tengas la mejor experiencia.<br>"
            + "¡Muy pronto estará disponible!"
            + "</div></html>"
        );

        mensaje.setFont(new Font(
            "Segoe UI", Font.PLAIN, 14
        ));
        mensaje.setForeground(new Color(170, 176, 188));
        mensaje.setAlignmentX(Component.CENTER_ALIGNMENT);

        JProgressBar progreso = new JProgressBar();
        progreso.setIndeterminate(true);
        progreso.setForeground(NARANJA);
        progreso.setBorderPainted(false);
        progreso.setMaximumSize(new Dimension(260, 6));
        progreso.setPreferredSize(new Dimension(260, 6));
        progreso.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton entendido = new JButton("ENTENDIDO");
        entendido.setFont(new Font(
            "Segoe UI", Font.BOLD, 14
        ));
        entendido.setForeground(Color.WHITE);
        entendido.setBackground(NARANJA);
        entendido.setFocusPainted(false);
        entendido.setBorderPainted(false);
        entendido.setCursor(new Cursor(
            Cursor.HAND_CURSOR
        ));
        entendido.putClientProperty(
            "JButton.buttonType", "roundRect"
        );
        entendido.setMaximumSize(new Dimension(180, 40));
        entendido.setPreferredSize(new Dimension(180, 40));
        entendido.setAlignmentX(Component.CENTER_ALIGNMENT);
        entendido.addActionListener(e -> dialogo.dispose());

        panel.add(marca);
        panel.add(Box.createVerticalStrut(6));
        panel.add(titulo);
        panel.add(Box.createVerticalStrut(10));
        panel.add(estado);
        panel.add(Box.createVerticalStrut(14));
        panel.add(mensaje);
        panel.add(Box.createVerticalStrut(22));
        panel.add(progreso);
        panel.add(Box.createVerticalStrut(24));
        panel.add(entendido);

        dialogo.setContentPane(panel);

        dialogo.getRootPane().registerKeyboardAction(
            e -> dialogo.dispose(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        dialogo.getRootPane().setDefaultButton(entendido);

        dialogo.pack();
        dialogo.setLocationRelativeTo(this);
        dialogo.setVisible(true);
    }

    // ---------------------------------------------------------
    // INFORMACIÓN GENERAL
    // ---------------------------------------------------------

    private void mostrarInformacion() {

        String sqlSedes =
            "SELECT COUNT(*) AS total "
            + "FROM sedes WHERE activo = 1";

        String sqlClases =
            "SELECT COUNT(*) AS total "
            + "FROM clases WHERE activo = 1";

        int totalSedes = 0;
        int totalClases = 0;

        Conexion conexionBD = Conexion.getInstancia();
        Connection conexion = conexionBD.conectar();

        if (conexion == null) {
            JOptionPane.showMessageDialog(
                this,
                "No se pudo conectar con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (
            PreparedStatement pstSedes =
                conexion.prepareStatement(sqlSedes);
            PreparedStatement pstClases =
                conexion.prepareStatement(sqlClases);
            ResultSet rsSedes = pstSedes.executeQuery();
            ResultSet rsClases = pstClases.executeQuery()
        ) {

            if (rsSedes.next()) {
                totalSedes = rsSedes.getInt("total");
            }

            if (rsClases.next()) {
                totalClases = rsClases.getInt("total");
            }

            JOptionPane.showMessageDialog(
                this,
                "NEXUS GYM\n\n"
                + "Plataforma de gestión y consulta "
                + "para nuestros usuarios.\n\n"
                + "Sedes activas: " + totalSedes + "\n"
                + "Clases activas: " + totalClases + "\n\n"
                + "Consulta nuestras sedes y clases "
                + "desde el menú principal.",
                "Información de Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible consultar la información.\n\n"
                + "Error: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ---------------------------------------------------------
    // CONTACTOS
    // ---------------------------------------------------------

    private void mostrarContactos() {

        String sql =
            "SELECT nombre, telefono, email "
            + "FROM sedes "
            + "WHERE activo = 1 "
            + "ORDER BY id_sede";

        StringBuilder contactos =
            new StringBuilder("CONTACTO NEXUS GYM\n\n");

        Conexion conexionBD = Conexion.getInstancia();
        Connection conexion = conexionBD.conectar();

        if (conexion == null) {
            JOptionPane.showMessageDialog(
                this,
                "No se pudo conectar con la base de datos.",
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (
            PreparedStatement pst =
                conexion.prepareStatement(sql);
            ResultSet rs = pst.executeQuery()
        ) {

            boolean hayContactos = false;

            while (rs.next()) {

                hayContactos = true;

                contactos.append(
                    textoSeguro(rs.getString("nombre"))
                );

                contactos.append("\nTeléfono: ");
                contactos.append(
                    textoSeguro(rs.getString("telefono"))
                );

                contactos.append("\nEmail: ");
                contactos.append(
                    textoSeguro(rs.getString("email"))
                );

                contactos.append("\n\n");
            }

            if (!hayContactos) {
                contactos.append(
                    "No hay sedes activas registradas."
                );
            }

            JOptionPane.showMessageDialog(
                this,
                contactos.toString(),
                "Contacto Nexus Gym",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible cargar los contactos.\n\n"
                + "Error: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private String textoSeguro(String texto) {

        if (texto == null || texto.isBlank()) {
            return "No registrado";
        }

        return texto;
    }

    // ---------------------------------------------------------
    // INICIO
    // ---------------------------------------------------------

    public static void main(String[] args) {

        try {
            FlatDarkLaf.setup();
        } catch (Exception ex) {
            System.err.println(
                "No se pudo cargar FlatDarkLaf: "
                + ex.getMessage()
            );
        }

        SwingUtilities.invokeLater(() -> {
            PaginaPrincipal pagina = new PaginaPrincipal();
            pagina.setVisible(true);
        });
    }
}
