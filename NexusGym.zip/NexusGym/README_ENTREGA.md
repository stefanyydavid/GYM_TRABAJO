# NexusGym — proyecto NetBeans

## Requisitos
- JDK 17 o superior (el proyecto se configura para compilar con Java 17).
- NetBeans con soporte para proyectos Ant.
- MariaDB/MySQL de XAMPP, base `db_gym`; configuración local predeterminada: `127.0.0.1:3307`, usuario `root`, contraseña vacía.
- Bibliotecas Java: MySQL Connector/J, FlatLaf 3.6.1, bcrypt 0.10.2 y bytes 1.5.0.

## Abrir
1. Extrae el ZIP completo.
2. En NetBeans selecciona **File > Open Project** y elige la carpeta `NexusGym`.
3. Coloca los JAR oficiales en `NexusGym/lib/` con estos nombres exactos: `mysql-connector-j.jar`, `flatlaf.jar`, `bcrypt.jar`, `bytes.jar`.
4. Configura/arranca MySQL y prepara `db_gym` usando los scripts de `NexusGym_BaseDatos.zip`.
5. Ejecuta el proyecto; clase principal `nexusgym.LoginNuevo`.

## Conexión
Por defecto se conecta a `jdbc:mysql://127.0.0.1:3307/db_gym`. Puedes sobreescribir con variables de entorno `NEXUS_DB_URL`, `NEXUS_DB_USER` y `NEXUS_DB_PASSWORD`. No guardes claves reales en el código.

## Alcance y verificación
Este ZIP conserva las clases, formularios y cinco mockups que venían en el proyecto recibido, normaliza las rutas de dependencias y mejora la configuración JDBC. No se pudo certificar una compilación/ejecución integral en este entorno porque no se proporcionaron los JAR binarios y no hay servidor MySQL activo aquí. La integración de pagos reales necesita credenciales de un proveedor y un backend público con HTTPS; no se deben poner secretos de pasarela en Swing ni en SQL.
